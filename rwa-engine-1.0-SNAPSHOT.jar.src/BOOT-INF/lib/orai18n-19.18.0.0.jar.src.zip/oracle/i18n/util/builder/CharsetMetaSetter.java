/*    */ package oracle.i18n.util.builder;
/*    */ 
/*    */ import java.util.Map;
/*    */ import oracle.i18n.text.converter.CharsetMeta;
/*    */ import oracle.i18n.util.GDKOracleMetaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CharsetMetaSetter
/*    */   extends CharsetMeta
/*    */ {
/* 21 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setAvailableCharacterSets(String[] paramArrayOfString) {
/* 29 */     this.m_aveCharsets = paramArrayOfString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setCharSetNameToId(Map paramMap) {
/* 39 */     this.m_charSetIdMap = paramMap;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setContainsCharset(Map paramMap) {
/* 50 */     this.m_containsCharset = paramMap;
/*    */   }
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18\\util\builder\CharsetMetaSetter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import oracle.i18n.text.converter.CharsetMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharConvRepackage
/*     */ {
/*     */   private static final String M_COMMAND = "-custom-charsets-jar";
/*     */   private static final String M_CHARSET = "-charset";
/*     */   private static final String M_MANIFEST_NAME = "META-INF/MANIFEST.MF";
/*     */   private static final String M_DEFAULT_JAR_NAME = "jdbc_orai18n_cs.jar";
/*     */   private static final String M_RESERVED_NAME = "orai18n";
/*  73 */   private static final String[] GDK_JDBC_PACKAGE_CLASS = new String[] { "oracle/i18n/text/converter/CharacterConverterOGS.class", "oracle/i18n/text/converter/CharacterConverter12Byte.class", "oracle/i18n/text/converter/CharacterConverter1Byte.class", "oracle/i18n/text/converter/CharacterConverterGB18030.class", "oracle/i18n/text/converter/CharacterConverterJAEUC.class", "oracle/i18n/text/converter/CharacterConverterLC.class", "oracle/i18n/text/converter/CharacterConverterSJIS.class", "oracle/i18n/text/converter/CharacterConverterShift.class", "oracle/i18n/text/converter/CharacterConverterZHTEUC.class", "oracle/i18n/text/converter/Messages.class", "oracle/i18n/text/converter/GDKMessage.class", "oracle/i18n/util/GDKOracleMetaData.class", "oracle/i18n/text/converter/CharacterConverter.class" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private static final Set UNICODE_CHARSETS = new HashSet();
/*     */ 
/*     */   
/*     */   static {
/*  94 */     UNICODE_CHARSETS.add("AL16UTF16");
/*  95 */     UNICODE_CHARSETS.add("AL16UTF16LE");
/*  96 */     UNICODE_CHARSETS.add("AL32UTF8");
/*  97 */     UNICODE_CHARSETS.add("UTF8");
/*  98 */     UNICODE_CHARSETS.add("UTFE");
/*  99 */     UNICODE_CHARSETS.add("AL24UTFFSS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getCommand() {
/* 109 */     return "-custom-charsets-jar";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printUsage() {
/* 117 */     System.out.println("  -custom-charsets-jar <jar/zip file name> -charset <character set name> [<character set name> ...] : Generates a custom character set jar/zip file");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void main(List<String> paramList) throws Exception {
/*     */     File file1;
/* 141 */     if (paramList.size() < 2) {
/*     */       
/* 143 */       printUsage();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 149 */     Class<CharConvRepackage> clazz = CharConvRepackage.class;
/*     */     
/* 151 */     for (byte b = 0; b < GDK_JDBC_PACKAGE_CLASS.length; b++) {
/*     */ 
/*     */       
/* 154 */       InputStream inputStream = clazz.getResourceAsStream("/" + GDK_JDBC_PACKAGE_CLASS[b]);
/*     */       
/* 156 */       if (inputStream == null)
/*     */       {
/* 158 */         new ClassNotFoundException("/" + GDK_JDBC_PACKAGE_CLASS[b]);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     String str = paramList.get(0);
/*     */     
/* 167 */     if ("-charset".equals(str)) {
/*     */       
/* 169 */       file1 = new File("jdbc_orai18n_cs.jar");
/*     */     }
/*     */     else {
/*     */       
/* 173 */       file1 = new File(str);
/*     */       
/* 175 */       if (file1.getName().startsWith("orai18n"))
/*     */       {
/* 177 */         throw new IllegalArgumentException("You cannot specify the name for jar/zip file: " + file1
/*     */             
/* 179 */             .getName());
/*     */       }
/*     */       
/* 182 */       paramList.remove(0);
/*     */ 
/*     */       
/* 185 */       if (!"-charset".equals(paramList.get(0))) {
/*     */         
/* 187 */         printUsage();
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 193 */     paramList.remove(0);
/*     */     
/* 195 */     File file2 = File.createTempFile("gdk", null);
/* 196 */     file2.deleteOnExit();
/*     */     
/* 198 */     FileOutputStream fileOutputStream = null;
/*     */ 
/*     */     
/*     */     try {
/* 202 */       fileOutputStream = new FileOutputStream(file2);
/*     */       
/* 204 */       ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);
/*     */       byte b1;
/* 206 */       for (b1 = 0; b1 < paramList.size(); b1++) {
/*     */         
/* 208 */         String str2 = ((String)paramList.get(b1)).toUpperCase(Locale.US);
/*     */         
/* 210 */         if (UNICODE_CHARSETS.contains(str2)) {
/*     */ 
/*     */           
/* 213 */           System.out.println("Added       Character set : " + str2);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 218 */           CharsetMeta charsetMeta = CharsetMeta.getInstance();
/* 219 */           String str3 = charsetMeta.getCharSetId(str2);
/*     */           
/* 221 */           if (str3 == null)
/*     */           {
/* 223 */             throw new UnsupportedEncodingException(str2);
/*     */           }
/*     */           
/* 226 */           String str4 = Integer.toHexString(Integer.parseInt(str3));
/*     */           
/* 228 */           String str5 = "lx2" + ("0000" + str4).substring(str4.length());
/* 229 */           String str6 = "oracle/i18n/data/" + str5 + ".glb";
/*     */ 
/*     */           
/* 232 */           InputStream inputStream = clazz.getResourceAsStream("/" + str6);
/*     */           
/* 234 */           if (inputStream == null)
/*     */           {
/* 236 */             throw new UnsupportedEncodingException(str2);
/*     */           }
/*     */           
/* 239 */           ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
/* 240 */           Object object = objectInputStream.readObject();
/* 241 */           objectInputStream.close();
/* 242 */           inputStream.close();
/*     */ 
/*     */           
/* 245 */           ZipEntry zipEntry1 = new ZipEntry(str6);
/* 246 */           zipOutputStream.putNextEntry(zipEntry1);
/*     */           
/* 248 */           ObjectOutputStream objectOutputStream = new ObjectOutputStream(zipOutputStream);
/* 249 */           objectOutputStream.writeObject(object);
/* 250 */           System.out.println("Added       Character set : " + str2);
/*     */         } 
/*     */       } 
/*     */       
/* 254 */       for (b1 = 0; b1 < GDK_JDBC_PACKAGE_CLASS.length; b1++) {
/*     */         
/* 256 */         ZipEntry zipEntry1 = new ZipEntry(GDK_JDBC_PACKAGE_CLASS[b1]);
/* 257 */         zipOutputStream.putNextEntry(zipEntry1);
/*     */ 
/*     */         
/* 260 */         InputStream inputStream = clazz.getResourceAsStream("/" + GDK_JDBC_PACKAGE_CLASS[b1]);
/* 261 */         copyFile(inputStream, zipOutputStream);
/* 262 */         inputStream.close();
/*     */       } 
/*     */ 
/*     */       
/* 266 */       ZipEntry zipEntry = new ZipEntry("META-INF/MANIFEST.MF");
/* 267 */       zipOutputStream.putNextEntry(zipEntry);
/*     */       
/* 269 */       String str1 = clazz.getProtectionDomain().getCodeSource().getLocation().getPath();
/* 270 */       JarFile jarFile = new JarFile(str1);
/* 271 */       Enumeration<JarEntry> enumeration = jarFile.entries();
/* 272 */       while (enumeration.hasMoreElements()) {
/*     */         
/* 274 */         JarEntry jarEntry = enumeration.nextElement();
/* 275 */         String str2 = jarEntry.getName();
/* 276 */         if (str2.equals("META-INF/MANIFEST.MF")) {
/*     */           
/* 278 */           InputStream inputStream = jarFile.getInputStream(jarEntry);
/* 279 */           copyFile(inputStream, zipOutputStream);
/* 280 */           inputStream.close();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 286 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 287 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(byteArrayOutputStream, "iso-8859-1");
/*     */ 
/*     */       
/* 290 */       outputStreamWriter.write("\n");
/* 291 */       outputStreamWriter.write("This custom character set jar/zip file was created with the following command:\n");
/*     */       
/* 293 */       outputStreamWriter.write("java -jar orai18n.jar -custom-charsets-jar " + file1
/* 294 */           .getName() + " " + "-charset");
/*     */ 
/*     */       
/* 297 */       for (byte b2 = 0; b2 < paramList.size(); b2++) {
/*     */         
/* 299 */         String str2 = ((String)paramList.get(b2)).toUpperCase(Locale.US);
/* 300 */         outputStreamWriter.write(" ");
/* 301 */         outputStreamWriter.write(str2);
/*     */       } 
/*     */       
/* 304 */       outputStreamWriter.write("\n");
/* 305 */       outputStreamWriter.close();
/* 306 */       byteArrayOutputStream.close();
/*     */ 
/*     */       
/* 309 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/* 310 */       zipEntry = new ZipEntry("oracle/i18n/readme.txt");
/* 311 */       zipOutputStream.putNextEntry(zipEntry);
/* 312 */       copyFile(byteArrayInputStream, zipOutputStream);
/* 313 */       byteArrayInputStream.close();
/*     */ 
/*     */       
/* 316 */       zipOutputStream.close();
/* 317 */       fileOutputStream.close();
/* 318 */       fileOutputStream = null;
/*     */       
/* 320 */       if (!file2.renameTo(file1))
/*     */       {
/*     */         
/* 323 */         FileInputStream fileInputStream = new FileInputStream(file2);
/* 324 */         fileOutputStream = new FileOutputStream(file1);
/* 325 */         copyFile(fileInputStream, fileOutputStream);
/* 326 */         fileOutputStream.close();
/* 327 */         fileOutputStream = null;
/* 328 */         fileInputStream.close();
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 333 */       if (fileOutputStream != null)
/*     */       {
/* 335 */         fileOutputStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void copyFile(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
/* 343 */     byte[] arrayOfByte = new byte[8192];
/*     */     
/* 345 */     for (int i = -1; (i = paramInputStream.read(arrayOfByte)) != -1;)
/*     */     {
/* 347 */       paramOutputStream.write(arrayOfByte, 0, i);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18\\util\CharConvRepackage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
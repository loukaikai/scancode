/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetEncoder
/*     */   extends CharsetEncoder
/*     */ {
/*     */   private int maxBPC;
/*     */   
/*     */   OraCharsetEncoder(OraCharset paramOraCharset, float paramFloat1, float paramFloat2, byte[] paramArrayOfbyte) {
/*  41 */     super(paramOraCharset, paramFloat1, paramFloat2, paramArrayOfbyte);
/*  42 */     this.maxBPC = (int)Math.ceil(paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OraCharsetEncoder(OraCharset paramOraCharset, float paramFloat1, float paramFloat2) {
/*  49 */     super(paramOraCharset, paramFloat1, paramFloat2);
/*  50 */     this.maxBPC = (int)Math.ceil(paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CoderResult encodeLoop(CharBuffer paramCharBuffer, ByteBuffer paramByteBuffer) {
/*  56 */     int i = paramCharBuffer.position();
/*  57 */     int j = paramCharBuffer.remaining();
/*     */ 
/*     */     
/*  60 */     if (j == 0)
/*     */     {
/*     */       
/*  63 */       return CoderResult.UNDERFLOW;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  68 */     boolean bool = false;
/*     */     
/*  70 */     if (j * this.maxBPC > paramByteBuffer.remaining()) {
/*     */       
/*  72 */       bool = true;
/*  73 */       if (paramByteBuffer.remaining() / this.maxBPC < 1) {
/*  74 */         return CoderResult.OVERFLOW;
/*     */       }
/*  76 */       if (UTFUtility.isHiSurrogate(paramCharBuffer.charAt(paramByteBuffer.remaining() / this.maxBPC - 1)) && 
/*  77 */         UTFUtility.isLoSurrogate(paramCharBuffer.charAt(paramByteBuffer.remaining() / this.maxBPC))) {
/*  78 */         k = paramByteBuffer.remaining() / this.maxBPC - 1;
/*     */       } else {
/*  80 */         k = paramByteBuffer.remaining() / this.maxBPC;
/*     */       } 
/*     */     } else {
/*     */       
/*  84 */       k = j;
/*     */     } 
/*     */     
/*  87 */     int k = (k < j) ? k : j;
/*     */ 
/*     */     
/*  90 */     char[] arrayOfChar = new char[k];
/*  91 */     paramCharBuffer.get(arrayOfChar);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 100 */       byte[] arrayOfByte = (CodingErrorAction.REPLACE == unmappableCharacterAction()) ? ((OraCharset)charset()).convertWithReplacement(new String(arrayOfChar, 0, arrayOfChar.length)) : ((OraCharset)charset()).convert(new String(arrayOfChar, 0, arrayOfChar.length));
/*     */       
/* 102 */       if (arrayOfByte.length > paramByteBuffer.remaining()) {
/*     */         
/* 104 */         bool = true;
/* 105 */         paramCharBuffer.position(i);
/* 106 */         char[] arrayOfChar1 = new char[k - 2];
/* 107 */         paramCharBuffer.get(arrayOfChar1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 113 */         arrayOfByte = (CodingErrorAction.REPLACE == unmappableCharacterAction()) ? ((OraCharset)charset()).convertWithReplacement(new String(arrayOfChar1, 0, arrayOfChar1.length)) : ((OraCharset)charset()).convert(new String(arrayOfChar1, 0, arrayOfChar1.length));
/*     */       } 
/*     */       
/* 116 */       if (bool) {
/*     */ 
/*     */ 
/*     */         
/* 120 */         paramByteBuffer.put(arrayOfByte);
/*     */         
/* 122 */         return CoderResult.OVERFLOW;
/*     */       } 
/*     */       
/* 125 */       paramByteBuffer.put(arrayOfByte);
/*     */       
/* 127 */       return CoderResult.UNDERFLOW;
/*     */     }
/* 129 */     catch (SQLException sQLException) {
/*     */       
/* 131 */       paramCharBuffer.position(i);
/*     */       
/* 133 */       return CoderResult.unmappableForLength(j);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
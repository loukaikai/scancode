/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.io.UTFDataFormatException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.text.converter.GDKMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetUTF
/*     */   extends OraCharset
/*     */ {
/*     */   OraCharsetUTF(String paramString, int paramInt) {
/*  36 */     super(paramString, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Charset paramCharset) {
/*  42 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/*  48 */     return new OraCharsetDecoder(this, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/*  54 */     return new OraCharsetEncoder(this, 1.0F, 3.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/*  72 */       char[] arrayOfChar = new char[paramArrayOfbyte.length];
/*     */       
/*  74 */       int i = UTFToJavaChar(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPLACEMENT);
/*     */ 
/*     */ 
/*     */       
/*  78 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  80 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */ 
/*     */       
/*  83 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/* 106 */       char[] arrayOfChar = new char[paramArrayOfbyte.length];
/*     */       
/* 108 */       int i = UTFToJavaChar(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPORT_ERROR);
/*     */ 
/*     */ 
/*     */       
/* 112 */       return new String(arrayOfChar, 0, i);
/*     */     }
/* 114 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */       
/* 116 */       throw new SQLException(GDKMessage.getORAMessage(17037));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convertWithReplacement(String paramString) {
/* 131 */     char[] arrayOfChar = paramString.toCharArray();
/* 132 */     byte[] arrayOfByte1 = new byte[arrayOfChar.length * 3];
/* 133 */     int i = javaCharsToUTF(arrayOfChar, 0, arrayOfChar.length, arrayOfByte1, 0);
/* 134 */     byte[] arrayOfByte2 = new byte[i];
/* 135 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
/*     */     
/* 137 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convert(String paramString) throws SQLException {
/* 152 */     return convertWithReplacement(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetUTF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
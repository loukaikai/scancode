/*    */ package oracle.i18n.text;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OraCharsetIterator
/*    */   implements Iterator
/*    */ {
/*    */   private int capacity;
/*    */   private int current;
/*    */   private Object[] collection;
/*    */   
/*    */   OraCharsetIterator(Object[] paramArrayOfObject, int paramInt) {
/* 39 */     this.current = 0;
/* 40 */     this.capacity = paramInt;
/* 41 */     this.collection = new Object[this.capacity];
/*    */     
/* 43 */     for (byte b = 0; b < this.capacity; b++) {
/* 44 */       this.collection[b] = paramArrayOfObject[b];
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 49 */     if (this.current < this.capacity)
/*    */     {
/* 51 */       return true;
/*    */     }
/*    */     
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object next() {
/* 59 */     if (this.current < this.capacity)
/*    */     {
/* 61 */       return this.collection[this.current++];
/*    */     }
/*    */ 
/*    */     
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void remove() {
/* 72 */     System.out.println(this.current);
/* 73 */     this.collection[this.current - 1] = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void reset() {
/* 80 */     this.current = 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
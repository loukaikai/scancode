/*    */ package oracle.i18n.text;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.spi.CharsetProvider;
/*    */ import java.util.Iterator;
/*    */ import oracle.i18n.text.converter.CharsetMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OraCharsetProvider
/*    */   extends CharsetProvider
/*    */ {
/*    */   public Charset charsetForName(String paramString) {
/* 52 */     return OraCharset.getInstance(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator charsets() {
/* 63 */     String[] arrayOfString = CharsetMeta.getInstance().getAvailableCharacterSets();
/* 64 */     Object[] arrayOfObject = new Object[arrayOfString.length];
/* 65 */     byte b1 = 0;
/*    */     
/* 67 */     for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/*    */       
/* 69 */       arrayOfObject[b1] = 
/* 70 */         OraCharset.getInstance("X-ORACLE-" + arrayOfString[b2]);
/*    */ 
/*    */       
/* 73 */       if (arrayOfObject[b1] != null)
/*    */       {
/* 75 */         b1++;
/*    */       }
/*    */     } 
/*    */     
/* 79 */     return new OraCharsetIterator(arrayOfObject, b1);
/*    */   }
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
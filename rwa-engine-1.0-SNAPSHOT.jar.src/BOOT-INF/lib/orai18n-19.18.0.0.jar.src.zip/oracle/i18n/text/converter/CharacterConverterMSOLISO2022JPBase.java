/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterConverterMSOLISO2022JPBase
/*     */   extends CharacterConverter12Byte
/*     */ {
/*  39 */   protected static int MAXLIMIT = 65536;
/*     */   
/*     */   static final int BUCKETSIZE = 200;
/*     */   
/*     */   static final byte REPLACEMENT_CHAR_IN_BYTE = 63;
/*     */   
/*  45 */   static final byte[] REPLACEMENT_CHAR_IN_BYTES = new byte[] { 63 };
/*     */   
/*     */   static final int ASCII_JISROMAN = 0;
/*     */   
/*     */   static final int JISX0208 = 1;
/*     */   
/*     */   static final int JISX0212 = 2;
/*     */   static final int HALF_WIDTH_KATAKANA = 3;
/*  53 */   static final byte[] JISROMAN_ESCSEQ = new byte[] { 27, 40, 66 };
/*  54 */   static final byte[] JISX0208_ESCSEQ = new byte[] { 27, 36, 66 };
/*  55 */   static final byte[] JISX0212_ESCSEQ = new byte[] { 27, 36, 40, 68 };
/*  56 */   static final byte[] HALF_WIDTH_KATAKANA_ESCSEQ = new byte[] { 27, 40, 73 };
/*     */   
/*     */   static final int FULLWIDTH_MODE = 1;
/*     */   
/*     */   static final int HALFWIDTH_MODE = 2;
/*  61 */   public int[] m_oraCharExtraLevel1 = null;
/*  62 */   public char[] m_oraCharExtraLevel2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharacterConverterMSOLISO2022JPBase() {
/*  69 */     this.averageCharsPerByte = 1.0F;
/*  70 */     this.maxCharsPerByte = 1.0F;
/*  71 */     this.maxBytesPerChar = 10.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicode(int paramInt) throws SQLException {
/*  91 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicodeWithReplacement(int paramInt) {
/*     */     int k;
/* 105 */     if (paramInt >= 0 && paramInt <= 127) {
/* 106 */       return paramInt;
/*     */     }
/*     */ 
/*     */     
/* 110 */     int i = paramInt >> 8 & 0xFF;
/* 111 */     int j = paramInt & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1) {
/*     */       
/* 118 */       k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*     */     } else {
/* 120 */       k = this.m_ucsCharReplacement;
/*     */     } 
/* 122 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/* 148 */       return toUnicodeStringMain(paramArrayOfbyte, paramInt1, paramInt2, CharacterConverterBehavior.REPORT_ERROR);
/*     */     }
/* 150 */     catch (Exception exception) {
/*     */       
/* 152 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/* 174 */       return toUnicodeStringMain(paramArrayOfbyte, paramInt1, paramInt2, CharacterConverterBehavior.REPLACEMENT);
/*     */     }
/* 176 */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       char[] arrayOfChar = { (char)this.m_ucsCharReplacement };
/* 183 */       return new String(arrayOfChar);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String toUnicodeStringMain(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, CharacterConverterBehavior paramCharacterConverterBehavior) throws SQLException {
/* 190 */     int i = paramInt1;
/* 191 */     int j = paramInt1;
/* 192 */     boolean bool1 = false;
/* 193 */     boolean bool2 = false, bool3 = false, bool4 = false;
/* 194 */     boolean bool5 = false;
/*     */     
/* 196 */     String str = new String("");
/*     */ 
/*     */     
/* 199 */     j = getNextEscpSeq(paramArrayOfbyte, i);
/*     */     
/* 201 */     if (j == -1) {
/*     */       
/* 203 */       str = str + toUnicodeChars(paramArrayOfbyte, 0, paramArrayOfbyte.length - 1, 0, paramCharacterConverterBehavior);
/* 204 */       bool5 = true;
/*     */     }
/* 206 */     else if (j != 0) {
/* 207 */       str = str + toUnicodeChars(paramArrayOfbyte, 0, j - 1, 0, paramCharacterConverterBehavior);
/*     */     } 
/* 209 */     while (!bool5) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 214 */       i = j;
/* 215 */       j = getNextEscpSeq(paramArrayOfbyte, j + 1);
/*     */ 
/*     */       
/* 218 */       if (j == -1) {
/*     */         
/* 220 */         j = paramArrayOfbyte.length;
/* 221 */         bool5 = true;
/*     */       } 
/*     */       
/* 224 */       int k = checkEscpSeq(paramArrayOfbyte, i);
/*     */       
/* 226 */       if (k == 0 || k == 1 || k == 3) {
/*     */         
/* 228 */         if (i + 3 != j)
/* 229 */           str = str + toUnicodeChars(paramArrayOfbyte, i + 3, j - 1, k, paramCharacterConverterBehavior); 
/*     */         continue;
/*     */       } 
/* 232 */       if (k == 2) {
/*     */         
/* 234 */         if (i + 4 != j) {
/* 235 */           str = str + toUnicodeChars(paramArrayOfbyte, i + 4, j - 1, k, paramCharacterConverterBehavior);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 241 */       paramCharacterConverterBehavior.onFailConversion(i);
/*     */     } 
/*     */     
/* 244 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toUnicodeChars(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, CharacterConverterBehavior paramCharacterConverterBehavior) throws SQLException {
/* 252 */     String str = new String("");
/*     */ 
/*     */     
/* 255 */     if (paramInt2 < paramInt1) {
/* 256 */       throw new SQLException();
/*     */     }
/* 258 */     if (paramInt3 == 0)
/*     */     {
/* 260 */       return new String(paramArrayOfbyte, paramInt1, paramInt2 - paramInt1 + 1);
/*     */     }
/* 262 */     if (paramInt3 == 1 || paramInt3 == 2) {
/*     */       
/* 264 */       for (int i = paramInt1; i < paramInt2; i += 2)
/*     */       {
/*     */         
/* 267 */         int m, j = paramArrayOfbyte[i] & 0xFF;
/* 268 */         int k = paramArrayOfbyte[i + 1] & 0xFF;
/*     */ 
/*     */         
/* 271 */         if (this.m_ucsCharLevel1[j] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[j] + k] != -1) {
/*     */ 
/*     */           
/* 274 */           m = this.m_ucsCharLevel2[this.m_ucsCharLevel1[j] + k];
/*     */         }
/*     */         else {
/*     */           
/* 278 */           m = this.m_ucsCharReplacement;
/*     */         } 
/* 280 */         str = str + new String(new char[] { (char)m });
/*     */       }
/*     */     
/* 283 */     } else if (paramInt3 == 3) {
/*     */       
/* 285 */       for (int i = paramInt1; i <= paramInt2; i++) {
/*     */         int k;
/*     */         
/* 288 */         boolean bool = false;
/* 289 */         int j = paramArrayOfbyte[i] & 0xFF;
/*     */ 
/*     */         
/* 292 */         if (this.m_ucsCharLevel1[bool] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[bool] + j] != -1) {
/*     */ 
/*     */           
/* 295 */           k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[bool] + j];
/*     */         }
/*     */         else {
/*     */           
/* 299 */           k = this.m_ucsCharReplacement;
/*     */         } 
/* 301 */         str = str + new String(new char[] { (char)k });
/*     */       } 
/*     */     } 
/* 304 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleString(String paramString) throws SQLException {
/* 322 */     int[] arrayOfInt = new int[1];
/* 323 */     arrayOfInt[0] = paramString.length();
/*     */     
/* 325 */     if (arrayOfInt[0] == 0)
/*     */     {
/* 327 */       return new byte[0];
/*     */     }
/*     */     
/* 330 */     char[] arrayOfChar = new char[arrayOfInt[0]];
/* 331 */     paramString.getChars(0, arrayOfInt[0], arrayOfChar, 0);
/*     */     
/* 333 */     return toISO2022JPStringMain(arrayOfChar, 0, (byte[])null, 0, arrayOfInt, CharacterConverterBehavior.REPORT_ERROR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*     */     try {
/* 363 */       return toISO2022JPStringMain(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramArrayOfint, CharacterConverterBehavior.REPLACEMENT);
/*     */ 
/*     */     
/*     */     }
/* 367 */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */       
/* 371 */       return new byte[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] toISO2022JPStringMain(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint, CharacterConverterBehavior paramCharacterConverterBehavior) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toISO2022JPStringFWHW(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint, CharacterConverterBehavior paramCharacterConverterBehavior, int paramInt3) throws SQLException {
/*     */     byte[] arrayOfByte2;
/* 388 */     int i = paramArrayOfint[0];
/* 389 */     int j = paramInt1 + i;
/* 390 */     ArrayList<byte[]> arrayList = new ArrayList(0);
/* 391 */     byte b1 = 0;
/* 392 */     byte b2 = 0;
/* 393 */     int k = 0;
/*     */     
/* 395 */     byte[] arrayOfByte1 = new byte[200];
/* 396 */     arrayList.add(arrayOfByte1);
/*     */     
/* 398 */     for (int m = paramInt1; m < j; m++) {
/*     */       
/* 400 */       if (paramArrayOfchar[m] >= '\000' && paramArrayOfchar[m] <= '') {
/*     */         
/* 402 */         if (b1) {
/*     */           
/* 404 */           b1 = 0;
/* 405 */           k = insertEscSeq(k, arrayList, b1);
/* 406 */           b2 += true;
/*     */         } 
/*     */         
/* 409 */         k = insertToBucket(k, arrayList, new byte[] { (byte)paramArrayOfchar[m] });
/*     */         
/* 411 */         b2++;
/*     */       
/*     */       }
/* 414 */       else if (paramArrayOfchar[m] >= '¡' && paramArrayOfchar[m] <= 'ÿ') {
/*     */ 
/*     */         
/* 417 */         int i1 = paramArrayOfchar[m] >> 8 & 0xFF;
/* 418 */         int i2 = paramArrayOfchar[m] & 0xFF;
/*     */ 
/*     */         
/* 421 */         if (this.m_oraCharExtraLevel1[i1] != -1 && this.m_oraCharExtraLevel2[this.m_oraCharExtraLevel1[i1] + i2] != Character.MAX_VALUE)
/*     */         {
/*     */           
/* 424 */           char c = this.m_oraCharExtraLevel2[this.m_oraCharExtraLevel1[i1] + i2];
/*     */ 
/*     */           
/* 427 */           if ((char)(c & 0xFF) == c)
/*     */           {
/* 429 */             if (b1) {
/*     */               
/* 431 */               b1 = 0;
/* 432 */               k = insertEscSeq(k, arrayList, b1);
/* 433 */               b2 += 3;
/*     */             } 
/*     */             
/* 436 */             k = insertToBucket(k, arrayList, new byte[] { (byte)(c & 0xFF) });
/*     */             
/* 438 */             b2++;
/*     */           }
/*     */           else
/*     */           {
/* 442 */             if (b1 != 1) {
/*     */               
/* 444 */               b1 = 1;
/* 445 */               k = insertEscSeq(k, arrayList, b1);
/* 446 */               b2 += 3;
/*     */             } 
/*     */             
/* 449 */             k = insertToBucket(k, arrayList, new byte[] { (byte)(c >> 8 & 0xFF), (byte)(c & 0xFF) });
/*     */             
/* 451 */             b2 += 2;
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 458 */         int i1 = paramArrayOfchar[m] >> 8 & 0xFF;
/* 459 */         int i2 = paramArrayOfchar[m] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 469 */         if (this.m_oraCharExtraLevel1[i1] != -1 && this.m_oraCharExtraLevel2[this.m_oraCharExtraLevel1[i1] + i2] != Character.MAX_VALUE) {
/*     */ 
/*     */           
/* 472 */           if (paramInt3 == 1)
/*     */           {
/* 474 */             if (b1 != 1) {
/*     */               
/* 476 */               b1 = 1;
/* 477 */               k = insertEscSeq(k, arrayList, b1);
/* 478 */               b2 += 3;
/*     */             } 
/* 480 */             char c = this.m_oraCharExtraLevel2[this.m_oraCharExtraLevel1[i1] + i2];
/*     */             
/* 482 */             k = insertToBucket(k, arrayList, new byte[] { (byte)(c >> 8 & 0xFF), (byte)(c & 0xFF) });
/*     */             
/* 484 */             b2 += 2;
/*     */           }
/*     */           else
/*     */           {
/* 488 */             if (b1 != 3) {
/*     */               
/* 490 */               b1 = 3;
/* 491 */               k = insertEscSeq(k, arrayList, b1);
/* 492 */               b2 += 3;
/*     */             } 
/* 494 */             char c = this.m_oraCharExtraLevel2[this.m_oraCharExtraLevel1[i1] + i2];
/*     */             
/* 496 */             k = insertToBucket(k, arrayList, new byte[] { (byte)(c & 0xFF) });
/*     */             
/* 498 */             b2++;
/*     */           }
/*     */         
/* 501 */         } else if (this.m_oraCharLevel1[i1] != -1 && this.m_oraCharLevel2[this.m_oraCharLevel1[i1] + i2] != Character.MAX_VALUE) {
/*     */ 
/*     */           
/* 504 */           if (b1 != 1) {
/*     */             
/* 506 */             b1 = 1;
/* 507 */             k = insertEscSeq(k, arrayList, b1);
/* 508 */             b2 += 3;
/*     */           } 
/* 510 */           char c = this.m_oraCharLevel2[this.m_oraCharLevel1[i1] + i2];
/*     */           
/* 512 */           k = insertToBucket(k, arrayList, new byte[] { (byte)(c >> 8 & 0xFF), (byte)(c & 0xFF) });
/*     */ 
/*     */           
/* 515 */           b2 += 2;
/*     */ 
/*     */         
/*     */         }
/* 519 */         else if (paramCharacterConverterBehavior == CharacterConverterBehavior.REPLACEMENT) {
/*     */           
/* 521 */           if (b1 != 0) {
/*     */             
/* 523 */             b1 = 0;
/* 524 */             k = insertEscSeq(k, arrayList, b1);
/* 525 */             b2 += 3;
/*     */           } 
/* 527 */           char c = this.m_1ByteOraCharReplacement;
/*     */           
/* 529 */           k = insertToBucket(k, arrayList, new byte[] { 63 });
/*     */           
/* 531 */           b2++;
/*     */         }
/*     */         else {
/*     */           
/* 535 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 545 */     if (b1 != 0) {
/* 546 */       k = insertEscSeq(k, arrayList, 0);
/* 547 */       b2 += 3;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 553 */     if (paramArrayOfbyte != null) {
/*     */       
/* 555 */       arrayOfByte2 = paramArrayOfbyte;
/*     */     }
/*     */     else {
/*     */       
/* 559 */       arrayOfByte2 = new byte[b2];
/* 560 */       paramInt2 = 0;
/*     */     } 
/*     */     
/* 563 */     byte b3 = 0; int n = paramInt2;
/* 564 */     for (byte b4 = 0; b4 < arrayList.size(); b4++) {
/*     */       
/* 566 */       byte b = ((b2 - n) / 200 > 0) ? 200 : (b2 % 200);
/* 567 */       for (b3 = 0; b3 < b; b3++, n++)
/*     */       {
/* 569 */         arrayOfByte2[n] = ((byte[])arrayList.get(b4))[b3];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 574 */     paramArrayOfint[0] = b2;
/*     */     
/* 576 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildUnicodeToOracleMapping() {
/* 610 */     this.m_oraCharLevel1 = new int[256];
/* 611 */     this.m_oraCharExtraLevel1 = new int[256];
/*     */     
/* 613 */     char[] arrayOfChar = new char[MAXLIMIT];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 624 */     byte b1 = 0;
/* 625 */     int[][] arrayOfInt = new int[MAXLIMIT][2];
/*     */     
/* 627 */     byte b2 = 0;
/*     */     byte b3;
/* 629 */     for (b3 = 0; b3 < 'Ā'; b3++)
/*     */     {
/* 631 */       this.m_oraCharLevel1[b3] = -1;
/*     */     }
/*     */     
/* 634 */     for (b3 = 0; b3 < MAXLIMIT; b3++)
/*     */     {
/* 636 */       arrayOfChar[b3] = Character.MAX_VALUE;
/*     */     }
/*     */     
/* 639 */     for (b3 = 0; b3 < '￿'; b3++) {
/*     */ 
/*     */       
/* 642 */       int i = toUnicodeWithReplacement(b3);
/* 643 */       if (i != this.m_ucsCharReplacement) {
/* 644 */         arrayOfInt[b2][0] = i;
/* 645 */         arrayOfInt[b2][1] = b3;
/* 646 */         b2++;
/*     */       } 
/*     */     } 
/*     */     
/* 650 */     for (b3 = 0; b3 < arrayOfInt.length; b3++) {
/*     */       
/* 652 */       int i = arrayOfInt[b3][0] >>> 8 & 0xFF;
/* 653 */       int j = arrayOfInt[b3][0] & 0xFF;
/*     */       
/* 655 */       if (this.m_oraCharLevel1[i] == -1) {
/*     */         
/* 657 */         this.m_oraCharLevel1[i] = b1;
/* 658 */         b1 += true;
/*     */       } 
/*     */       
/* 661 */       if (arrayOfChar[this.m_oraCharLevel1[i] + j] == Character.MAX_VALUE)
/*     */       {
/* 663 */         arrayOfChar[this.m_oraCharLevel1[i] + j] = (char)(arrayOfInt[b3][1] & 0xFFFF);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 672 */     this.m_oraCharLevel2 = new char[b1];
/*     */     
/* 674 */     for (b3 = 0; b3 < b1; b3++)
/*     */     {
/* 676 */       this.m_oraCharLevel2[b3] = arrayOfChar[b3];
/*     */     }
/*     */ 
/*     */     
/* 680 */     if (this.extraUnicodeToOracleMapping != null) {
/*     */ 
/*     */       
/* 683 */       b1 = 0;
/* 684 */       for (b3 = 0; b3 < 'Ā'; b3++)
/*     */       {
/* 686 */         this.m_oraCharExtraLevel1[b3] = -1;
/*     */       }
/* 688 */       for (b3 = 0; b3 < MAXLIMIT; b3++)
/*     */       {
/* 690 */         arrayOfChar[b3] = Character.MAX_VALUE;
/*     */       }
/*     */       
/* 693 */       int i = this.extraUnicodeToOracleMapping.length;
/*     */       
/* 695 */       for (b3 = 0; b3 < i; b3++) {
/*     */ 
/*     */         
/* 698 */         int m = this.extraUnicodeToOracleMapping[b3][0];
/* 699 */         int n = this.extraUnicodeToOracleMapping[b3][1];
/*     */ 
/*     */ 
/*     */         
/* 703 */         int j = m >>> 8 & 0xFF;
/* 704 */         int k = m & 0xFF;
/*     */         
/* 706 */         if (this.m_oraCharExtraLevel1[j] == -1) {
/*     */           
/* 708 */           this.m_oraCharExtraLevel1[j] = b1;
/* 709 */           b1 += 256;
/*     */         } 
/*     */         
/* 712 */         if (arrayOfChar[this.m_oraCharExtraLevel1[j] + k] == Character.MAX_VALUE)
/*     */         {
/*     */ 
/*     */           
/* 716 */           arrayOfChar[this.m_oraCharExtraLevel1[j] + k] = (char)n;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 724 */       this.m_oraCharExtraLevel2 = new char[b1];
/*     */       
/* 726 */       for (b3 = 0; b3 < b1; b3++)
/*     */       {
/* 728 */         this.m_oraCharExtraLevel2[b3] = arrayOfChar[b3];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExtraMappings() {
/* 739 */     return (this.extraUnicodeToOracleMapping != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char getOraChar1ByteRep() {
/* 745 */     return this.m_1ByteOraCharReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char getOraChar2ByteRep() {
/* 751 */     return this.m_2ByteOraCharReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUCS2CharRep() {
/* 757 */     return this.m_ucsCharReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int insertToBucket(int paramInt, ArrayList<byte[]> paramArrayList, byte[] paramArrayOfbyte) {
/* 765 */     if (paramInt + paramArrayOfbyte.length - 1 >= 200) {
/*     */       
/* 767 */       for (byte b = 0; b < paramArrayOfbyte.length; b++, paramInt++)
/*     */       {
/* 769 */         if (paramInt >= 200) {
/*     */           
/* 771 */           byte[] arrayOfByte = new byte[200];
/* 772 */           paramArrayList.add(arrayOfByte);
/* 773 */           paramInt = 0;
/*     */         } 
/* 775 */         ((byte[])paramArrayList.get(paramArrayList.size() - 1))[paramInt] = paramArrayOfbyte[b];
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 780 */       for (byte b = 0; b < paramArrayOfbyte.length; b++, paramInt++)
/*     */       {
/* 782 */         ((byte[])paramArrayList.get(paramArrayList.size() - 1))[paramInt] = paramArrayOfbyte[b];
/*     */       }
/*     */     } 
/* 785 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int checkEscpSeq(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/* 794 */     if (paramInt + 2 >= paramArrayOfbyte.length) {
/* 795 */       return -1;
/*     */     }
/* 797 */     if (paramArrayOfbyte[paramInt + 1] == 40) {
/*     */ 
/*     */       
/* 800 */       if (paramArrayOfbyte[paramInt + 2] == 66 || paramArrayOfbyte[paramInt + 2] == 74)
/* 801 */         return 0; 
/* 802 */       if (paramArrayOfbyte[paramInt + 2] == 73) {
/* 803 */         return 3;
/*     */       }
/* 805 */     } else if (paramArrayOfbyte[paramInt + 1] == 36) {
/*     */ 
/*     */       
/* 808 */       if (paramArrayOfbyte[paramInt + 2] == 64 || paramArrayOfbyte[paramInt + 2] == 66) {
/* 809 */         return 1;
/*     */       }
/* 811 */       if (paramArrayOfbyte[paramInt + 2] == 40 && paramArrayOfbyte[paramInt + 3] == 68)
/* 812 */         return 2; 
/*     */     } 
/* 814 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int insertEscSeq(int paramInt1, ArrayList paramArrayList, int paramInt2) {
/* 820 */     byte[] arrayOfByte = null;
/* 821 */     if (paramInt2 == 0) {
/* 822 */       arrayOfByte = JISROMAN_ESCSEQ;
/* 823 */     } else if (paramInt2 == 1) {
/* 824 */       arrayOfByte = JISX0208_ESCSEQ;
/* 825 */     } else if (paramInt2 == 2) {
/* 826 */       arrayOfByte = JISX0212_ESCSEQ;
/* 827 */     } else if (paramInt2 == 3) {
/* 828 */       arrayOfByte = HALF_WIDTH_KATAKANA_ESCSEQ;
/*     */     } 
/* 830 */     return insertToBucket(paramInt1, paramArrayList, arrayOfByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getNextEscpSeq(byte[] paramArrayOfbyte, int paramInt) {
/* 837 */     for (; paramInt < paramArrayOfbyte.length; paramInt++) {
/*     */       
/* 839 */       if (paramArrayOfbyte[paramInt] == 27)
/* 840 */         return paramInt; 
/*     */     } 
/* 842 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class CharacterConverterBehavior
/*     */   {
/* 857 */     public static final CharacterConverterBehavior REPORT_ERROR = new CharacterConverterBehavior()
/*     */       {
/*     */         
/*     */         public void onFailConversion(int param2Int) throws SQLException
/*     */         {
/* 862 */           throw new SQLException();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 867 */     public static final CharacterConverterBehavior REPLACEMENT = new CharacterConverterBehavior() {
/*     */         public void onFailConversion(int param2Int) throws SQLException {}
/*     */       };
/*     */     
/*     */     public abstract void onFailConversion(int param1Int) throws SQLException;
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterMSOLISO2022JPBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*      */ package oracle.i18n.text.converter;
/*      */ 
/*      */ import java.io.CharConversionException;
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import oracle.i18n.util.GDKOracleMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CharacterConverter12Byte
/*      */   extends CharacterConverterOGS
/*      */ {
/*  123 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*      */   static final int ORACHARMASK = 255;
/*      */   static final int UCSCHARWIDTH = 16;
/*      */   static final int ORACHARWIDTH = 16;
/*      */   static final int BYTEWIDTH = 8;
/*      */   static final short MAX_7BIT = 127;
/*  129 */   protected static int MAXLIMIT = 42000;
/*  130 */   public char[] m_ucsCharLevel1 = null;
/*  131 */   public int[] m_ucsCharLevel2 = null;
/*  132 */   public int m_ucsCharReplacement = 0;
/*      */ 
/*      */   
/*  135 */   public char[] m_displayWidthLevel1 = null;
/*  136 */   public byte[] m_displayWidthLevel2 = null;
/*      */ 
/*      */   
/*  139 */   public int[] m_oraCharLevel1 = null;
/*  140 */   public int[] m_oraCharSurrogateLevel = null;
/*  141 */   public char[] m_oraCharLevel2 = null;
/*  142 */   public char m_1ByteOraCharReplacement = Character.MIN_VALUE;
/*  143 */   public char m_2ByteOraCharReplacement = Character.MIN_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterConverter12Byte() {
/*  150 */     this.m_groupId = 1;
/*  151 */     this.averageCharsPerByte = 1.0F;
/*  152 */     this.maxCharsPerByte = 1.0F;
/*  153 */     this.maxBytesPerChar = 2.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int toUnicode(int paramInt) throws SQLException {
/*  170 */     int k, i = paramInt >> 8 & 0xFF;
/*  171 */     int j = paramInt & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  176 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1) {
/*      */ 
/*      */       
/*  179 */       k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*      */     }
/*      */     else {
/*      */       
/*  183 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*      */     } 
/*      */ 
/*      */     
/*  187 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int toUnicodeWithReplacement(int paramInt) {
/*  198 */     int k, i = paramInt >> 8 & 0xFF;
/*  199 */     int j = paramInt & 0xFF;
/*      */ 
/*      */     
/*  202 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1) {
/*      */ 
/*      */       
/*  205 */       k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*      */     }
/*      */     else {
/*      */       
/*  209 */       k = this.m_ucsCharReplacement;
/*      */     } 
/*      */     
/*  212 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int toUnicodeNoException(int paramInt) {
/*  224 */     int i = paramInt >> 8 & 0xFF;
/*  225 */     int j = paramInt & 0xFF;
/*      */     
/*  227 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE)
/*      */     {
/*  229 */       return this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*      */     }
/*      */     
/*  232 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDisplayWidth(int paramInt, boolean paramBoolean) throws UnsupportedEncodingException, SQLException {
/*  250 */     char c, arrayOfChar[] = parseUnicodeCodePoint(paramInt);
/*      */     
/*  252 */     if (paramBoolean) {
/*  253 */       c = toOracleCharacterWithReplacement(arrayOfChar[0], arrayOfChar[1]);
/*      */     } else {
/*  255 */       c = toOracleCharacter(arrayOfChar[0], arrayOfChar[1]);
/*      */     } 
/*  257 */     if (this.m_displayWidthLevel1 == null || this.m_displayWidthLevel2 == null) {
/*  258 */       return getDefaultDisplayWidth(c);
/*      */     }
/*      */ 
/*      */     
/*  262 */     int i = c >> 8 & 0xFF;
/*  263 */     int j = c & 0xFF;
/*      */     
/*  265 */     if (this.m_displayWidthLevel1[i] != Character.MAX_VALUE) {
/*  266 */       byte b = this.m_displayWidthLevel2[this.m_displayWidthLevel1[i] + j];
/*  267 */       if (b != -1) {
/*  268 */         return b;
/*      */       }
/*      */     } 
/*  271 */     return getDefaultDisplayWidth(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   char toOracleCharacter(char paramChar1, char paramChar2) throws SQLException {
/*  285 */     char c = '￿';
/*      */     
/*  287 */     if (paramChar2 != '\000') {
/*      */ 
/*      */       
/*  290 */       int i = paramChar1 >>> 8 & 0xFF;
/*  291 */       int j = paramChar1 & 0xFF;
/*  292 */       int k = paramChar2 >>> 8 & 0xFF;
/*  293 */       int m = paramChar2 & 0xFF;
/*      */       
/*  295 */       if (this.m_oraCharLevel1[i] != -1 && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] != -1 && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] != -1 && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m] != Character.MAX_VALUE)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  300 */         c = this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m];
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  306 */       int i = paramChar1 >>> 8 & 0xFF;
/*  307 */       int j = paramChar1 & 0xFF;
/*      */       
/*  309 */       if (this.m_oraCharLevel1[i] != -1 && this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j] != Character.MAX_VALUE)
/*      */       {
/*      */         
/*  312 */         c = this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j];
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  317 */     if (c == '￿')
/*      */     {
/*  319 */       throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*      */     }
/*      */ 
/*      */     
/*  323 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   char toOracleCharacterWithReplacement(char paramChar1, char paramChar2) {
/*  335 */     char c = '￿';
/*      */     
/*  337 */     if (paramChar2 != '\000') {
/*      */ 
/*      */       
/*  340 */       int i = paramChar1 >>> 8 & 0xFF;
/*  341 */       int j = paramChar1 & 0xFF;
/*  342 */       int k = paramChar2 >>> 8 & 0xFF;
/*  343 */       int m = paramChar2 & 0xFF;
/*      */       
/*  345 */       if (this.m_oraCharLevel1[i] != -1 && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] != -1 && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] != -1 && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m] != Character.MAX_VALUE)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  350 */         c = this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m];
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  356 */       int i = paramChar1 >>> 8 & 0xFF;
/*  357 */       int j = paramChar1 & 0xFF;
/*      */       
/*  359 */       if (this.m_oraCharLevel1[i] != -1 && this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j] != Character.MAX_VALUE)
/*      */       {
/*      */         
/*  362 */         c = this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j];
/*      */       }
/*      */     } 
/*      */     
/*  366 */     if (c == '￿') {
/*      */       
/*  368 */       if (paramChar1 > '⿿')
/*      */       {
/*  370 */         return this.m_2ByteOraCharReplacement;
/*      */       }
/*      */ 
/*      */       
/*  374 */       return this.m_1ByteOraCharReplacement;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  379 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  397 */     int i = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */     
/*  401 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  402 */     byte b = 0;
/*  403 */     int j = paramInt1;
/*      */ 
/*      */ 
/*      */     
/*  407 */     while (j < i) {
/*      */ 
/*      */       
/*  410 */       int k = paramArrayOfbyte[j] & 0xFF;
/*      */       
/*  412 */       if (k > 127)
/*      */       {
/*      */ 
/*      */         
/*  416 */         if (j < i - 1) {
/*      */           
/*  418 */           k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*      */           
/*  420 */           j++;
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/*  428 */           throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  435 */       int m = toUnicode(k);
/*      */       
/*  437 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*      */         
/*  439 */         arrayOfChar[b++] = (char)(m >>> 16);
/*  440 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*      */       }
/*      */       else {
/*      */         
/*  444 */         arrayOfChar[b++] = (char)m;
/*      */       } 
/*      */       
/*  447 */       j++;
/*      */     } 
/*      */     
/*  450 */     return new String(arrayOfChar, 0, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  462 */     int i = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */     
/*  466 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  467 */     byte b = 0;
/*  468 */     int j = paramInt1;
/*      */ 
/*      */ 
/*      */     
/*  472 */     while (j < i) {
/*      */ 
/*      */       
/*  475 */       int k = paramArrayOfbyte[j] & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  481 */       if (k > 127) {
/*      */         
/*  483 */         if (i - j < 2) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  491 */         k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*      */         
/*  493 */         j++;
/*      */       } 
/*      */ 
/*      */       
/*  497 */       int m = toUnicodeWithReplacement(k);
/*      */       
/*  499 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*      */         
/*  501 */         arrayOfChar[b++] = (char)(m >>> 16);
/*  502 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*      */       }
/*      */       else {
/*      */         
/*  506 */         arrayOfChar[b++] = (char)m;
/*      */       } 
/*      */       
/*  509 */       j++;
/*      */     } 
/*      */     
/*  512 */     return new String(arrayOfChar, 0, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toOracleString(String paramString) throws SQLException {
/*  524 */     int i = paramString.length();
/*      */     
/*  526 */     if (i == 0)
/*      */     {
/*  528 */       return new byte[0];
/*      */     }
/*      */     
/*  531 */     char[] arrayOfChar = new char[i];
/*  532 */     paramString.getChars(0, i, arrayOfChar, 0);
/*      */     
/*  534 */     byte[] arrayOfByte = new byte[i * 4];
/*      */ 
/*      */     
/*  537 */     byte b1 = 0;
/*      */     
/*  539 */     for (byte b2 = 0; b2 < i; b2++) {
/*      */       char c;
/*  541 */       if (arrayOfChar[b2] >= '?' && arrayOfChar[b2] < '?') {
/*      */         
/*  543 */         if (b2 + 1 < i && arrayOfChar[b2 + 1] >= '?' && arrayOfChar[b2 + 1] <= '?')
/*      */         {
/*      */ 
/*      */           
/*  547 */           c = toOracleCharacterWithReplacement(arrayOfChar[b2], arrayOfChar[b2 + 1]);
/*      */           
/*  549 */           b2++;
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*  554 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  559 */         c = toOracleCharacter(arrayOfChar[b2], false);
/*      */       } 
/*      */       
/*  562 */       if (c >> 8 != 0) {
/*      */         
/*  564 */         arrayOfByte[b1++] = (byte)(c >> 8);
/*  565 */         arrayOfByte[b1++] = (byte)c;
/*      */       }
/*      */       else {
/*      */         
/*  569 */         arrayOfByte[b1++] = (byte)c;
/*      */       } 
/*      */     } 
/*      */     
/*  573 */     if (b1 < arrayOfByte.length) {
/*      */ 
/*      */       
/*  576 */       byte[] arrayOfByte1 = new byte[b1];
/*  577 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*      */       
/*  579 */       return arrayOfByte1;
/*      */     } 
/*      */ 
/*      */     
/*  583 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*      */     byte[] arrayOfByte;
/*      */     byte b;
/*  611 */     int i = paramArrayOfint[0];
/*      */ 
/*      */ 
/*      */     
/*  615 */     char c = '￿';
/*  616 */     int j = paramInt1 + i;
/*      */ 
/*      */     
/*  619 */     if (paramArrayOfbyte != null) {
/*      */       
/*  621 */       arrayOfByte = paramArrayOfbyte;
/*  622 */       b = paramInt2;
/*      */     }
/*      */     else {
/*      */       
/*  626 */       arrayOfByte = new byte[i * 4];
/*  627 */       b = 0;
/*  628 */       paramInt2 = 0;
/*      */     } 
/*      */     
/*  631 */     int k = paramInt1; while (true) { if (k < j) {
/*      */         
/*  633 */         if (paramArrayOfchar[k] >= '?' && paramArrayOfchar[k] < '?') {
/*      */           
/*  635 */           if (k + 1 < j && paramArrayOfchar[k + 1] >= '?' && paramArrayOfchar[k + 1] <= '?') {
/*      */ 
/*      */ 
/*      */             
/*  639 */             c = toOracleCharacterWithReplacement(paramArrayOfchar[k], paramArrayOfchar[k + 1]);
/*      */             
/*  641 */             k++;
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  646 */             arrayOfByte[b++] = (byte)(this.m_2ByteOraCharReplacement >> 8);
/*  647 */             arrayOfByte[b++] = (byte)this.m_2ByteOraCharReplacement;
/*      */ 
/*      */ 
/*      */             
/*      */             k++;
/*      */           } 
/*      */         } else {
/*  654 */           c = toOracleCharacterWithReplacement(paramArrayOfchar[k], false);
/*      */         } 
/*      */         
/*  657 */         if (c >> 8 != 0) {
/*      */           
/*  659 */           arrayOfByte[b++] = (byte)(c >> 8);
/*  660 */           arrayOfByte[b++] = (byte)c;
/*      */         }
/*      */         else {
/*      */           
/*  664 */           arrayOfByte[b++] = (byte)c;
/*      */         } 
/*      */       } else {
/*      */         break;
/*      */       }  k++; }
/*  669 */      paramArrayOfint[0] = b - paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  676 */     if (paramArrayOfbyte == null && b < arrayOfByte.length) {
/*      */       
/*  678 */       byte[] arrayOfByte1 = new byte[b];
/*  679 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b);
/*      */       
/*  681 */       return arrayOfByte1;
/*      */     } 
/*      */ 
/*      */     
/*  685 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isOraCharacterReplacement(char paramChar1, char paramChar2) {
/*  691 */     char c = toOracleCharacterWithReplacement(paramChar1, paramChar2);
/*      */     
/*  693 */     return (c == getOraChar1ByteRep() || c == 
/*  694 */       getOraChar2ByteRep());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void buildUnicodeToOracleMapping() {
/*  732 */     this.m_oraCharLevel1 = new int[256];
/*  733 */     this.m_oraCharSurrogateLevel = null;
/*  734 */     this.m_oraCharLevel2 = null;
/*      */     
/*  736 */     Vector<int[]> vector = new Vector(45055, 12287);
/*  737 */     Hashtable<Object, Object> hashtable1 = new Hashtable<Object, Object>();
/*  738 */     Hashtable<Object, Object> hashtable2 = new Hashtable<Object, Object>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  752 */     boolean bool1 = false;
/*  753 */     boolean bool2 = false;
/*      */     
/*      */     byte b1;
/*  756 */     for (b1 = 0; b1 < 'Ā'; b1++)
/*      */     {
/*  758 */       this.m_oraCharLevel1[b1] = -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  767 */     for (b1 = 0; b1 < '￿'; b1++) {
/*      */       int i;
/*  769 */       if ((i = toUnicodeNoException(b1)) != -1) {
/*      */         
/*  771 */         int[] arrayOfInt = new int[2];
/*  772 */         arrayOfInt[0] = i;
/*  773 */         arrayOfInt[1] = b1;
/*  774 */         vector.addElement(arrayOfInt);
/*  775 */         storeMappingRange(i, hashtable1, hashtable2);
/*      */       } 
/*      */     } 
/*      */     
/*  779 */     if (this.extraUnicodeToOracleMapping != null) {
/*      */       
/*  781 */       int i = this.extraUnicodeToOracleMapping.length;
/*      */       
/*  783 */       for (b1 = 0; b1 < i; b1++) {
/*      */         
/*  785 */         int j = this.extraUnicodeToOracleMapping[b1][0];
/*  786 */         storeMappingRange(j, hashtable1, hashtable2);
/*      */       } 
/*      */     } 
/*      */     
/*  790 */     Enumeration<Object> enumeration = hashtable1.keys();
/*      */ 
/*      */     
/*  793 */     byte b2 = 0;
/*  794 */     byte b3 = 0;
/*      */     
/*  796 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  798 */       Object object = enumeration.nextElement();
/*  799 */       char[] arrayOfChar = (char[])hashtable1.get(object);
/*      */       
/*  801 */       if (arrayOfChar != null)
/*      */       {
/*      */         
/*  804 */         b2 += true;
/*      */       }
/*      */     } 
/*      */     
/*  808 */     enumeration = hashtable2.keys();
/*      */     
/*  810 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  812 */       Object object = enumeration.nextElement();
/*  813 */       char[] arrayOfChar = (char[])hashtable2.get(object);
/*      */       
/*  815 */       if (arrayOfChar != null)
/*      */       {
/*      */         
/*  818 */         b3 += true;
/*      */       }
/*      */     } 
/*      */     
/*  822 */     if (b2)
/*      */     {
/*  824 */       this.m_oraCharSurrogateLevel = new int[b2];
/*      */     }
/*      */     
/*  827 */     if (b3)
/*      */     {
/*  829 */       this.m_oraCharLevel2 = new char[b3];
/*      */     }
/*      */     byte b4;
/*  832 */     for (b4 = 0; b4 < b2; b4++)
/*      */     {
/*  834 */       this.m_oraCharSurrogateLevel[b4] = -1;
/*      */     }
/*      */     
/*  837 */     for (b4 = 0; b4 < b3; b4++)
/*      */     {
/*  839 */       this.m_oraCharLevel2[b4] = Character.MAX_VALUE;
/*      */     }
/*      */     
/*  842 */     for (b4 = 0; b4 < vector.size(); b4++) {
/*      */       
/*  844 */       int[] arrayOfInt = vector.elementAt(b4);
/*  845 */       int i = arrayOfInt[0] >> 24 & 0xFF;
/*  846 */       int j = arrayOfInt[0] >> 16 & 0xFF;
/*  847 */       int k = arrayOfInt[0] >> 8 & 0xFF;
/*  848 */       int m = arrayOfInt[0] & 0xFF;
/*      */       
/*  850 */       if (i >= 216 && i < 220) {
/*      */         
/*  852 */         if (this.m_oraCharLevel1[i] == -1) {
/*      */           
/*  854 */           this.m_oraCharLevel1[i] = bool2;
/*  855 */           bool2 += true;
/*      */         } 
/*      */         
/*  858 */         if (this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] == -1) {
/*      */           
/*  860 */           this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] = bool2;
/*  861 */           bool2 += true;
/*      */         } 
/*      */         
/*  864 */         if (this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] == -1) {
/*      */ 
/*      */           
/*  867 */           this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] = bool1;
/*  868 */           bool1 += true;
/*      */         } 
/*      */         
/*  871 */         if (this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m] == Character.MAX_VALUE)
/*      */         {
/*      */           
/*  874 */           this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m] = (char)(arrayOfInt[1] & 0xFFFF);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  884 */         if (this.m_oraCharLevel1[k] == -1) {
/*      */           
/*  886 */           this.m_oraCharLevel1[k] = bool1;
/*  887 */           bool1 += true;
/*      */         } 
/*      */         
/*  890 */         if (this.m_oraCharLevel2[this.m_oraCharLevel1[k] + m] == Character.MAX_VALUE)
/*      */         {
/*  892 */           this.m_oraCharLevel2[this.m_oraCharLevel1[k] + m] = (char)(arrayOfInt[1] & 0xFFFF);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  902 */     if (this.extraUnicodeToOracleMapping != null) {
/*      */       
/*  904 */       int i = this.extraUnicodeToOracleMapping.length;
/*      */       
/*  906 */       for (b4 = 0; b4 < i; b4++) {
/*      */ 
/*      */         
/*  909 */         int i1 = this.extraUnicodeToOracleMapping[b4][0];
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  914 */         int j = i1 >>> 24 & 0xFF;
/*  915 */         int k = i1 >>> 16 & 0xFF;
/*  916 */         int m = i1 >>> 8 & 0xFF;
/*  917 */         int n = i1 & 0xFF;
/*      */         
/*  919 */         if (j >= 216 && j < 220) {
/*      */           
/*  921 */           if (this.m_oraCharLevel1[j] == -1) {
/*      */ 
/*      */             
/*  924 */             this.m_oraCharLevel1[j] = bool2;
/*  925 */             bool2 += true;
/*      */           } 
/*      */           
/*  928 */           if (this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] == -1) {
/*      */             
/*  930 */             this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] = bool2;
/*  931 */             bool2 += true;
/*      */           } 
/*      */           
/*  934 */           if (this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] == -1) {
/*      */ 
/*      */             
/*  937 */             this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] = bool1;
/*  938 */             bool1 += true;
/*      */           } 
/*      */           
/*  941 */           this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] = (char)(this.extraUnicodeToOracleMapping[b4][1] & 0xFFFF);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  946 */           if (this.m_oraCharLevel1[m] == -1) {
/*      */             
/*  948 */             this.m_oraCharLevel1[m] = bool1;
/*  949 */             bool1 += true;
/*      */           } 
/*      */           
/*  952 */           this.m_oraCharLevel2[this.m_oraCharLevel1[m] + n] = (char)(this.extraUnicodeToOracleMapping[b4][1] & 0xFFFF);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void extractCodepoints(Vector<int[]> paramVector) {
/*  962 */     byte b1 = 0;
/*  963 */     char c = '￿';
/*      */ 
/*      */     
/*  966 */     for (byte b2 = b1; b2 <= c; b2++) {
/*      */ 
/*      */       
/*      */       try {
/*  970 */         int[] arrayOfInt = new int[2];
/*  971 */         arrayOfInt[0] = b2;
/*  972 */         arrayOfInt[1] = toUnicode(b2);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  977 */         paramVector.addElement(arrayOfInt);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  982 */       catch (SQLException sQLException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void extractExtraMappings(Vector<int[]> paramVector) {
/*  991 */     if (this.extraUnicodeToOracleMapping == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     for (byte b = 0; b < this.extraUnicodeToOracleMapping.length; b++) {
/*      */       
/* 1000 */       int[] arrayOfInt = new int[2];
/* 1001 */       arrayOfInt[0] = this.extraUnicodeToOracleMapping[b][0];
/* 1002 */       arrayOfInt[1] = this.extraUnicodeToOracleMapping[b][1];
/* 1003 */       paramVector.addElement(arrayOfInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasExtraMappings() {
/* 1009 */     return (this.extraUnicodeToOracleMapping != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public char getOraChar1ByteRep() {
/* 1014 */     return this.m_1ByteOraCharReplacement;
/*      */   }
/*      */ 
/*      */   
/*      */   public char getOraChar2ByteRep() {
/* 1019 */     return this.m_2ByteOraCharReplacement;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getUCS2CharRep() {
/* 1024 */     return this.m_ucsCharReplacement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int ByteToCharConvert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 1033 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int CharToByteConvert(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 1041 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int toUnicodeCharsWithReplacement(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
/* 1048 */     return 0;
/*      */   }
/*      */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverter12Byte.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
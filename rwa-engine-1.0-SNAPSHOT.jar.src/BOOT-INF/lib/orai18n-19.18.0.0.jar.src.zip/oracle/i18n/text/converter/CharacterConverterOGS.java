/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import oracle.i18n.text.UTFUtility;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterConverterOGS
/*     */   extends CharacterConverter
/*     */ {
/*  73 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */   
/*  75 */   static final String CONVERTERNAMEPREFIX = GDKOracleMetaData.getDataPath() + "lx2";
/*     */   
/*     */   static final String CONVERTERIDPREFIX = "0000";
/*     */   
/*     */   public static final byte UNDEFINED_DISPLAY_WIDTH = -1;
/*     */   
/*     */   public static final int BELOW_CJK = 12287;
/*     */   
/*     */   static final int HIBYTEMASK = 65280;
/*     */   
/*     */   static final int LOWBYTEMASK = 255;
/*     */   
/*     */   static final int STORE_INCREMENT = 10;
/*     */   
/*     */   static final int INVALID_ORA_CHAR = -1;
/*     */   
/*     */   static final int FIRSTBSHIFT = 24;
/*     */   static final int SECONDBSHIFT = 16;
/*     */   static final int THIRDBSHIFT = 8;
/*     */   static final int UB2MASK = 65535;
/*     */   static final int UB4MASK = 65535;
/*     */   protected static final String BEGIN_UNISTR = "UNISTR('";
/*     */   protected static final String END_UNISTR = "')";
/*  98 */   static final HashMap m_converterStore = new HashMap<Object, Object>();
/*     */ 
/*     */ 
/*     */   
/*     */   public int m_groupId;
/*     */ 
/*     */ 
/*     */   
/*     */   public int m_oracleId;
/*     */ 
/*     */ 
/*     */   
/*     */   protected float averageCharsPerByte;
/*     */ 
/*     */   
/*     */   protected float maxCharsPerByte;
/*     */ 
/*     */   
/*     */   protected float maxBytesPerChar;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final synchronized CharacterConverter getInstance(int paramInt) {
/* 121 */     CharacterConverterOGS characterConverterOGS = null;
/* 122 */     boolean bool1 = false;
/* 123 */     boolean bool2 = false;
/* 124 */     String str1 = Integer.toHexString(paramInt);
/* 125 */     characterConverterOGS = (CharacterConverterOGS)m_converterStore.get(str1);
/* 126 */     if (characterConverterOGS != null) {
/* 127 */       return characterConverterOGS;
/*     */     }
/*     */ 
/*     */     
/* 131 */     String str2 = CONVERTERNAMEPREFIX + "0000".substring(0, 4 - str1.length()) + str1;
/*     */     
/* 133 */     characterConverterOGS = (CharacterConverterOGS)readObj(str2 + ".glb");
/* 134 */     if (characterConverterOGS == null)
/* 135 */       return null; 
/* 136 */     characterConverterOGS.buildUnicodeToOracleMapping();
/* 137 */     m_converterStore.put(str1, characterConverterOGS);
/* 138 */     return characterConverterOGS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void storeMappingRange(int paramInt, Hashtable<Integer, char[]> paramHashtable1, Hashtable<Integer, char[]> paramHashtable2) {
/* 150 */     int i = paramInt >> 24 & 0xFF;
/* 151 */     int j = paramInt >> 16 & 0xFF;
/* 152 */     int k = paramInt >> 8 & 0xFF;
/* 153 */     int m = paramInt & 0xFF;
/* 154 */     Integer integer1 = new Integer(i);
/* 155 */     Integer integer2 = new Integer(paramInt >> 16 & 0xFFFF);
/* 156 */     Integer integer3 = new Integer(paramInt >> 8 & 0xFFFFFF);
/*     */     
/* 158 */     if (paramInt >>> 26 == 54) {
/*     */       
/* 160 */       char[] arrayOfChar1 = (char[])paramHashtable1.get(integer1);
/* 161 */       if (arrayOfChar1 == null) {
/* 162 */         arrayOfChar1 = new char[] { 'ÿ', Character.MIN_VALUE };
/*     */       }
/* 164 */       if (arrayOfChar1[0] == 'ÿ' && arrayOfChar1[1] == '\000') {
/* 165 */         arrayOfChar1[0] = (char)j;
/* 166 */         arrayOfChar1[1] = (char)j;
/*     */       } else {
/* 168 */         if (j < (arrayOfChar1[0] & Character.MAX_VALUE))
/* 169 */           arrayOfChar1[0] = (char)j; 
/* 170 */         if (j > (arrayOfChar1[0] & Character.MAX_VALUE))
/* 171 */           arrayOfChar1[1] = (char)j; 
/*     */       } 
/* 173 */       paramHashtable1.put(integer1, arrayOfChar1);
/*     */       
/* 175 */       arrayOfChar1 = paramHashtable1.get(integer2);
/* 176 */       if (arrayOfChar1 == null) {
/* 177 */         arrayOfChar1 = new char[] { 'ÿ', Character.MIN_VALUE };
/*     */       }
/* 179 */       if (arrayOfChar1[0] == 'ÿ' && arrayOfChar1[1] == '\000') {
/* 180 */         arrayOfChar1[0] = (char)k;
/* 181 */         arrayOfChar1[1] = (char)k;
/*     */       } else {
/* 183 */         if (k < (arrayOfChar1[0] & Character.MAX_VALUE))
/* 184 */           arrayOfChar1[0] = (char)k; 
/* 185 */         if (k > (arrayOfChar1[0] & Character.MAX_VALUE))
/* 186 */           arrayOfChar1[1] = (char)k; 
/*     */       } 
/* 188 */       paramHashtable1.put(integer2, arrayOfChar1);
/*     */     } 
/*     */     
/* 191 */     char[] arrayOfChar = (char[])paramHashtable2.get(integer3);
/* 192 */     if (arrayOfChar == null) {
/* 193 */       arrayOfChar = new char[] { 'ÿ', Character.MIN_VALUE };
/*     */     }
/* 195 */     if (arrayOfChar[0] == 'ÿ' && arrayOfChar[1] == '\000') {
/* 196 */       arrayOfChar[0] = (char)m;
/* 197 */       arrayOfChar[1] = (char)m;
/*     */     } else {
/* 199 */       if (m < (arrayOfChar[0] & Character.MAX_VALUE))
/* 200 */         arrayOfChar[0] = (char)m; 
/* 201 */       if (m > (arrayOfChar[0] & Character.MAX_VALUE))
/* 202 */         arrayOfChar[1] = (char)m; 
/*     */     } 
/* 204 */     paramHashtable2.put(integer3, arrayOfChar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGroupId() {
/* 213 */     return this.m_groupId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOracleId() {
/* 222 */     return this.m_oracleId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAverageRatio() {
/* 231 */     return this.averageCharsPerByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaxRatio() {
/* 240 */     return this.maxCharsPerByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaxBytesRatio() {
/* 249 */     return this.maxBytesPerChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String toUnistrChar(char paramChar) {
/* 260 */     String str = Integer.toHexString(paramChar);
/* 261 */     return "\\" + (new String("000" + str)).substring(str.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultDisplayWidth(int paramInt) {
/* 271 */     return (paramInt >>> 8 > 0) ? 2 : 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected char[] parseUnicodeCodePoint(int paramInt) throws UnsupportedEncodingException {
/* 280 */     char c1 = (char)(paramInt & 0xFFFF);
/* 281 */     char c2 = (char)(paramInt >>> 16);
/* 282 */     if (UTFUtility.isHiSurrogate(c2)) {
/* 283 */       if (UTFUtility.isLoSurrogate(c1)) {
/* 284 */         return new char[] { c2, c1 };
/*     */       }
/* 286 */       throw new UnsupportedEncodingException(GDKMessage.getMessage(7002, Integer.toHexString(paramInt)));
/*     */     } 
/*     */     
/* 289 */     return new char[] { c1, Character.MIN_VALUE };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getDisplayWidth(int paramInt, boolean paramBoolean) throws UnsupportedEncodingException, SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] toOracleString(String paramString) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void buildUnicodeToOracleMapping();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleStringWithReplacement(String paramString) {
/* 325 */     int[] arrayOfInt = new int[1];
/* 326 */     arrayOfInt[0] = paramString.length();
/*     */     
/* 328 */     if (arrayOfInt[0] == 0)
/*     */     {
/* 330 */       return new byte[0];
/*     */     }
/*     */     
/* 333 */     char[] arrayOfChar = new char[arrayOfInt[0]];
/* 334 */     paramString.getChars(0, arrayOfInt[0], arrayOfChar, 0);
/*     */     
/* 336 */     return toOracleStringWithReplacement(arrayOfChar, 0, null, 0, arrayOfInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint);
/*     */ 
/*     */   
/*     */   public abstract void extractCodepoints(Vector paramVector);
/*     */ 
/*     */   
/*     */   public abstract void extractExtraMappings(Vector paramVector);
/*     */ 
/*     */   
/*     */   public abstract boolean hasExtraMappings();
/*     */   
/*     */   public abstract char getOraChar1ByteRep();
/*     */   
/*     */   public abstract char getOraChar2ByteRep();
/*     */   
/*     */   public abstract int getUCS2CharRep();
/*     */   
/*     */   protected abstract boolean isOraCharacterReplacement(char paramChar1, char paramChar2);
/*     */   
/*     */   public String toUnistr(String paramString) {
/* 360 */     StringBuffer stringBuffer = new StringBuffer("UNISTR('");
/* 361 */     char[] arrayOfChar = paramString.toCharArray();
/* 362 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/*     */       
/* 364 */       if (arrayOfChar[b] >= '?' && arrayOfChar[b] <= '?') {
/*     */         
/* 366 */         if (b + 1 < arrayOfChar.length && arrayOfChar[b + 1] >= '?' && arrayOfChar[b + 1] <= '?')
/*     */         {
/*     */           
/* 369 */           if (isOraCharacterReplacement(arrayOfChar[b], arrayOfChar[b + 1]))
/*     */           {
/* 371 */             stringBuffer.append(toUnistrChar(arrayOfChar[b++]));
/* 372 */             stringBuffer.append(toUnistrChar(arrayOfChar[b]));
/*     */           }
/*     */           else
/*     */           {
/* 376 */             stringBuffer.append(arrayOfChar[b++]);
/* 377 */             stringBuffer.append(arrayOfChar[b]);
/*     */           }
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 383 */           stringBuffer.append(toUnistrChar(arrayOfChar[b]));
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 388 */       else if (isOraCharacterReplacement(arrayOfChar[b], false)) {
/* 389 */         stringBuffer.append(toUnistrChar(arrayOfChar[b]));
/* 390 */       } else if (arrayOfChar[b] == '\'') {
/*     */         
/* 392 */         stringBuffer.append("''");
/*     */       } else {
/*     */         
/* 395 */         stringBuffer.append(arrayOfChar[b]);
/*     */       } 
/*     */     } 
/* 398 */     stringBuffer.append("')");
/* 399 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object readObj(String paramString) {
/* 409 */     final Class<CharacterConverterOGS> me = CharacterConverterOGS.class;
/* 410 */     final String fentryName = paramString;
/*     */ 
/*     */     
/*     */     try {
/* 414 */       final URL objfile = AccessController.<URL>doPrivileged(new PrivilegedExceptionAction<URL>()
/*     */           {
/*     */             public Object run() throws ClassNotFoundException
/*     */             {
/* 418 */               return me.getResource(fentryName);
/*     */             }
/*     */           });
/* 421 */       if (uRL == null)
/*     */       {
/* 423 */         return null;
/*     */       }
/*     */       
/* 426 */       return AccessController.doPrivileged(new PrivilegedExceptionAction<Object>()
/*     */           {
/*     */             public Object run() throws IOException, ClassNotFoundException
/*     */             {
/* 430 */               InputStream inputStream = objfile.openStream();
/* 431 */               ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
/* 432 */               Object object = objectInputStream.readObject();
/* 433 */               objectInputStream.close();
/* 434 */               inputStream.close();
/* 435 */               return object;
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 442 */     catch (PrivilegedActionException privilegedActionException) {
/* 443 */       throw new RuntimeException("IOException" + privilegedActionException.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterOGS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
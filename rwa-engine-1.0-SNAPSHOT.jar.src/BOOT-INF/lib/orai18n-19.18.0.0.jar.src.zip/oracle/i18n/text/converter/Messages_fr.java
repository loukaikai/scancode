/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages_fr
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents() {
/* 26 */     return this.contents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private Object[][] contents = new Object[][] { { "17154", "Impossible de mettre en correspondance un caractère Oracle avec Unicode" }, { "17155", "Impossible de mettre en correspondance Unicode avec le caractère Oracle" }, { "7002", "valeur de substitution Unicode non valide" } };
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\Messages_fr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterConverterLC
/*     */   extends CharacterConverterOGS
/*     */ {
/* 109 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */   
/*     */   static final int MAX_7BIT = 127;
/*     */   
/*     */   static final int ORACHARMASK = 255;
/*     */   static final int UCSCHARWIDTH = 16;
/*     */   static final int ORACHARWIDTH = 16;
/*     */   static final int ORACHARWITHLCWIDTH = 32;
/*     */   static final int BYTEWIDTH = 8;
/*     */   static final int HIBYTEMASK = 65280;
/*     */   static final int LOWBYTEMASK = 255;
/*     */   static final int LOW16BITMASK = 65535;
/*     */   static final int LEADINGCODEWIDTH = 16;
/*     */   static final int LEADINGCODESHIFT = 16;
/*     */   static final int LEADINGCODEMASK = 65535;
/*     */   static final int LCINDEXWIDTH = 4;
/*     */   static final int LCINDEXMASK = 15;
/*     */   static final int LCINDEXFACTOR = 2;
/*     */   static final int MAXBYTEPERCHAR = 4;
/* 128 */   public char[][] m_ucsCharLeadingCode = (char[][])null;
/* 129 */   public char[] m_ucsCharLevel1 = null;
/* 130 */   public int[] m_ucsCharLevel2 = null;
/* 131 */   public int m_ucsCharReplacement = 0;
/* 132 */   public char m_1ByteOraCharReplacement = Character.MIN_VALUE;
/* 133 */   public char m_2ByteOraCharReplacement = Character.MIN_VALUE;
/*     */ 
/*     */   
/* 136 */   public char[] m_displayWidthLevel1 = null;
/* 137 */   public byte[] m_displayWidthLevel2 = null;
/* 138 */   public char[][] m_displayWidthLeadingCode = (char[][])null;
/*     */ 
/*     */   
/* 141 */   public char[] m_oraCharLevel1 = null;
/* 142 */   public int[] m_oraCharLevel2 = null;
/* 143 */   public char[] m_oraCharSurrogateLevel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CharacterConverterLC() {
/* 150 */     this.m_groupId = 8;
/* 151 */     this.averageCharsPerByte = 1.0F;
/* 152 */     this.maxCharsPerByte = 1.0F;
/* 153 */     this.maxBytesPerChar = 4.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getLeadingCodes() {
/* 161 */     char[] arrayOfChar = new char[this.m_ucsCharLeadingCode.length];
/*     */     
/* 163 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/* 164 */       arrayOfChar[b] = this.m_ucsCharLeadingCode[b][0];
/*     */     }
/* 166 */     return arrayOfChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicode(int paramInt) throws SQLException {
/*     */     int m;
/* 183 */     char c = Character.MIN_VALUE;
/* 184 */     int i = paramInt >> 16 & 0xFFFF;
/*     */     
/*     */     byte b;
/* 187 */     for (b = 0; b < this.m_ucsCharLeadingCode.length; b++) {
/*     */       
/* 189 */       if (i == this.m_ucsCharLeadingCode[b][0]) {
/*     */         
/* 191 */         c = this.m_ucsCharLeadingCode[b][1];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 197 */     if (b == this.m_ucsCharLeadingCode.length)
/*     */     {
/*     */       
/* 200 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     }
/*     */ 
/*     */     
/* 204 */     int j = (paramInt >> 8 & 0xFF) + c;
/* 205 */     int k = paramInt & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     if (this.m_ucsCharLevel1[j] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[j] + k] != -1) {
/*     */ 
/*     */       
/* 213 */       m = this.m_ucsCharLevel2[this.m_ucsCharLevel1[j] + k];
/*     */     }
/*     */     else {
/*     */       
/* 217 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     } 
/*     */ 
/*     */     
/* 221 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicodeWithReplacement(int paramInt) {
/*     */     int m;
/* 232 */     char c = Character.MIN_VALUE;
/* 233 */     int i = paramInt >> 16 & 0xFFFF;
/*     */     
/*     */     byte b;
/* 236 */     for (b = 0; b < this.m_ucsCharLeadingCode.length; b++) {
/*     */       
/* 238 */       if (i == this.m_ucsCharLeadingCode[b][0]) {
/*     */         
/* 240 */         c = this.m_ucsCharLeadingCode[b][1];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     if (b == this.m_ucsCharLeadingCode.length)
/*     */     {
/*     */       
/* 249 */       return this.m_ucsCharReplacement;
/*     */     }
/*     */ 
/*     */     
/* 253 */     int j = (paramInt >> 8 & 0xFF) + c;
/* 254 */     int k = paramInt & 0xFF;
/*     */ 
/*     */     
/* 257 */     if (this.m_ucsCharLevel1[j] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[j] + k] != -1) {
/*     */ 
/*     */       
/* 260 */       m = this.m_ucsCharLevel2[this.m_ucsCharLevel1[j] + k];
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 265 */       m = this.m_ucsCharReplacement;
/*     */     } 
/*     */     
/* 268 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDisplayWidth(int paramInt, boolean paramBoolean) throws UnsupportedEncodingException, SQLException {
/*     */     int i;
/* 286 */     char[] arrayOfChar = parseUnicodeCodePoint(paramInt);
/*     */ 
/*     */     
/* 289 */     if (paramBoolean) {
/* 290 */       i = toOracleCharacterWithReplacement(arrayOfChar[0], arrayOfChar[1]);
/*     */     } else {
/* 292 */       i = toOracleCharacter(arrayOfChar[0], arrayOfChar[1]);
/*     */     } 
/*     */     
/* 295 */     if (this.m_displayWidthLevel1 == null || this.m_displayWidthLevel2 == null) {
/* 296 */       return getDefaultDisplayWidth(i);
/*     */     }
/*     */ 
/*     */     
/* 300 */     char c = Character.MIN_VALUE;
/* 301 */     int j = i >> 16 & 0xFFFF;
/*     */     
/*     */     byte b;
/* 304 */     for (b = 0; b < this.m_displayWidthLeadingCode.length; b++) {
/* 305 */       if (j == this.m_displayWidthLeadingCode[b][0]) {
/* 306 */         c = this.m_displayWidthLeadingCode[b][1];
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 311 */     if (b == this.m_displayWidthLeadingCode.length) {
/* 312 */       return getDefaultDisplayWidth(i);
/*     */     }
/*     */ 
/*     */     
/* 316 */     int k = (i >> 8 & 0xFF) + c;
/* 317 */     int m = i & 0xFF;
/*     */     
/* 319 */     if (this.m_displayWidthLevel1[k] != Character.MAX_VALUE) {
/* 320 */       byte b1 = this.m_displayWidthLevel2[this.m_displayWidthLevel1[k] + m];
/* 321 */       if (b1 != -1) {
/* 322 */         return b1;
/*     */       }
/*     */     } 
/* 325 */     return getDefaultDisplayWidth(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toOracleCharacter(char paramChar1, char paramChar2) throws SQLException {
/* 339 */     int i = -1;
/*     */     
/* 341 */     if (paramChar2 != '\000') {
/*     */ 
/*     */       
/* 344 */       int j = paramChar1 >>> 8 & 0xFF;
/* 345 */       int k = paramChar1 & 0xFF;
/* 346 */       int m = paramChar2 >>> 8 & 0xFF;
/* 347 */       int n = paramChar2 & 0xFF;
/*     */       
/* 349 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] != -1)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 354 */         i = this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n];
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 360 */       int j = paramChar1 >>> 8 & 0xFF;
/* 361 */       int k = paramChar1 & 0xFF;
/*     */       
/* 363 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k] != -1)
/*     */       {
/*     */         
/* 366 */         i = this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 371 */     if (i == -1)
/*     */     {
/* 373 */       throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */     }
/*     */ 
/*     */     
/* 377 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toOracleCharacterWithReplacement(char paramChar1, char paramChar2) {
/* 389 */     int i = -1;
/*     */     
/* 391 */     if (paramChar2 != '\000') {
/*     */ 
/*     */       
/* 394 */       int j = paramChar1 >>> 8 & 0xFF;
/* 395 */       int k = paramChar1 & 0xFF;
/* 396 */       int m = paramChar2 >>> 8 & 0xFF;
/* 397 */       int n = paramChar2 & 0xFF;
/*     */       
/* 399 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] != -1)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 404 */         i = this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n];
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 410 */       int j = paramChar1 >>> 8 & 0xFF;
/* 411 */       int k = paramChar1 & 0xFF;
/*     */       
/* 413 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k] != -1)
/*     */       {
/*     */         
/* 416 */         i = this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k];
/*     */       }
/*     */     } 
/*     */     
/* 420 */     if (i == -1) {
/*     */       
/* 422 */       if (paramChar1 > '⿿')
/*     */       {
/* 424 */         return this.m_2ByteOraCharReplacement;
/*     */       }
/*     */ 
/*     */       
/* 428 */       return this.m_1ByteOraCharReplacement;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 433 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleString(String paramString) throws SQLException {
/* 450 */     int i = paramString.length();
/*     */     
/* 452 */     if (i == 0)
/*     */     {
/* 454 */       return new byte[0];
/*     */     }
/*     */     
/* 457 */     char[] arrayOfChar = new char[i];
/* 458 */     paramString.getChars(0, i, arrayOfChar, 0);
/*     */     
/* 460 */     byte[] arrayOfByte = new byte[i * 4];
/*     */ 
/*     */     
/* 463 */     byte b1 = 0;
/*     */     
/* 465 */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       int j;
/* 467 */       if (arrayOfChar[b2] >= '?' && arrayOfChar[b2] < '?') {
/*     */         
/* 469 */         if (b2 + 1 < i && arrayOfChar[b2 + 1] >= '?' && arrayOfChar[b2 + 1] <= '?')
/*     */         {
/*     */ 
/*     */           
/* 473 */           j = toOracleCharacterWithReplacement(arrayOfChar[b2], arrayOfChar[b2 + 1]);
/*     */           
/* 475 */           b2++;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 480 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 485 */         j = toOracleCharacter(arrayOfChar[b2], false);
/*     */       } 
/*     */       
/* 488 */       if (j >> 24 != 0) {
/*     */         
/* 490 */         arrayOfByte[b1++] = (byte)(j >> 24);
/* 491 */         arrayOfByte[b1++] = (byte)(j >> 16);
/* 492 */         arrayOfByte[b1++] = (byte)(j >> 8);
/* 493 */         arrayOfByte[b1++] = (byte)j;
/*     */       }
/* 495 */       else if (j >> 16 != 0) {
/*     */         
/* 497 */         arrayOfByte[b1++] = (byte)(j >> 16);
/* 498 */         arrayOfByte[b1++] = (byte)(j >> 8);
/* 499 */         arrayOfByte[b1++] = (byte)j;
/*     */       }
/* 501 */       else if (j >> 8 != 0) {
/*     */         
/* 503 */         arrayOfByte[b1++] = (byte)(j >> 8);
/* 504 */         arrayOfByte[b1++] = (byte)j;
/*     */       }
/*     */       else {
/*     */         
/* 508 */         arrayOfByte[b1++] = (byte)j;
/*     */       } 
/*     */     } 
/*     */     
/* 512 */     if (b1 < arrayOfByte.length) {
/*     */ 
/*     */       
/* 515 */       byte[] arrayOfByte1 = new byte[b1];
/* 516 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*     */       
/* 518 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 522 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*     */     byte[] arrayOfByte;
/*     */     byte b;
/* 550 */     int i = paramArrayOfint[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 555 */     int j = paramInt1 + i;
/*     */ 
/*     */     
/* 558 */     if (paramArrayOfbyte != null) {
/*     */       
/* 560 */       arrayOfByte = paramArrayOfbyte;
/* 561 */       b = paramInt2;
/*     */     }
/*     */     else {
/*     */       
/* 565 */       arrayOfByte = new byte[i * 4];
/* 566 */       b = 0;
/* 567 */       paramInt2 = 0;
/*     */     } 
/*     */     
/* 570 */     int k = paramInt1; while (true) { if (k < j) {
/*     */         int m;
/* 572 */         if (paramArrayOfchar[k] >= '?' && paramArrayOfchar[k] <= '?') {
/*     */           
/* 574 */           if (k + 1 < j && paramArrayOfchar[k + 1] >= '?' && paramArrayOfchar[k + 1] <= '?') {
/*     */ 
/*     */ 
/*     */             
/* 578 */             m = toOracleCharacterWithReplacement(paramArrayOfchar[k], paramArrayOfchar[k + 1]);
/*     */             
/* 580 */             k++;
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 585 */             arrayOfByte[b++] = (byte)(this.m_2ByteOraCharReplacement >> 8);
/* 586 */             arrayOfByte[b++] = (byte)this.m_2ByteOraCharReplacement;
/*     */ 
/*     */ 
/*     */             
/*     */             k++;
/*     */           } 
/*     */         } else {
/* 593 */           m = toOracleCharacterWithReplacement(paramArrayOfchar[k], false);
/*     */         } 
/*     */         
/* 596 */         if (m >> 24 != 0) {
/*     */           
/* 598 */           arrayOfByte[b++] = (byte)(m >> 24);
/* 599 */           arrayOfByte[b++] = (byte)(m >> 16);
/* 600 */           arrayOfByte[b++] = (byte)(m >> 8);
/* 601 */           arrayOfByte[b++] = (byte)m;
/*     */         }
/* 603 */         else if (m >> 16 != 0) {
/*     */           
/* 605 */           arrayOfByte[b++] = (byte)(m >> 16);
/* 606 */           arrayOfByte[b++] = (byte)(m >> 8);
/* 607 */           arrayOfByte[b++] = (byte)m;
/*     */         }
/* 609 */         else if (m >> 8 != 0) {
/*     */           
/* 611 */           arrayOfByte[b++] = (byte)(m >> 8);
/* 612 */           arrayOfByte[b++] = (byte)m;
/*     */         }
/*     */         else {
/*     */           
/* 616 */           arrayOfByte[b++] = (byte)m;
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       }  k++; }
/* 621 */      paramArrayOfint[0] = b - paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 628 */     if (paramArrayOfbyte == null && b < arrayOfByte.length) {
/*     */       
/* 630 */       byte[] arrayOfByte1 = new byte[b];
/* 631 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b);
/*     */       
/* 633 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 637 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOraCharacterReplacement(char paramChar1, char paramChar2) {
/* 648 */     int i = toOracleCharacterWithReplacement(paramChar1, paramChar2);
/*     */     
/* 650 */     return (i == getOraChar1ByteRep() || i == 
/* 651 */       getOraChar2ByteRep());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildUnicodeToOracleMapping() {
/* 687 */     this.m_oraCharLevel1 = new char[256];
/*     */     
/* 689 */     char[] arrayOfChar = null;
/* 690 */     int[] arrayOfInt = null;
/* 691 */     Vector<int[]> vector = new Vector(45055, 12287);
/* 692 */     Hashtable<Object, Object> hashtable1 = new Hashtable<Object, Object>();
/* 693 */     Hashtable<Object, Object> hashtable2 = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 704 */     char c1 = Character.MIN_VALUE;
/* 705 */     char c2 = Character.MIN_VALUE;
/*     */     
/*     */     byte b1;
/*     */     
/* 709 */     for (b1 = 0; b1 < 'Ā'; b1++)
/*     */     {
/* 711 */       this.m_oraCharLevel1[b1] = Character.MAX_VALUE;
/*     */     }
/*     */     
/* 714 */     for (b1 = 0; b1 < this.m_ucsCharLeadingCode.length; b1++) {
/*     */ 
/*     */       
/* 717 */       int i = this.m_ucsCharLeadingCode[b1][0] << 16;
/*     */       
/* 719 */       for (byte b = 0; b < '￿'; b++) {
/*     */         
/* 721 */         int j = toUnicodeWithReplacement(i | b);
/* 722 */         if (j != this.m_ucsCharReplacement) {
/*     */           
/* 724 */           int[] arrayOfInt1 = new int[2];
/* 725 */           arrayOfInt1[0] = j;
/* 726 */           arrayOfInt1[1] = i | b;
/* 727 */           vector.addElement(arrayOfInt1);
/* 728 */           storeMappingRange(j, hashtable1, hashtable2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 733 */     if (this.extraUnicodeToOracleMapping != null) {
/*     */       
/* 735 */       int i = this.extraUnicodeToOracleMapping.length;
/*     */       
/* 737 */       for (b1 = 0; b1 < i; b1++) {
/*     */         
/* 739 */         int j = this.extraUnicodeToOracleMapping[b1][0];
/* 740 */         storeMappingRange(j, hashtable1, hashtable2);
/*     */       } 
/*     */     } 
/*     */     
/* 744 */     Enumeration<Object> enumeration = hashtable1.keys();
/*     */ 
/*     */     
/* 747 */     byte b2 = 0;
/* 748 */     byte b3 = 0;
/*     */     
/* 750 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 752 */       Object object = enumeration.nextElement();
/* 753 */       char[] arrayOfChar1 = (char[])hashtable1.get(object);
/*     */       
/* 755 */       if (arrayOfChar1 != null)
/*     */       {
/*     */         
/* 758 */         b2 += true;
/*     */       }
/*     */     } 
/*     */     
/* 762 */     enumeration = hashtable2.keys();
/*     */     
/* 764 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 766 */       Object object = enumeration.nextElement();
/* 767 */       char[] arrayOfChar1 = (char[])hashtable2.get(object);
/*     */       
/* 769 */       if (arrayOfChar1 != null)
/*     */       {
/*     */         
/* 772 */         b3 += true;
/*     */       }
/*     */     } 
/*     */     
/* 776 */     if (b2)
/*     */     {
/* 778 */       arrayOfChar = new char[b2];
/*     */     }
/*     */     
/* 781 */     if (b3)
/*     */     {
/* 783 */       arrayOfInt = new int[b3];
/*     */     }
/*     */     byte b4;
/* 786 */     for (b4 = 0; b4 < b2; b4++)
/*     */     {
/* 788 */       arrayOfChar[b4] = Character.MAX_VALUE;
/*     */     }
/*     */     
/* 791 */     for (b4 = 0; b4 < b3; b4++)
/*     */     {
/* 793 */       arrayOfInt[b4] = -1;
/*     */     }
/*     */     
/* 796 */     for (b4 = 0; b4 < vector.size(); b4++) {
/*     */       
/* 798 */       int[] arrayOfInt1 = vector.elementAt(b4);
/* 799 */       int i = arrayOfInt1[0] >>> 24 & 0xFF;
/* 800 */       int j = arrayOfInt1[0] >>> 16 & 0xFF;
/* 801 */       int k = arrayOfInt1[0] >>> 8 & 0xFF;
/* 802 */       int m = arrayOfInt1[0] & 0xFF;
/*     */       
/* 804 */       if (i >= 216 && i < 220) {
/*     */         
/* 806 */         if (this.m_oraCharLevel1[i] == Character.MAX_VALUE) {
/*     */ 
/*     */           
/* 809 */           this.m_oraCharLevel1[i] = c2;
/* 810 */           c2 = (char)(c2 + 256);
/*     */         } 
/*     */         
/* 813 */         if (arrayOfChar[this.m_oraCharLevel1[i] + j] == Character.MAX_VALUE) {
/*     */           
/* 815 */           arrayOfChar[this.m_oraCharLevel1[i] + j] = c2;
/* 816 */           c2 = (char)(c2 + 256);
/*     */         } 
/*     */         
/* 819 */         if (arrayOfChar[arrayOfChar[this.m_oraCharLevel1[i] + j] + k] == Character.MAX_VALUE) {
/*     */ 
/*     */           
/* 822 */           arrayOfChar[arrayOfChar[this.m_oraCharLevel1[i] + j] + k] = c1;
/* 823 */           c1 = (char)(c1 + 256);
/*     */         } 
/*     */         
/* 826 */         if (arrayOfInt[arrayOfChar[arrayOfChar[this.m_oraCharLevel1[i] + j] + k] + m] == -1)
/*     */         {
/*     */           
/* 829 */           arrayOfInt[arrayOfChar[arrayOfChar[this.m_oraCharLevel1[i] + j] + k] + m] = arrayOfInt1[1];
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 838 */         if (this.m_oraCharLevel1[k] == Character.MAX_VALUE) {
/*     */           
/* 840 */           this.m_oraCharLevel1[k] = c1;
/* 841 */           c1 = (char)(c1 + 256);
/*     */         } 
/*     */         
/* 844 */         if (arrayOfInt[this.m_oraCharLevel1[k] + m] == -1)
/*     */         {
/* 846 */           arrayOfInt[this.m_oraCharLevel1[k] + m] = arrayOfInt1[1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 855 */     if (this.extraUnicodeToOracleMapping != null) {
/*     */       
/* 857 */       int i = this.extraUnicodeToOracleMapping.length;
/*     */       
/* 859 */       for (b4 = 0; b4 < i; b4++) {
/*     */ 
/*     */         
/* 862 */         int i1 = this.extraUnicodeToOracleMapping[b4][0];
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 867 */         int j = i1 >>> 24 & 0xFF;
/* 868 */         int k = i1 >>> 16 & 0xFF;
/* 869 */         int m = i1 >>> 8 & 0xFF;
/* 870 */         int n = i1 & 0xFF;
/*     */         
/* 872 */         if (j >= 216 && j < 220) {
/*     */           
/* 874 */           if (this.m_oraCharLevel1[j] == Character.MAX_VALUE) {
/*     */ 
/*     */             
/* 877 */             this.m_oraCharLevel1[j] = c2;
/* 878 */             c2 = (char)(c2 + 256);
/*     */           } 
/*     */           
/* 881 */           if (arrayOfChar[this.m_oraCharLevel1[j] + k] == Character.MAX_VALUE) {
/*     */             
/* 883 */             arrayOfChar[this.m_oraCharLevel1[j] + k] = c2;
/* 884 */             c2 = (char)(c2 + 256);
/*     */           } 
/*     */           
/* 887 */           if (arrayOfChar[arrayOfChar[this.m_oraCharLevel1[j] + k] + m] == Character.MAX_VALUE) {
/*     */ 
/*     */             
/* 890 */             arrayOfChar[arrayOfChar[this.m_oraCharLevel1[j] + k] + m] = c1;
/* 891 */             c1 = (char)(c1 + 256);
/*     */           } 
/*     */           
/* 894 */           arrayOfInt[arrayOfChar[arrayOfChar[this.m_oraCharLevel1[j] + k] + m] + n] = this.extraUnicodeToOracleMapping[b4][1];
/*     */         }
/*     */         else {
/*     */           
/* 898 */           if (this.m_oraCharLevel1[m] == Character.MAX_VALUE) {
/*     */             
/* 900 */             this.m_oraCharLevel1[m] = c1;
/* 901 */             c1 = (char)(c1 + 256);
/*     */           } 
/*     */           
/* 904 */           arrayOfInt[this.m_oraCharLevel1[m] + n] = this.extraUnicodeToOracleMapping[b4][1];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 911 */     this.m_oraCharLevel2 = arrayOfInt;
/* 912 */     this.m_oraCharSurrogateLevel = arrayOfChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extractCodepoints(Vector<int[]> paramVector) {
/* 922 */     for (byte b = 0; b < this.m_ucsCharLeadingCode.length; b++) {
/*     */       
/* 924 */       char c = this.m_ucsCharLeadingCode[b][0];
/* 925 */       int i = c << 16;
/* 926 */       int j = i + 65535;
/*     */       
/* 928 */       for (int k = i; k <= j; k++) {
/*     */ 
/*     */         
/*     */         try {
/* 932 */           int[] arrayOfInt = new int[2];
/* 933 */           arrayOfInt[0] = k;
/* 934 */           arrayOfInt[1] = toUnicode(k);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 939 */           paramVector.addElement(arrayOfInt);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 944 */         catch (SQLException sQLException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extractExtraMappings(Vector<int[]> paramVector) {
/* 954 */     if (this.extraUnicodeToOracleMapping == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 959 */     for (byte b = 0; b < this.extraUnicodeToOracleMapping.length; b++)
/*     */     {
/* 961 */       paramVector.addElement(this.extraUnicodeToOracleMapping[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasExtraMappings() {
/* 967 */     return (this.extraUnicodeToOracleMapping != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getOraChar1ByteRep() {
/* 972 */     return this.m_1ByteOraCharReplacement;
/*     */   }
/*     */ 
/*     */   
/*     */   public char getOraChar2ByteRep() {
/* 977 */     return this.m_2ByteOraCharReplacement;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getUCS2CharRep() {
/* 982 */     return this.m_ucsCharReplacement;
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterLC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
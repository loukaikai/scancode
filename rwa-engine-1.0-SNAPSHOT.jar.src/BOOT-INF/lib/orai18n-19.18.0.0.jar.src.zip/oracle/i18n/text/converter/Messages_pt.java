/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages_pt
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents() {
/* 26 */     return this.contents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private Object[][] contents = new Object[][] { { "17154", "não é possível efectuar a correspondência do carácter Oracle com o Unicode" }, { "17155", "não é possível efectuar a correspondência do Unicode com o carácter Oracle" }, { "7002", "o substituto de unicode é inválido" } };
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\Messages_pt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages_el
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents() {
/* 26 */     return this.contents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private Object[][] contents = new Object[][] { { "17154", "δεν είναι δυνατή η αντιστοίχιση του χαρακτήρα Oracle σε χαρακτήρα Unicode" }, { "17155", "δεν είναι δυνατή η αντιστοίχιση του χαρακτήρα Unicode σε χαρακτήρα Oracle" }, { "7002", "Μη αποδεκτό υποκατάστατο unicode" } };
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\Messages_el.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GDKMessage
/*     */ {
/*     */   private static final String M_C_MESSAGEFILE = "oracle.i18n.text.converter.Messages";
/*  33 */   private static final ResourceBundle bundle = ResourceBundle.getBundle("oracle.i18n.text.converter.Messages");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String GDK_PREFIX = "GDK";
/*     */ 
/*     */   
/*     */   private static final String ORA_PREFIX = "ORA";
/*     */ 
/*     */   
/*     */   private static final String KEY_BASE = "00000";
/*     */ 
/*     */   
/*  46 */   private static final int KEY_LENGTH = "00000".length();
/*     */ 
/*     */   
/*     */   public static final int CHARSET_NOT_SUPPORTED = 17035;
/*     */ 
/*     */   
/*     */   public static final int FAIL_CONV_UTF8_UCS2 = 17037;
/*     */ 
/*     */   
/*     */   public static final int NON_SUPPORTED_ADD_GDK = 17056;
/*     */   
/*     */   public static final int CANNOT_MAP_ORA_UNICODE = 17154;
/*     */   
/*     */   public static final int CANNOT_MAP_UNICODE_ORA = 17155;
/*     */   
/*     */   public static final int INVALID_UNICODE_SURROGATE = 7002;
/*     */ 
/*     */   
/*     */   private static String msg(String paramString, Object paramObject) {
/*     */     try {
/*  66 */       if (paramObject != null) {
/*  67 */         return bundle.getString(paramString) + ": " + paramObject;
/*     */       }
/*  69 */       return bundle.getString(paramString);
/*     */     }
/*  71 */     catch (Exception exception) {
/*     */       
/*  73 */       return "Message [" + paramString + "] not found in '" + "oracle.i18n.text.converter.Messages" + "'.";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMessage(String paramString, Object paramObject) {
/*  82 */     return "GDK-" + paramString + ": " + msg(paramString, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMessage(int paramInt) {
/*  89 */     return getMessage(paramInt, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMessage(int paramInt, Object paramObject) {
/*  96 */     String str = (new Integer(paramInt)).toString();
/*     */     
/*  98 */     if (str.length() < KEY_LENGTH) {
/*  99 */       str = "00000".substring(str.length()) + str;
/*     */     }
/*     */     
/* 102 */     return getMessage(str, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getORAMessage(int paramInt) {
/* 109 */     String str = (new Integer(paramInt)).toString();
/*     */     
/* 111 */     if (str.length() < KEY_LENGTH) {
/* 112 */       str = "00000".substring(str.length()) + str;
/*     */     }
/* 114 */     return "ORA-" + str + ": " + msg(str, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\GDKMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*      */ package oracle.i18n.text.converter;
/*      */ 
/*      */ import java.sql.SQLException;
/*      */ import java.util.Vector;
/*      */ import oracle.i18n.util.GDKOracleMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CharacterConverterGB18030
/*      */   extends CharacterConverter12Byte
/*      */ {
/*  119 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*  120 */   protected static int MAXLIMIT = 64000;
/*      */   static final int BMPSTART = -2127527632;
/*      */   static final int BMPEND = -2077121479;
/*      */   static final int GBBMPSTART = 1687218;
/*      */   static final int GBBMPEND = 1726637;
/*      */   static final int USURSTART = 65536;
/*      */   static final int USUREND = 1114111;
/*      */   static final int GBSURSTART = 1876218;
/*      */   static final int GBSUREND = 2924793;
/*  129 */   static char[][] gbMapping = new char[][] { { '', '£', Character.MIN_VALUE, '#' }, { '¥', '¦', '$', '%' }, { '©', '¯', '&', ',' }, { '²', '¶', '-', '1' }, { '¸', 'Ö', '2', 'P' }, { 'Ø', 'ß', 'Q', 'X' }, { 'â', 'ç', 'Y', '^' }, { 'ë', 'ë', '_', '_' }, { 'î', 'ñ', '`', 'c' }, { 'ô', 'ö', 'd', 'f' }, { 'ø', 'ø', 'g', 'g' }, { 'û', 'û', 'h', 'h' }, { 'ý', 'Ā', 'i', 'l' }, { 'Ă', 'Ē', 'm', '}' }, { 'Ĕ', 'Ě', '~', '' }, { 'Ĝ', 'Ī', '', '' }, { 'Ĭ', 'Ń', '', '«' }, { 'Ņ', 'Ň', '¬', '®' }, { 'ŉ', 'Ō', '¯', '²' }, { 'Ŏ', 'Ū', '³', 'Ï' }, { 'Ŭ', 'Ǎ', 'Ð', 'ı' }, { 'Ǐ', 'Ǐ', 'Ĳ', 'Ĳ' }, { 'Ǒ', 'Ǒ', 'ĳ', 'ĳ' }, { 'Ǔ', 'Ǔ', 'Ĵ', 'Ĵ' }, { 'Ǖ', 'Ǖ', 'ĵ', 'ĵ' }, { 'Ǘ', 'Ǘ', 'Ķ', 'Ķ' }, { 'Ǚ', 'Ǚ', 'ķ', 'ķ' }, { 'Ǜ', 'Ǜ', 'ĸ', 'ĸ' }, { 'ǝ', 'Ǹ', 'Ĺ', 'Ŕ' }, { 'Ǻ', 'ɐ', 'ŕ', 'ƫ' }, { 'ɒ', 'ɠ', 'Ƭ', 'ƺ' }, { 'ɢ', 'ˆ', 'ƻ', 'ȟ' }, { 'ˈ', 'ˈ', 'Ƞ', 'Ƞ' }, { 'ˌ', '˘', 'ȡ', 'ȭ' }, { '˚', 'ΐ', 'Ȯ', 'ˤ' }, { '΢', '΢', '˥', '˥' }, { 'Ϊ', 'ΰ', '˦', 'ˬ' }, { 'ς', 'ς', '˭', '˭' }, { 'ϊ', 'Ѐ', 'ˮ', '̤' }, { 'Ђ', 'Џ', '̥', '̲' }, { 'ѐ', 'ѐ', '̳', '̳' }, { 'ђ', '‏', '̴', 'ự' }, { '‑', '‒', 'Ỳ', 'ỳ' }, { '‗', '‗', 'Ỵ', 'Ỵ' }, { '‚', '‛', 'ỵ', 'Ỷ' }, { '„', '․', 'ỷ', 'ỽ' }, { '‧', ' ', 'Ỿ', 'ἆ' }, { '‱', '‱', 'ἇ', 'ἇ' }, { '‴', '‴', 'Ἀ', 'Ἀ' }, { '‶', '›', 'Ἁ', 'Ἅ' }, { '‼', '₫', 'Ἆ', 'ώ' }, { '₭', 'ℂ', '὾', 'ΐ' }, { '℄', '℄', '῔', '῔' }, { '℆', '℈', '῕', 'ῗ' }, { 'ℊ', 'ℕ', 'Ῐ', 'ΰ' }, { '℗', '℠', 'ῤ', '῭' }, { '™', '⅟', '΅', '‫' }, { 'Ⅼ', 'Ⅿ', '‬', ' ' }, { 'ⅺ', '↏', '‰', '⁅' }, { '↔', '↕', '⁆', '⁇' }, { '↚', '∇', '⁈', '₵' }, { '∉', '∎', '₶', '₻' }, { '∐', '∐', '₼', '₼' }, { '−', '∔', '₽', '₿' }, { '∖', '∙', '⃀', '⃃' }, { '∛', '∜', '⃄', '⃅' }, { '∡', '∢', '⃆', '⃇' }, { '∤', '∤', '⃈', '⃈' }, { '∦', '∦', '⃉', '⃉' }, { '∬', '∭', '⃊', '⃋' }, { '∯', '∳', '⃌', '⃐' }, { '∸', '∼', '⃑', '⃕' }, { '∾', '≇', '⃖', '⃟' }, { '≉', '≋', '⃠', '⃢' }, { '≍', '≑', '⃣', '⃧' }, { '≓', '≟', '⃨', '⃴' }, { '≢', '≣', '⃵', '⃶' }, { '≨', '≭', '⃷', '⃼' }, { '≰', '⊔', '⃽', '℡' }, { '⊖', '⊘', '™', 'ℤ' }, { '⊚', '⊤', '℥', 'ℯ' }, { '⊦', '⊾', 'ℰ', 'ⅈ' }, { '⋀', '⌑', 'ⅉ', '↚' }, { '⌓', '⑟', '↛', '⋧' }, { '⑪', '⑳', '⋨', '⋱' }, { '⒜', '⓿', '⋲', '⍕' }, { '╌', '╏', '⍖', '⍙' }, { '╴', '▀', '⍚', '⍦' }, { '▐', '▒', '⍧', '⍩' }, { '▖', '▟', '⍪', '⍳' }, { '▢', '▱', '⍴', '⎃' }, { '▴', '▻', '⎄', '⎋' }, { '▾', '◅', '⎌', '⎓' }, { '◈', '◊', '⎔', '⎖' }, { '◌', '◍', '⎗', '⎘' }, { '◐', '◡', '⎙', '⎪' }, { '◦', '☄', '⎫', '⏉' }, { '☇', '☈', '⏊', '⏋' }, { '☊', '☿', '⏌', '␁' }, { '♁', '♁', '␂', '␂' }, { '♃', '⺀', '␃', 'ⱀ' }, { '⺂', '⺃', 'ⱁ', 'ⱂ' }, { '⺅', '⺇', 'ⱃ', 'ⱅ' }, { '⺉', '⺊', 'ⱆ', 'ⱇ' }, { '⺍', '⺖', 'ⱈ', 'ⱑ' }, { '⺘', '⺦', 'ⱒ', 'Ⱡ' }, { '⺨', '⺩', 'ⱡ', 'Ɫ' }, { '⺫', '⺭', 'Ᵽ', 'ⱥ' }, { '⺯', '⺲', 'ⱦ', 'Ⱪ' }, { '⺴', '⺵', 'ⱪ', 'Ⱬ' }, { '⺸', '⺺', 'ⱬ', 'Ɱ' }, { '⺼', '⻉', 'Ɐ', 'ⱼ' }, { '⻋', '⿯', 'ⱽ', 'ⶡ' }, { '⿼', '⿿', 'ⶢ', 'ⶥ' }, { '〄', '〄', 'ⶦ', 'ⶦ' }, { '〘', '〜', '⶧', 'ⶫ' }, { '〟', '〠', 'ⶬ', 'ⶭ' }, { '〪', '〽', 'ⶮ', 'ⷁ' }, { '〿', '぀', 'ⷂ', 'ⷃ' }, { 'ゔ', '゚', 'ⷄ', 'ⷊ' }, { 'ゟ', '゠', 'ⷋ', 'ⷌ' }, { 'ヷ', '・', 'ⷍ', 'ⷑ' }, { 'ヿ', '㄄', 'ⷒ', '⷗' }, { 'ㄪ', '㈟', 'ⷘ', '⻍' }, { '㈪', '㈰', '⻎', '⻔' }, { '㈲', '㊢', '⻕', '⽅' }, { '㊤', '㎍', '⽆', '〯' }, { '㎐', '㎛', '〰', '〻' }, { '㎟', '㎠', '〼', '〽' }, { '㎢', '㏃', '〾', 'た' }, { '㏅', '㏍', 'だ', 'と' }, { '㏏', '㏐', 'ど', 'な' }, { '㏓', '㏔', 'に', 'ぬ' }, { '㏖', '㑆', 'ね', 'ポ' }, { '㑈', '㑲', 'マ', 'ㄈ' }, { '㑴', '㖝', 'ㄉ', '㈲' }, { '㖟', '㘍', '㈳', '㊡' }, { '㘏', '㘙', '㊢', '㊬' }, { '㘛', '㤗', '㊭', '㖩' }, { '㤙', '㥭', '㖪', '㗾' }, { '㥯', '㧎', '㗿', '㙞' }, { '㧑', '㧞', '㙟', '㙬' }, { '㧠', '㩲', '㙭', '㛿' }, { '㩴', '㭍', '㜀', '㟙' }, { '㭏', '㱭', '㟚', '㣸' }, { '㱯', '㳟', '㣹', '㥩' }, { '㳡', '䁕', '㥪', '㳞' }, { '䁗', '䅞', '㳟', '㷦' }, { '䅠', '䌶', '㷧', '㾽' }, { '䌸', '䎫', '㾾', '䀱' }, { '䎭', '䎰', '䀲', '䀵' }, { '䎲', '䏜', '䀶', '䁠' }, { '䏞', '䓕', '䁡', '䅘' }, { '䓗', '䙋', '䅙', '䋍' }, { '䙍', '䙠', '䋎', '䋡' }, { '䙢', '䜢', '䋢', '䎢' }, { '䜤', '䜨', '䎣', '䎧' }, { '䜪', '䝻', '䎨', '䏹' }, { '䝽', '䞌', '䏺', '䐉' }, { '䞎', '䥆', '䐊', '䗂' }, { '䥈', '䥹', '䗃', '䗴' }, { '䥻', '䥼', '䗵', '䗶' }, { '䥾', '䦁', '䗷', '䗺' }, { '䦄', '䦄', '䗻', '䗻' }, { '䦇', '䦚', '䗼', '䘏' }, { '䦜', '䦞', '䘐', '䘒' }, { '䦠', '䦵', '䘓', '䘨' }, { '䦸', '䱶', '䘩', '䣧' }, { '䱸', '䲞', '䣨', '䤎' }, { '䲤', '䴒', '䤏', '䥽' }, { '䴚', '䶭', '䥾', '䨑' }, { '䶯', '䷿', '䨒', '䩢' }, { '龦', '퟿', '䩣', '芼' }, { '', '', '芽', '芽' }, { '', '', '芾', '芾' }, { '', '', '芿', '苋' }, { '', '', '苌', '苌' }, { '', '', '苍', '苑' }, { '', '', '苒', '苘' }, { '', '', '苙', '苜' }, { '', '', '苝', '苠' }, { '', '', '苡', '苨' }, { '', '', '苩', '苯' }, { '', '', '苰', '苿' }, { '', '', '茀', '茍' }, { '', '狼', '茎', '鏔' }, { '來', '兩', '鏕', '鐠' }, { '梁', '璉', '鐡', '鐻' }, { '練', '罹', '鐼', '钌' }, { '裡', '藺', '钍', '钕' }, { '鱗', '廓', '钖', '钯' }, { '塚', '塚', '钰', '钰' }, { '晴', '晴', '钱', '钱' }, { '凞', '益', '钲', '钴' }, { '神', '羽', '钵', '钺' }, { '諸', '諸', '钻', '钻' }, { '逸', '都', '钼', '钽' }, { '飯', '︯', '钾', '飃' }, { '︲', '︲', '飄', '飄' }, { '﹅', '﹈', '飅', '飈' }, { '﹓', '﹓', '飉', '飉' }, { '﹘', '﹘', '飊', '飊' }, { '﹧', '﹧', '飋', '飋' }, { '﹬', '＀', '飌', '饠' }, { '｟', '￟', '饡', '駡' }, { '￦', '￮', '駢', '駪' } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int toUnicode(int paramInt) throws SQLException {
/*      */     int k;
/*  369 */     if (bMPLinear(paramInt) >= 39419) {
/*      */ 
/*      */       
/*  372 */       int m = 1752754 + bMPLinear(paramInt) - 1876218;
/*      */       
/*  374 */       return surrogateUcs4ToUtf16(m);
/*      */     } 
/*  376 */     if (paramInt >> 16 != 0) {
/*      */ 
/*      */       
/*  379 */       int m = bMPOracle2Unicode(paramInt);
/*      */       
/*  381 */       if (m == 0)
/*      */       {
/*  383 */         throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*      */       }
/*      */       
/*  386 */       return m;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  392 */     int i = paramInt >> 8 & 0xFF;
/*  393 */     int j = paramInt & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  398 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  405 */       k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*      */     }
/*      */     else {
/*      */       
/*  409 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*      */     } 
/*      */ 
/*      */     
/*  413 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int toUnicodeWithReplacement(int paramInt) {
/*      */     int k;
/*  429 */     if (bMPLinear(paramInt) >= 39419) {
/*      */ 
/*      */ 
/*      */       
/*  433 */       int m = 1752754 + bMPLinear(paramInt) - 1876218;
/*      */       
/*  435 */       return surrogateUcs4ToUtf16(m);
/*      */     } 
/*  437 */     if (paramInt >> 16 != 0) {
/*      */ 
/*      */       
/*  440 */       int m = bMPOracle2Unicode(paramInt);
/*      */       
/*  442 */       if (m == 0)
/*      */       {
/*  444 */         m = this.m_ucsCharReplacement;
/*      */       }
/*      */       
/*  447 */       return m;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  453 */     int i = paramInt >> 8 & 0xFF;
/*  454 */     int j = paramInt & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  459 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  466 */       k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*      */     }
/*      */     else {
/*      */       
/*  470 */       k = this.m_ucsCharReplacement;
/*      */     } 
/*      */ 
/*      */     
/*  474 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int toOracleCharacterGB(char paramChar1, char paramChar2) throws SQLException {
/*      */     int k;
/*  494 */     if (paramChar2 != '\000') {
/*      */ 
/*      */       
/*  497 */       int m = surrogateUtf16ToUcs4(paramChar1, paramChar2);
/*      */       
/*  499 */       if (m >= 65536 && m <= 1114111)
/*      */       {
/*      */         
/*  502 */         return bMPunLinear(1876218 + m - 65536 - 1687218);
/*      */       }
/*      */ 
/*      */       
/*  506 */       throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  511 */     int i = paramChar1 >> 8 & 0xFF;
/*  512 */     int j = paramChar1 & 0xFF;
/*      */ 
/*      */ 
/*      */     
/*  516 */     if (this.m_oraCharLevel1[i] != -1 && this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j] != Character.MAX_VALUE) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  523 */       k = this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j] & Character.MAX_VALUE;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  528 */       k = bMPUnicode2Oracle(paramChar1);
/*      */       
/*  530 */       if (k == 0)
/*      */       {
/*  532 */         throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  537 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int toOracleCharacterWithReplacementGB(char paramChar1, char paramChar2) {
/*      */     int k;
/*  554 */     if (paramChar2 != '\000') {
/*      */ 
/*      */       
/*  557 */       int m = surrogateUtf16ToUcs4(paramChar1, paramChar2);
/*      */       
/*  559 */       if (m >= 65536 && m <= 1114111)
/*      */       {
/*      */         
/*  562 */         return bMPunLinear(1876218 + m - 65536 - 1687218);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  567 */       return this.m_2ByteOraCharReplacement;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  572 */     int i = paramChar1 >> 8 & 0xFF;
/*  573 */     int j = paramChar1 & 0xFF;
/*      */ 
/*      */ 
/*      */     
/*  577 */     if (this.m_oraCharLevel1[i] != -1 && this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j] != Character.MAX_VALUE) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  584 */       k = this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j] & Character.MAX_VALUE;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  589 */       k = bMPUnicode2Oracle(paramChar1);
/*      */       
/*  591 */       if (k == 0) {
/*      */ 
/*      */         
/*  594 */         if (paramChar1 > '⿿')
/*      */         {
/*      */           
/*  597 */           return this.m_2ByteOraCharReplacement;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  602 */         return this.m_1ByteOraCharReplacement;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  608 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  632 */     int i = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */     
/*  636 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  637 */     byte b = 0;
/*  638 */     int j = paramInt1;
/*      */ 
/*      */ 
/*      */     
/*  642 */     while (j < i) {
/*      */ 
/*      */ 
/*      */       
/*  646 */       int k = paramArrayOfbyte[j] & 0xFF;
/*      */       
/*  648 */       if (k > 127) {
/*      */ 
/*      */         
/*  651 */         if (j + 1 < i) {
/*      */ 
/*      */           
/*  654 */           if ((paramArrayOfbyte[j] & 0xFF) >= 129 && (paramArrayOfbyte[j] & 0xFF) <= 254 && (paramArrayOfbyte[j + 1] & 0xFF) >= 48 && (paramArrayOfbyte[j + 1] & 0xFF) <= 57) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  663 */             if (j + 3 < i && (paramArrayOfbyte[j + 2] & 0xFF) >= 129 && (paramArrayOfbyte[j + 2] & 0xFF) <= 254 && (paramArrayOfbyte[j + 3] & 0xFF) >= 48 && (paramArrayOfbyte[j + 3] & 0xFF) <= 57) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  671 */               k = (paramArrayOfbyte[j] & 0xFF) << 24 | (paramArrayOfbyte[j + 1] & 0xFF) << 16 | (paramArrayOfbyte[j + 2] & 0xFF) << 8 | paramArrayOfbyte[j + 3] & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  677 */               j += 4;
/*      */               
/*  679 */               int m = toUnicode(k);
/*      */               
/*  681 */               if (m >> 16 == 0) {
/*      */                 
/*  683 */                 arrayOfChar[b++] = (char)m;
/*      */                 
/*      */                 continue;
/*      */               } 
/*  687 */               arrayOfChar[b++] = (char)(m >> 16 & 0xFFFF);
/*  688 */               arrayOfChar[b++] = (char)(m & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  700 */             throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  708 */           k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*      */ 
/*      */           
/*  711 */           arrayOfChar[b++] = (char)toUnicode(k);
/*  712 */           j += 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  724 */         throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  733 */       arrayOfChar[b++] = (char)toUnicode(k);
/*  734 */       j++;
/*      */     } 
/*      */ 
/*      */     
/*  738 */     return new String(arrayOfChar, 0, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  757 */     int i = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */     
/*  761 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  762 */     byte b = 0;
/*  763 */     int j = paramInt1;
/*      */ 
/*      */ 
/*      */     
/*  767 */     while (j < i) {
/*      */ 
/*      */ 
/*      */       
/*  771 */       int k = paramArrayOfbyte[j] & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  777 */       if (k > 127) {
/*      */ 
/*      */         
/*  780 */         if (j + 1 < i) {
/*      */ 
/*      */           
/*  783 */           if ((paramArrayOfbyte[j] & 0xFF) >= 129 && (paramArrayOfbyte[j] & 0xFF) <= 254 && (paramArrayOfbyte[j + 1] & 0xFF) >= 48 && (paramArrayOfbyte[j + 1] & 0xFF) <= 57) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  792 */             if (j + 3 < i && (paramArrayOfbyte[j + 2] & 0xFF) >= 129 && (paramArrayOfbyte[j + 2] & 0xFF) <= 254 && (paramArrayOfbyte[j + 3] & 0xFF) >= 48 && (paramArrayOfbyte[j + 3] & 0xFF) <= 57) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  800 */               k = (paramArrayOfbyte[j] & 0xFF) << 24 | (paramArrayOfbyte[j + 1] & 0xFF) << 16 | (paramArrayOfbyte[j + 2] & 0xFF) << 8 | paramArrayOfbyte[j + 3] & 0xFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  806 */               j += 4;
/*      */               
/*  808 */               int m = toUnicodeWithReplacement(k);
/*      */               
/*  810 */               if (m >> 16 == 0) {
/*      */                 
/*  812 */                 arrayOfChar[b++] = (char)m;
/*      */                 
/*      */                 continue;
/*      */               } 
/*  816 */               arrayOfChar[b++] = (char)(m >> 16 & 0xFFFF);
/*  817 */               arrayOfChar[b++] = (char)(m & 0xFFFF);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  827 */             arrayOfChar[b++] = (char)this.m_ucsCharReplacement;
/*  828 */             j += 4;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  838 */           k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*      */ 
/*      */           
/*  841 */           arrayOfChar[b++] = (char)toUnicodeWithReplacement(k);
/*  842 */           j += 2;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  852 */         arrayOfChar[b++] = (char)this.m_ucsCharReplacement;
/*  853 */         j++;
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*  860 */       arrayOfChar[b++] = (char)toUnicodeWithReplacement(k);
/*  861 */       j++;
/*      */     } 
/*      */     
/*  864 */     return new String(arrayOfChar, 0, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toOracleString(String paramString) throws SQLException {
/*  882 */     int i = paramString.length();
/*      */     
/*  884 */     if (i == 0)
/*      */     {
/*      */       
/*  887 */       return new byte[0];
/*      */     }
/*      */     
/*  890 */     char[] arrayOfChar = new char[i];
/*  891 */     paramString.getChars(0, i, arrayOfChar, 0);
/*      */     
/*  893 */     byte[] arrayOfByte = new byte[i * 4];
/*      */ 
/*      */     
/*  896 */     byte b1 = 0;
/*      */     
/*  898 */     for (byte b2 = 0; b2 < i; b2++) {
/*      */       int j;
/*      */       
/*  901 */       if (arrayOfChar[b2] >= '?' && arrayOfChar[b2] < '?') {
/*      */ 
/*      */         
/*  904 */         if (b2 + 1 < i && arrayOfChar[b2 + 1] >= '?' && arrayOfChar[b2 + 1] <= '?')
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  912 */           j = toOracleCharacterWithReplacementGB(arrayOfChar[b2], arrayOfChar[b2 + 1]);
/*  913 */           b2++;
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */           
/*  919 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  924 */         j = toOracleCharacterGB(arrayOfChar[b2], false);
/*      */       } 
/*      */       
/*  927 */       if (j >> 16 != 0) {
/*      */         
/*  929 */         arrayOfByte[b1++] = (byte)(j >> 24);
/*  930 */         arrayOfByte[b1++] = (byte)(j >> 16);
/*  931 */         arrayOfByte[b1++] = (byte)(j >> 8);
/*  932 */         arrayOfByte[b1++] = (byte)j;
/*      */       }
/*  934 */       else if (j >> 8 != 0) {
/*      */         
/*  936 */         arrayOfByte[b1++] = (byte)(j >> 8);
/*  937 */         arrayOfByte[b1++] = (byte)j;
/*      */       }
/*      */       else {
/*      */         
/*  941 */         arrayOfByte[b1++] = (byte)j;
/*      */       } 
/*      */     } 
/*      */     
/*  945 */     if (b1 < arrayOfByte.length) {
/*      */ 
/*      */ 
/*      */       
/*  949 */       byte[] arrayOfByte1 = new byte[b1];
/*  950 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*      */       
/*  952 */       return arrayOfByte1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  957 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*      */     byte[] arrayOfByte;
/*      */     byte b;
/*  985 */     int i = paramArrayOfint[0];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  990 */     int j = paramInt1 + i;
/*      */ 
/*      */     
/*  993 */     if (paramArrayOfbyte != null) {
/*      */       
/*  995 */       arrayOfByte = paramArrayOfbyte;
/*  996 */       b = paramInt2;
/*      */     }
/*      */     else {
/*      */       
/* 1000 */       arrayOfByte = new byte[i * 4];
/* 1001 */       b = 0;
/* 1002 */       paramInt2 = 0;
/*      */     } 
/*      */     
/* 1005 */     int k = paramInt1; while (true) { if (k < j)
/*      */       { int m;
/*      */         
/* 1008 */         if (paramArrayOfchar[k] >= '?' && paramArrayOfchar[k] <= '?') {
/*      */ 
/*      */           
/* 1011 */           if (k + 1 < j && paramArrayOfchar[k + 1] >= '?' && paramArrayOfchar[k + 1] <= '?') {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1019 */             m = toOracleCharacterWithReplacementGB(paramArrayOfchar[k], paramArrayOfchar[k + 1]);
/* 1020 */             k++;
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 1026 */             arrayOfByte[b++] = (byte)(this.m_2ByteOraCharReplacement >> 8);
/* 1027 */             arrayOfByte[b++] = (byte)this.m_2ByteOraCharReplacement;
/*      */ 
/*      */ 
/*      */             
/*      */             k++;
/*      */           } 
/*      */         } else {
/* 1034 */           m = toOracleCharacterWithReplacementGB(paramArrayOfchar[k], false);
/*      */         } 
/*      */         
/* 1037 */         if (m >> 16 != 0) {
/*      */           
/* 1039 */           arrayOfByte[b++] = (byte)(m >> 24);
/* 1040 */           arrayOfByte[b++] = (byte)(m >> 16);
/* 1041 */           arrayOfByte[b++] = (byte)(m >> 8);
/* 1042 */           arrayOfByte[b++] = (byte)m;
/*      */         }
/* 1044 */         else if (m >> 8 != 0) {
/*      */           
/* 1046 */           arrayOfByte[b++] = (byte)(m >> 8);
/* 1047 */           arrayOfByte[b++] = (byte)m;
/*      */         }
/*      */         else {
/*      */           
/* 1051 */           arrayOfByte[b++] = (byte)m;
/*      */         }  }
/*      */       else { break; }
/*      */        k++; }
/* 1055 */      paramArrayOfint[0] = b - paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1062 */     if (paramArrayOfbyte == null && b < arrayOfByte.length) {
/*      */       
/* 1064 */       byte[] arrayOfByte1 = new byte[b];
/* 1065 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b);
/*      */       
/* 1067 */       return arrayOfByte1;
/*      */     } 
/*      */ 
/*      */     
/* 1071 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int surrogateUtf16ToUcs4(char paramChar1, char paramChar2) {
/* 1078 */     return ((0x3FF & paramChar1) << 10 | paramChar2 & 0x3FF) + 65536;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int surrogateUcs4ToUtf16(int paramInt) {
/* 1084 */     return (paramInt - 65536 >> 10 | 0xD800) << 16 | paramInt & 0x3FF | 0xDC00;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bMPUnicode2Oracle(char paramChar) {
/* 1091 */     int i = searchgbMapping(paramChar, true);
/*      */     
/* 1093 */     if (i == -1)
/*      */     {
/*      */       
/* 1096 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1101 */     return bMPunLinear(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bMPOracle2Unicode(int paramInt) {
/* 1108 */     int i = searchgbMapping((char)bMPLinear(paramInt), false);
/*      */     
/* 1110 */     if (i == -1)
/*      */     {
/*      */       
/* 1113 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1118 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bMPLinear(int paramInt) {
/* 1125 */     return (((paramInt >> 24 & 0xFF) * 10 + (paramInt >> 16 & 0xFF)) * 126 + (paramInt >> 8 & 0xFF)) * 10 + (paramInt & 0xFF) - 1687218;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bMPunLinear(int paramInt) {
/* 1140 */     int i = 0;
/* 1141 */     i = 48 + paramInt % 10 & 0xFF;
/* 1142 */     paramInt /= 10;
/* 1143 */     i += (129 + paramInt % 126 & 0xFF) << 8;
/* 1144 */     paramInt /= 126;
/* 1145 */     i += (48 + paramInt % 10 & 0xFF) << 16;
/* 1146 */     paramInt /= 10;
/* 1147 */     i += (129 + paramInt & 0xFF) << 24;
/*      */     
/* 1149 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int searchgbMapping(char paramChar, boolean paramBoolean) {
/*      */     byte b1, b2;
/*      */     boolean bool;
/* 1164 */     if (paramBoolean) {
/*      */       
/* 1166 */       b1 = 1;
/* 1167 */       b2 = 0;
/* 1168 */       bool = true;
/*      */     }
/*      */     else {
/*      */       
/* 1172 */       b1 = 3;
/* 1173 */       b2 = 2;
/* 1174 */       bool = false;
/*      */     } 
/*      */     
/* 1177 */     int i = gbMapping.length - 1;
/* 1178 */     int j = 0;
/*      */ 
/*      */ 
/*      */     
/* 1182 */     while (i >= j) {
/*      */       
/* 1184 */       int k = (i + j) / 2;
/*      */       
/* 1186 */       if (gbMapping[k][b2] <= paramChar && paramChar <= gbMapping[k][b1])
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1193 */         return paramChar - gbMapping[k][b2] + gbMapping[k][bool];
/*      */       }
/* 1195 */       if (paramChar < gbMapping[k][b2]) {
/*      */         
/* 1197 */         i = k - 1; continue;
/*      */       } 
/* 1199 */       if (paramChar > gbMapping[k][b1])
/*      */       {
/* 1201 */         j = k + 1;
/*      */       }
/*      */     } 
/*      */     
/* 1205 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void buildUnicodeToOracleMapping() {
/* 1239 */     this.m_oraCharLevel1 = new int[256];
/*      */     
/* 1241 */     char[] arrayOfChar = new char[MAXLIMIT];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1252 */     byte b1 = 0;
/* 1253 */     int[][] arrayOfInt = new int[MAXLIMIT][2];
/*      */     
/* 1255 */     byte b2 = 0;
/*      */     byte b3;
/* 1257 */     for (b3 = 0; b3 < 'Ā'; b3++)
/*      */     {
/* 1259 */       this.m_oraCharLevel1[b3] = -1;
/*      */     }
/*      */     
/* 1262 */     for (b3 = 0; b3 < MAXLIMIT; b3++)
/*      */     {
/* 1264 */       arrayOfChar[b3] = Character.MAX_VALUE;
/*      */     }
/*      */     
/* 1267 */     for (b3 = 0; b3 < '￿'; b3++) {
/*      */ 
/*      */       
/* 1270 */       int i = toUnicodeWithReplacement(b3);
/* 1271 */       if (i != this.m_ucsCharReplacement) {
/* 1272 */         arrayOfInt[b2][0] = i;
/* 1273 */         arrayOfInt[b2][1] = b3;
/* 1274 */         b2++;
/*      */       } 
/*      */     } 
/*      */     
/* 1278 */     for (b3 = 0; b3 < arrayOfInt.length; b3++) {
/*      */       
/* 1280 */       int i = arrayOfInt[b3][0] >>> 8 & 0xFF;
/* 1281 */       int j = arrayOfInt[b3][0] & 0xFF;
/*      */       
/* 1283 */       if (this.m_oraCharLevel1[i] == -1) {
/*      */         
/* 1285 */         this.m_oraCharLevel1[i] = b1;
/* 1286 */         b1 += true;
/*      */       } 
/*      */       
/* 1289 */       if (arrayOfChar[this.m_oraCharLevel1[i] + j] == Character.MAX_VALUE)
/*      */       {
/* 1291 */         arrayOfChar[this.m_oraCharLevel1[i] + j] = (char)(arrayOfInt[b3][1] & 0xFFFF);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1301 */     if (this.extraUnicodeToOracleMapping != null) {
/*      */       
/* 1303 */       int i = this.extraUnicodeToOracleMapping.length;
/*      */       
/* 1305 */       for (b3 = 0; b3 < i; b3++) {
/*      */ 
/*      */ 
/*      */         
/* 1309 */         int m = this.extraUnicodeToOracleMapping[b3][0];
/*      */ 
/*      */ 
/*      */         
/* 1313 */         int j = m >>> 8 & 0xFF;
/* 1314 */         int k = m & 0xFF;
/* 1315 */         j = arrayOfInt[b3][0] >>> 8 & 0xFF;
/* 1316 */         k = arrayOfInt[b3][0] & 0xFF;
/*      */         
/* 1318 */         if (this.m_oraCharLevel1[j] == -1) {
/*      */           
/* 1320 */           this.m_oraCharLevel1[j] = b1;
/* 1321 */           b1 += true;
/*      */         } 
/*      */         
/* 1324 */         if (arrayOfChar[this.m_oraCharLevel1[j] + k] == Character.MAX_VALUE)
/*      */         {
/*      */ 
/*      */           
/* 1328 */           arrayOfChar[this.m_oraCharLevel1[j] + k] = (char)(arrayOfInt[b3][1] & 0xFFFF);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1339 */     this.m_oraCharLevel2 = new char[b1];
/*      */     
/* 1341 */     for (b3 = 0; b3 < b1; b3++)
/*      */     {
/* 1343 */       this.m_oraCharLevel2[b3] = arrayOfChar[b3];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void extractCodepoints(Vector<int[]> paramVector) {
/* 1353 */     byte b1 = 0;
/* 1354 */     char c = '￿';
/*      */ 
/*      */     
/* 1357 */     for (byte b2 = b1; b2 <= c; b2++) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/* 1362 */         int[] arrayOfInt = new int[2];
/* 1363 */         arrayOfInt[0] = b2;
/* 1364 */         arrayOfInt[1] = (char)toUnicode(b2);
/*      */ 
/*      */ 
/*      */         
/* 1368 */         paramVector.addElement(arrayOfInt);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1373 */       catch (SQLException sQLException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void extractExtraMappings(Vector<int[]> paramVector) {
/* 1384 */     if (this.extraUnicodeToOracleMapping == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1392 */     for (byte b = 0; b < this.extraUnicodeToOracleMapping.length; b++) {
/*      */       
/* 1394 */       int[] arrayOfInt = new int[2];
/* 1395 */       arrayOfInt[0] = this.extraUnicodeToOracleMapping[b][0];
/* 1396 */       arrayOfInt[1] = this.extraUnicodeToOracleMapping[b][1];
/* 1397 */       paramVector.addElement(arrayOfInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasExtraMappings() {
/* 1404 */     return (this.extraUnicodeToOracleMapping != null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public char getOraChar1ByteRep() {
/* 1410 */     return this.m_1ByteOraCharReplacement;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public char getOraChar2ByteRep() {
/* 1416 */     return this.m_2ByteOraCharReplacement;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUCS2CharRep() {
/* 1422 */     return this.m_ucsCharReplacement;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] paramArrayOfString) throws SQLException {
/* 1428 */     CharacterConverterGB18030 characterConverterGB18030 = new CharacterConverterGB18030();
/* 1429 */     System.out.println(characterConverterGB18030.bMPLinear(-2127527632));
/* 1430 */     System.out.println(characterConverterGB18030.bMPunLinear(characterConverterGB18030.bMPLinear(-2127527632)));
/* 1431 */     System.out.println(characterConverterGB18030.bMPLinear(-1875869392));
/* 1432 */     System.out.println(characterConverterGB18030.bMPunLinear(characterConverterGB18030.bMPLinear(-1875869392)));
/*      */ 
/*      */ 
/*      */     
/* 1436 */     System.out.println(characterConverterGB18030.bMPUnicode2Oracle(''));
/* 1437 */     System.out.println(characterConverterGB18030.bMPOracle2Unicode(-2127525063));
/* 1438 */     System.out.println(characterConverterGB18030
/* 1439 */         .toOracleCharacterWithReplacement('?', '?'));
/*      */     
/* 1441 */     System.out.println(characterConverterGB18030
/* 1442 */         .toOracleCharacterWithReplacement('?', '?'));
/*      */     
/* 1444 */     System.out.println(characterConverterGB18030
/* 1445 */         .toOracleCharacter('?', '?'));
/*      */     
/* 1447 */     System.out.println(characterConverterGB18030
/* 1448 */         .toOracleCharacter('?', '?'));
/*      */     
/* 1450 */     System.out.println(characterConverterGB18030.toUnicode(-1875869392));
/* 1451 */     System.out.println(characterConverterGB18030.toUnicode(-483222987));
/*      */   }
/*      */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterGB18030.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
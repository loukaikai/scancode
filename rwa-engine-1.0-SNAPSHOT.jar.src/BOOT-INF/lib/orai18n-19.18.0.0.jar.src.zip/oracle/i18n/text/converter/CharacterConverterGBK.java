/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverterGBK
/*     */   extends CharacterConverter12Byte
/*     */ {
/*     */   static final short MAX_8BIT = 128;
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  54 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/*  58 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  59 */     byte b = 0;
/*  60 */     int j = paramInt1;
/*     */ 
/*     */ 
/*     */     
/*  64 */     while (j < i) {
/*     */ 
/*     */       
/*  67 */       int k = paramArrayOfbyte[j] & 0xFF;
/*     */       
/*  69 */       if (k > 128)
/*     */       {
/*     */ 
/*     */         
/*  73 */         if (j < i - 1) {
/*     */           
/*  75 */           k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */           
/*  77 */           j++;
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/*  85 */           throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       int m = toUnicode(k);
/*     */       
/*  94 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */         
/*  96 */         arrayOfChar[b++] = (char)(m >>> 16);
/*  97 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 101 */         arrayOfChar[b++] = (char)m;
/*     */       } 
/*     */       
/* 104 */       j++;
/*     */     } 
/*     */     
/* 107 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 119 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/* 123 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 124 */     byte b = 0;
/* 125 */     int j = paramInt1;
/*     */ 
/*     */ 
/*     */     
/* 129 */     while (j < i) {
/*     */ 
/*     */       
/* 132 */       int k = paramArrayOfbyte[j] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       if (k > 128) {
/*     */         
/* 140 */         if (i - j < 2) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 148 */         k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */         
/* 150 */         j++;
/*     */       } 
/*     */ 
/*     */       
/* 154 */       int m = toUnicodeWithReplacement(k);
/*     */       
/* 156 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 158 */         arrayOfChar[b++] = (char)(m >>> 16);
/* 159 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 163 */         arrayOfChar[b++] = (char)m;
/*     */       } 
/*     */       
/* 166 */       j++;
/*     */     } 
/*     */     
/* 169 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterGBK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
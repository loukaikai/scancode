/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages_es
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents() {
/* 26 */     return this.contents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private Object[][] contents = new Object[][] { { "17154", "no se puede asignar el carácter Oracle a Unicode" }, { "17155", "no se puede asignar Unicode al carácter Oracle" }, { "7002", "sustitución Unicode no válida" } };
/*    */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\Messages_es.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverterShift
/*     */   extends CharacterConverter12Byte
/*     */ {
/*  42 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*  43 */   public final byte SHIFT_OUT = 14;
/*  44 */   public final byte SHIFT_IN = 15;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharacterConverterShift() {
/*  51 */     this.m_groupId = 7;
/*  52 */     this.averageCharsPerByte = 1.0F;
/*  53 */     this.maxCharsPerByte = 1.0F;
/*  54 */     this.maxBytesPerChar = 4.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  71 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/*  75 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  76 */     byte b1 = 0;
/*  77 */     int j = paramInt1;
/*     */ 
/*     */     
/*  80 */     byte b2 = 15;
/*     */     
/*  82 */     while (j < i) {
/*     */       
/*  84 */       if (paramArrayOfbyte[j] == 15) {
/*     */         
/*  86 */         b2 = 15;
/*  87 */         j++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*  92 */       if (paramArrayOfbyte[j] == 14) {
/*     */         
/*  94 */         b2 = 14;
/*  95 */         j++;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 101 */       if (b2 == 15) {
/*     */ 
/*     */         
/* 104 */         int k = paramArrayOfbyte[j] & 0xFF;
/*     */ 
/*     */         
/* 107 */         int m = toUnicode(k);
/*     */         
/* 109 */         if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */           
/* 111 */           arrayOfChar[b1++] = (char)(m >>> 16);
/* 112 */           arrayOfChar[b1++] = (char)(m & 0xFFFF);
/*     */         }
/*     */         else {
/*     */           
/* 116 */           arrayOfChar[b1++] = (char)m;
/*     */         } 
/*     */         
/* 119 */         j++;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 125 */       if (j < i - 1) {
/*     */         
/* 127 */         int k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */ 
/*     */ 
/*     */         
/* 131 */         int m = toUnicode(k);
/*     */         
/* 133 */         if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */           
/* 135 */           arrayOfChar[b1++] = (char)(m >>> 16);
/* 136 */           arrayOfChar[b1++] = (char)(m & 0xFFFF);
/*     */         }
/*     */         else {
/*     */           
/* 140 */           arrayOfChar[b1++] = (char)m;
/*     */         } 
/*     */         
/* 143 */         j += 2;
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 151 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     return new String(arrayOfChar, 0, b1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 170 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/* 174 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 175 */     byte b1 = 0;
/* 176 */     int j = paramInt1;
/*     */ 
/*     */     
/* 179 */     byte b2 = 15;
/*     */     
/* 181 */     while (j < i) {
/*     */       
/* 183 */       if (paramArrayOfbyte[j] == 15) {
/*     */         
/* 185 */         b2 = 15;
/* 186 */         j++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 191 */       if (paramArrayOfbyte[j] == 14) {
/*     */         
/* 193 */         b2 = 14;
/* 194 */         j++;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 200 */       if (b2 == 15) {
/*     */ 
/*     */         
/* 203 */         int k = paramArrayOfbyte[j] & 0xFF;
/*     */ 
/*     */         
/* 206 */         int m = toUnicodeWithReplacement(k);
/*     */         
/* 208 */         if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */           
/* 210 */           arrayOfChar[b1++] = (char)(m >>> 16);
/* 211 */           arrayOfChar[b1++] = (char)(m & 0xFFFF);
/*     */         }
/*     */         else {
/*     */           
/* 215 */           arrayOfChar[b1++] = (char)m;
/*     */         } 
/*     */         
/* 218 */         j++;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 224 */       if (j < i - 1) {
/*     */         
/* 226 */         int k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */ 
/*     */         
/* 229 */         int m = toUnicodeWithReplacement(k);
/*     */         
/* 231 */         if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */           
/* 233 */           arrayOfChar[b1++] = (char)(m >>> 16);
/* 234 */           arrayOfChar[b1++] = (char)(m & 0xFFFF);
/*     */         }
/*     */         else {
/*     */           
/* 238 */           arrayOfChar[b1++] = (char)m;
/*     */         } 
/*     */         
/* 241 */         j += 2;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     return new String(arrayOfChar, 0, b1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleString(String paramString) throws SQLException {
/* 263 */     int i = paramString.length();
/*     */     
/* 265 */     if (i == 0)
/*     */     {
/* 267 */       return new byte[0];
/*     */     }
/*     */     
/* 270 */     char[] arrayOfChar = new char[i];
/* 271 */     paramString.getChars(0, i, arrayOfChar, 0);
/*     */     
/* 273 */     byte[] arrayOfByte = new byte[i * 4];
/*     */ 
/*     */     
/* 276 */     byte b1 = 0;
/* 277 */     byte b2 = 15;
/*     */     
/* 279 */     for (byte b3 = 0; b3 < i; b3++) {
/*     */       char c;
/* 281 */       if (arrayOfChar[b3] >= '?' && arrayOfChar[b3] < '?') {
/*     */         
/* 283 */         if (b3 + 1 < i && arrayOfChar[b3 + 1] >= '?' && arrayOfChar[b3 + 1] <= '?')
/*     */         {
/*     */ 
/*     */           
/* 287 */           c = toOracleCharacterWithReplacement(arrayOfChar[b3], arrayOfChar[b3 + 1]);
/*     */           
/* 289 */           b3++;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 294 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 299 */         c = toOracleCharacter(arrayOfChar[b3], false);
/*     */       } 
/*     */       int j;
/* 302 */       if ((j = c & 0xFF00) != 0) {
/*     */ 
/*     */         
/* 305 */         if (b2 == 15) {
/*     */           
/* 307 */           b2 = 14;
/* 308 */           arrayOfByte[b1++] = 14;
/*     */         } 
/*     */         
/* 311 */         arrayOfByte[b1++] = (byte)(j >> 8);
/* 312 */         arrayOfByte[b1++] = (byte)c;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 317 */         if (b2 == 14) {
/*     */           
/* 319 */           b2 = 15;
/* 320 */           arrayOfByte[b1++] = 15;
/*     */         } 
/*     */         
/* 323 */         arrayOfByte[b1++] = (byte)c;
/*     */       } 
/*     */     } 
/*     */     
/* 327 */     if (b1 < arrayOfByte.length) {
/*     */ 
/*     */       
/* 330 */       byte[] arrayOfByte1 = new byte[b1];
/* 331 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*     */       
/* 333 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 337 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*     */     byte[] arrayOfByte;
/*     */     byte b1;
/* 365 */     int i = paramArrayOfint[0];
/*     */ 
/*     */ 
/*     */     
/* 369 */     char c = '￿';
/* 370 */     int j = paramInt1 + i;
/* 371 */     byte b2 = 15;
/*     */ 
/*     */     
/* 374 */     if (paramArrayOfbyte != null) {
/*     */       
/* 376 */       arrayOfByte = paramArrayOfbyte;
/* 377 */       b1 = paramInt2;
/*     */     }
/*     */     else {
/*     */       
/* 381 */       arrayOfByte = new byte[i * 4];
/* 382 */       b1 = 0;
/* 383 */       paramInt2 = 0;
/*     */     } 
/*     */     
/* 386 */     for (int k = paramInt1; k < j; k++) {
/*     */       
/* 388 */       if (paramArrayOfchar[k] >= '?' && paramArrayOfchar[k] < '?') {
/*     */         
/* 390 */         if (k + 1 < j && paramArrayOfchar[k + 1] >= '?' && paramArrayOfchar[k + 1] <= '?')
/*     */         {
/*     */ 
/*     */           
/* 394 */           c = toOracleCharacterWithReplacement(paramArrayOfchar[k], paramArrayOfchar[k + 1]);
/*     */           
/* 396 */           k++;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 401 */           arrayOfByte[b1++] = (byte)(this.m_2ByteOraCharReplacement >> 8);
/* 402 */           arrayOfByte[b1++] = (byte)this.m_2ByteOraCharReplacement;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 407 */         c = toOracleCharacterWithReplacement(paramArrayOfchar[k], false);
/*     */       } 
/*     */       int m;
/* 410 */       if ((m = c & 0xFF00) != 0) {
/*     */ 
/*     */         
/* 413 */         if (b2 == 15) {
/*     */           
/* 415 */           b2 = 14;
/* 416 */           arrayOfByte[b1++] = 14;
/*     */         } 
/*     */         
/* 419 */         arrayOfByte[b1++] = (byte)(m >> 8);
/* 420 */         arrayOfByte[b1++] = (byte)c;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 425 */         if (b2 == 14) {
/*     */           
/* 427 */           b2 = 15;
/* 428 */           arrayOfByte[b1++] = 15;
/*     */         } 
/*     */         
/* 431 */         arrayOfByte[b1++] = (byte)c;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 436 */     if (b2 == 14) {
/*     */       
/* 438 */       b2 = 15;
/* 439 */       arrayOfByte[b1++] = 15;
/*     */     } 
/*     */ 
/*     */     
/* 443 */     paramArrayOfint[0] = b1 - paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 450 */     if (paramArrayOfbyte == null && b1 < arrayOfByte.length) {
/*     */       
/* 452 */       byte[] arrayOfByte1 = new byte[b1];
/* 453 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*     */       
/* 455 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 459 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterShift.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverterSJIS
/*     */   extends CharacterConverter12Byte
/*     */ {
/*  50 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final short MIN_8BIT_SB = 161;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final short MAX_8BIT_SB = 223;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  79 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/*  83 */     char[] arrayOfChar = new char[paramInt2 * 2];
/*  84 */     byte b = 0;
/*  85 */     int j = paramInt1;
/*     */ 
/*     */ 
/*     */     
/*  89 */     while (j < i) {
/*     */ 
/*     */       
/*  92 */       int k = paramArrayOfbyte[j] & 0xFF;
/*     */       
/*  94 */       if (k > 223 || (k > 127 && k < 161))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*  99 */         if (j < i - 1) {
/*     */           
/* 101 */           k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */           
/* 103 */           j++;
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 111 */           throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 118 */       int m = toUnicode(k);
/*     */       
/* 120 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 122 */         arrayOfChar[b++] = (char)(m >>> 16);
/* 123 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 127 */         arrayOfChar[b++] = (char)m;
/*     */       } 
/*     */       
/* 130 */       j++;
/*     */     } 
/*     */     
/* 133 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 145 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/* 149 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 150 */     byte b = 0;
/* 151 */     int j = paramInt1;
/*     */ 
/*     */ 
/*     */     
/* 155 */     while (j < i) {
/*     */ 
/*     */       
/* 158 */       int k = paramArrayOfbyte[j] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       if ((k > 223 || (k > 127 && k < 161)) && j < i - 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 171 */         k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */         
/* 173 */         j++;
/*     */       } 
/*     */ 
/*     */       
/* 177 */       int m = toUnicodeWithReplacement(k);
/*     */       
/* 179 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 181 */         arrayOfChar[b++] = (char)(m >>> 16);
/* 182 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 186 */         arrayOfChar[b++] = (char)m;
/*     */       } 
/*     */       
/* 189 */       j++;
/*     */     } 
/*     */     
/* 192 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterSJIS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.text.converter.CharacterConverterOGS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetWithConverter
/*     */   extends OraCharset
/*     */ {
/*     */   private CharacterConverterOGS charConverter;
/*     */   
/*     */   OraCharsetWithConverter(String paramString, int paramInt, CharacterConverterOGS paramCharacterConverterOGS) {
/*  39 */     super(paramString, paramInt);
/*  40 */     this.charConverter = paramCharacterConverterOGS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static OraCharset getInstance(String paramString, int paramInt) {
/*  46 */     return new OraCharsetWithConverter(paramString, paramInt, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/*  52 */     if (this.charConverter == null)
/*  53 */       this
/*  54 */         .charConverter = (CharacterConverterOGS)CharacterConverterOGS.getInstance(this.oracleId); 
/*  55 */     return new OraCharsetDecoder(this, this.charConverter.getAverageRatio(), this.charConverter
/*  56 */         .getMaxRatio());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/*  63 */     if (this.charConverter == null) {
/*  64 */       this
/*  65 */         .charConverter = (CharacterConverterOGS)CharacterConverterOGS.getInstance(this.oracleId);
/*     */     }
/*  67 */     if (this.charConverter.getGroupId() == 6 || this.charConverter
/*  68 */       .getGroupId() == 3) {
/*     */ 
/*     */ 
/*     */       
/*  72 */       CharacterConverterOGS characterConverterOGS = this.charConverter;
/*  73 */       char c = characterConverterOGS.getOraChar2ByteRep();
/*     */       
/*  75 */       return new OraCharsetEncoder(this, 1.0F / this.charConverter.getAverageRatio(), this.charConverter
/*  76 */           .getMaxBytesRatio(), new byte[] { (byte)(c >>> 8), (byte)c });
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     return new OraCharsetEncoder(this, 1.0F / this.charConverter.getAverageRatio(), this.charConverter
/*  84 */         .getMaxBytesRatio());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  92 */     if (this.charConverter == null)
/*  93 */       this
/*  94 */         .charConverter = (CharacterConverterOGS)CharacterConverterOGS.getInstance(this.oracleId); 
/*  95 */     return this.charConverter.toUnicodeStringWithReplacement(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 102 */     if (this.charConverter == null)
/* 103 */       this
/* 104 */         .charConverter = (CharacterConverterOGS)CharacterConverterOGS.getInstance(this.oracleId); 
/* 105 */     return this.charConverter.toUnicodeString(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convertWithReplacement(String paramString) {
/* 111 */     if (this.charConverter == null)
/* 112 */       this
/* 113 */         .charConverter = (CharacterConverterOGS)CharacterConverterOGS.getInstance(this.oracleId); 
/* 114 */     return this.charConverter.toOracleStringWithReplacement(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convert(String paramString) throws SQLException {
/* 120 */     if (this.charConverter == null)
/* 121 */       this
/* 122 */         .charConverter = (CharacterConverterOGS)CharacterConverterOGS.getInstance(this.oracleId); 
/* 123 */     return this.charConverter.toOracleString(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetWithConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
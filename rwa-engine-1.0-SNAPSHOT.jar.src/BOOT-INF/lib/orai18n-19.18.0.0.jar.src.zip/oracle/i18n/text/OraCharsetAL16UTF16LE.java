/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.io.UTFDataFormatException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.text.converter.GDKMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetAL16UTF16LE
/*     */   extends OraCharset
/*     */ {
/*  32 */   static final byte[] REPLACEMENT_CHAR_IN_BYTES = new byte[] { -3, -1 };
/*     */   
/*     */   OraCharsetAL16UTF16LE(String paramString, int paramInt) {
/*  35 */     super(paramString, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Charset paramCharset) {
/*  41 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/*  47 */     return new OraCharsetDecoder(this, 0.5F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/*  53 */     return new OraCharsetEncoder(this, 2.0F, 2.0F, REPLACEMENT_CHAR_IN_BYTES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/*  61 */       char[] arrayOfChar = new char[Math.min(paramArrayOfbyte.length - paramInt1 >>> 1, paramInt2 >>> 1)];
/*     */       
/*  63 */       int i = AL16UTF16LEBytesToJavaChars(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPLACEMENT);
/*     */ 
/*     */ 
/*     */       
/*  67 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  69 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */ 
/*     */       
/*  72 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/*  84 */       char[] arrayOfChar = new char[Math.min(paramArrayOfbyte.length - paramInt1 >>> 1, paramInt2 >>> 1)];
/*     */       
/*  86 */       int i = AL16UTF16LEBytesToJavaChars(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPORT_ERROR);
/*     */ 
/*     */ 
/*     */       
/*  90 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  92 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */       
/*  94 */       throw new SQLException(GDKMessage.getORAMessage(17037));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convertWithReplacement(String paramString) {
/* 101 */     char[] arrayOfChar = paramString.toCharArray();
/* 102 */     byte[] arrayOfByte = new byte[arrayOfChar.length * 2];
/* 103 */     javaCharsToAL16UTF16LEBytes(arrayOfChar, arrayOfChar.length, arrayOfByte);
/*     */     
/* 105 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convert(String paramString) {
/* 111 */     return convertWithReplacement(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetAL16UTF16LE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
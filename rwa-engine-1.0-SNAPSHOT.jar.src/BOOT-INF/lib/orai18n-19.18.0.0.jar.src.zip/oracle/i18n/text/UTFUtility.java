/*     */ package oracle.i18n.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UTFUtility
/*     */ {
/*     */   public static final boolean isHiSurrogate(char paramChar) {
/*  40 */     return ((char)(paramChar & 0xFC00) == '?');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isLoSurrogate(char paramChar) {
/*  55 */     return ((char)(paramChar & 0xFC00) == '?');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean check80toBF(byte paramByte) {
/*  69 */     return ((paramByte & 0xFFFFFFC0) == -128);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean check80to8F(byte paramByte) {
/*  82 */     return ((paramByte & 0xFFFFFFF0) == -128);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean check80to9F(byte paramByte) {
/*  94 */     return ((paramByte & 0xFFFFFFE0) == -128);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean checkA0toBF(byte paramByte) {
/* 106 */     return ((paramByte & 0xFFFFFFE0) == -96);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean check90toBF(byte paramByte) {
/* 118 */     return ((paramByte & 0xFFFFFFC0) == -128 && (paramByte & 0x30) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final char conv2ByteUTFtoUTF16(byte paramByte1, byte paramByte2) {
/* 132 */     if (paramByte1 < -62 || paramByte1 > -33 || !check80toBF(paramByte2))
/*     */     {
/* 134 */       return '�';
/*     */     }
/*     */     
/* 137 */     return (char)((paramByte1 & 0x1F) << 6 | paramByte2 & 0x3F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final char conv3ByteUTFtoUTF16(byte paramByte1, byte paramByte2, byte paramByte3) {
/* 155 */     if ((paramByte1 != -32 || 
/* 156 */       !checkA0toBF(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 < -31 || paramByte1 > -17 || 
/* 157 */       !check80toBF(paramByte2) || 
/* 158 */       !check80toBF(paramByte3)))
/*     */     {
/* 160 */       return '�';
/*     */     }
/*     */     
/* 163 */     return (char)((paramByte1 & 0xF) << 12 | (paramByte2 & 0x3F) << 6 | paramByte3 & 0x3F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final char conv3ByteAL32UTF8toUTF16(byte paramByte1, byte paramByte2, byte paramByte3) {
/* 184 */     if ((paramByte1 != -32 || 
/* 185 */       !checkA0toBF(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 < -31 || paramByte1 > -20 || 
/* 186 */       !check80toBF(paramByte2) || 
/* 187 */       !check80toBF(paramByte3)) && (paramByte1 != -19 || 
/* 188 */       !check80to9F(paramByte2) || !check80toBF(paramByte3)) && (paramByte1 < -18 || paramByte1 > -17 || 
/* 189 */       !check80toBF(paramByte2) || 
/* 190 */       !check80toBF(paramByte3)))
/*     */     {
/* 192 */       return '�';
/*     */     }
/*     */     
/* 195 */     return (char)((paramByte1 & 0xF) << 12 | (paramByte2 & 0x3F) << 6 | paramByte3 & 0x3F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int conv4ByteAL32UTF8toUTF16(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, char[] paramArrayOfchar, int paramInt) {
/* 214 */     boolean bool = false;
/*     */     
/* 216 */     if ((paramByte1 != -16 || 
/* 217 */       !check90toBF(paramByte2) || !check80toBF(paramByte3) || 
/* 218 */       !check80toBF(paramByte4)) && (paramByte1 < -15 || paramByte1 > -13 || 
/* 219 */       !check80toBF(paramByte2) || 
/* 220 */       !check80toBF(paramByte3) || !check80toBF(paramByte4)) && (paramByte1 != -12 || 
/* 221 */       !check80to8F(paramByte2) || !check80toBF(paramByte3) || 
/* 222 */       !check80toBF(paramByte4))) {
/*     */       
/* 224 */       paramArrayOfchar[paramInt] = '�';
/*     */       
/* 226 */       return 1;
/*     */     } 
/*     */     
/* 229 */     paramArrayOfchar[paramInt] = (char)((((paramByte1 & 0x7) << 2 | paramByte2 >>> 4 & 0x3) - 1 & 0xF) << 6 | (paramByte2 & 0xF) << 2 | paramByte3 >>> 4 & 0x3 | 0xD800);
/*     */ 
/*     */ 
/*     */     
/* 233 */     paramArrayOfchar[paramInt + 1] = (char)((paramByte3 & 0xF) << 6 | paramByte4 & 0x3F | 0xDC00);
/*     */ 
/*     */     
/* 236 */     return 2;
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\UTFUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
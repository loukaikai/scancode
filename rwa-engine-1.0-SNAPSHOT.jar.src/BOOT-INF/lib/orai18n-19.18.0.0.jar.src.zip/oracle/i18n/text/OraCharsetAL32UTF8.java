/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.io.UTFDataFormatException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.text.converter.GDKMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetAL32UTF8
/*     */   extends OraCharset
/*     */ {
/*     */   OraCharsetAL32UTF8(String paramString, int paramInt) {
/*  37 */     super(paramString, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Charset paramCharset) {
/*  43 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/*  49 */     return new OraCharsetDecoder(this, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/*  55 */     return new OraCharsetEncoder(this, 1.0F, 4.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/*  73 */       char[] arrayOfChar = new char[paramArrayOfbyte.length];
/*     */       
/*  75 */       int i = AL32UTF8ToJavaChar(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPLACEMENT);
/*     */ 
/*     */ 
/*     */       
/*  79 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  81 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */ 
/*     */ 
/*     */       
/*  85 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/* 110 */       char[] arrayOfChar = new char[paramArrayOfbyte.length];
/*     */       
/* 112 */       int i = AL32UTF8ToJavaChar(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPORT_ERROR);
/*     */ 
/*     */ 
/*     */       
/* 116 */       return new String(arrayOfChar, 0, i);
/*     */     }
/* 118 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */       
/* 120 */       throw new SQLException(GDKMessage.getORAMessage(17037));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convertWithReplacement(String paramString) {
/* 135 */     char[] arrayOfChar = paramString.toCharArray();
/* 136 */     byte[] arrayOfByte1 = new byte[arrayOfChar.length * 3];
/* 137 */     int i = javaCharsToAL32UTF8(arrayOfChar, 0, arrayOfChar.length, arrayOfByte1, 0);
/* 138 */     byte[] arrayOfByte2 = new byte[i];
/* 139 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
/*     */     
/* 141 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convert(String paramString) throws SQLException {
/* 156 */     return convertWithReplacement(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\16509\Desktop\工作文档\稠州银行\代码文件\rwa-engine-1.0-SNAPSHOT\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetAL32UTF8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
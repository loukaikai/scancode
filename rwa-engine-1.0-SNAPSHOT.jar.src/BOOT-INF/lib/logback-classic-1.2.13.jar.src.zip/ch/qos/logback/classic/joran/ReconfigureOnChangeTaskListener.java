package ch.qos.logback.classic.joran;

public class ReconfigureOnChangeTaskListener {
    void enteredRunMethod() {
    }

    void changeDetected() {
    }

    void doneReconfiguring() {
    }
}

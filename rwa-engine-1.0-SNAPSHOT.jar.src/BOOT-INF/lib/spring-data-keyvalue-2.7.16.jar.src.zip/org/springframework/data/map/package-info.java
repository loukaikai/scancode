/**
 * Repository implementation backed by generic {@link java.util.Map} instances.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.map;

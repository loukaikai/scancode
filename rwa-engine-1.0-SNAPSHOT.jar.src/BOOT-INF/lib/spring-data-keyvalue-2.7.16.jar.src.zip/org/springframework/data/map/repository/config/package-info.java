/**
 * Support infrastructure for the configuration of {@link java.util.Map} repositories.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.map.repository.config;

/**
 * Key-Value annotations for declarative keyspace configuration.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.annotation;

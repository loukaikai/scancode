/**
 * Key/value specific query and abstractions.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.core.query;

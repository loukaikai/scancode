/**
 * Query derivation mechanism for key/value specific repositories providing a generic SpEL based implementation.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.repository.query;

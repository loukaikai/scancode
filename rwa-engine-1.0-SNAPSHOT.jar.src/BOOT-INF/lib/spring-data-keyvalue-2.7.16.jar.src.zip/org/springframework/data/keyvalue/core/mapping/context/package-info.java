/**
 * Infrastructure for the Key-Value mapping context.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.core.mapping.context;

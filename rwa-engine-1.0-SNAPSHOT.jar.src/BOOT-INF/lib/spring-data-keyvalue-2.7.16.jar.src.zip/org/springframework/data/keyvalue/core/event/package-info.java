/**
 * Support classes for key-value events, like standard persistence lifecycle events.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.core.event;

/**
 * Support infrastructure for query derivation of key/value specific repositories.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.repository.support;

/**
 * Infrastructure for the Key-Value mapping subsystem and keyspace resolution.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.keyvalue.core.mapping;

package com.ulisesbocchio.jasyptspringboot;

/**
 * @author Ulises Bocchio
 */
public enum InterceptionMode {
    WRAPPER,
    PROXY
}

/**
 * Provides an namespace handler for the Spring Object/XML namespace.
 */
@NonNullApi
@NonNullFields
package org.springframework.oxm.config;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;

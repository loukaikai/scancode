/**
 * IO相关封装和工具类，包括Inputstream和OutputStream实现类，工具包括流工具IoUtil、文件工具FileUtil和Buffer工具BufferUtil
 *
 * @author looly
 *
 */
package cn.hutool.core.io;
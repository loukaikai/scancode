/**
 * FileVisitor功能性实现，包括递归删除、拷贝等
 *
 * @author looly
 *
 */
package cn.hutool.core.io.file.visitor;
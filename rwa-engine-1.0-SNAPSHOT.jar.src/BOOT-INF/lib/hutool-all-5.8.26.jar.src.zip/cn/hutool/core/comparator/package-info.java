/**
 * 各种比较器（Comparator）实现和封装
 *
 * @author looly
 *
 */
package cn.hutool.core.comparator;
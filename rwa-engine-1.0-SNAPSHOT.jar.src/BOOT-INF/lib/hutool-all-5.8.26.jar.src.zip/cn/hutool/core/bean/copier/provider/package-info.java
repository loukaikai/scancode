/**
 * Bean值提供者方式封装
 *
 * @author looly
 *
 */
package cn.hutool.core.bean.copier.provider;
/**
 * 压缩解压封装
 *
 * @author looly
 * @since 5.7.8
 */
package cn.hutool.core.compress;

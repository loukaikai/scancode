/**
 * GIF处理，来自：https://github.com/rtyley/animated-gif-lib-for-java
 *
 * @author looly
 *
 */
package cn.hutool.core.img.gif;
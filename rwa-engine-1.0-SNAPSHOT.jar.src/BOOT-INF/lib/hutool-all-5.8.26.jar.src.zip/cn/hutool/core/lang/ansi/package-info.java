/**
 * 命令行终端中ANSI 转义序列相关封装，如ANSI颜色等
 *
 * @author spring, looly
 */
package cn.hutool.core.lang.ansi;

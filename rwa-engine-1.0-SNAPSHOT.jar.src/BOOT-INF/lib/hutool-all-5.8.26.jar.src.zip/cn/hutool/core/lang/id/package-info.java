/**
 * 提供各种ID生成
 *
 * @author looly
 * @since 5.7.5
 */
package cn.hutool.core.lang.id;

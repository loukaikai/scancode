package cn.hutool.core.lang.ansi;

/**
 * 区分前景还是背景
 */
public enum ForeOrBack{

	/**
	 * 前景
	 */
	FORE,
	/**
	 * 背景
	 */
	BACK,
}

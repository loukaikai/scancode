/**
 * 规范化表示形式封装<br>
 * 所谓规范化，即当两个对象equals时，规范化的对象则可以实现==<br>
 * 此包中的相关封装类似于 String#intern()
 *
 * @author looly
 */
package cn.hutool.core.lang.intern;
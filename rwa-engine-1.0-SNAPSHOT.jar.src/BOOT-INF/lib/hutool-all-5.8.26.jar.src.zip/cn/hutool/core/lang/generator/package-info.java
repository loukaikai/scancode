/**
 * 提供生成器接口及相关封装
 *
 * @author looly
 *
 */
package cn.hutool.core.lang.generator;
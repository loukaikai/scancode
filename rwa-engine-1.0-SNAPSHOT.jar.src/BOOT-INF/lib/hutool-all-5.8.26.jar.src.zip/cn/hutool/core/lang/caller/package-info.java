/**
 * 调用者接口及实现。可以通过此类的方法获取调用者、多级调用者以及判断是否被调用
 *
 * @author looly
 *
 */
package cn.hutool.core.lang.caller;
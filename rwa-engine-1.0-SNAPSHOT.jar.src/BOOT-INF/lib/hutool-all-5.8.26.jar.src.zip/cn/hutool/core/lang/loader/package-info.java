/**
 * 加载器的抽象接口和实现，包括懒加载的实现等
 *
 * @author looly
 *
 */
package cn.hutool.core.lang.loader;
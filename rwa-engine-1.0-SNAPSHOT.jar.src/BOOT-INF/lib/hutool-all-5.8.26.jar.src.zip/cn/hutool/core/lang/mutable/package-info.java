/**
 * 提供可变值对象的封装，用于封装int、long等不可变值，使其可变
 *
 * @author looly
 *
 */
package cn.hutool.core.lang.mutable;
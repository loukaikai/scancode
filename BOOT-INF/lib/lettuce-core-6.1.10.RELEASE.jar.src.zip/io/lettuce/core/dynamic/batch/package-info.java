/**
 * Batching with Redis Command interfaces.
 */
package io.lettuce.core.dynamic.batch;

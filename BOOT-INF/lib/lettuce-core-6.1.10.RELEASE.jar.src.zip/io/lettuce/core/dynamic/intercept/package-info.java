/**
 * Invocation proxy support.
 */
package io.lettuce.core.dynamic.intercept;

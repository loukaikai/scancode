/**
 * {@link io.lettuce.core.codec.RedisCodec} resolution support.
 */
package io.lettuce.core.dynamic.codec;

/**
 * Support for {@link io.lettuce.core.dynamic.segment.CommandSegments} and segment parsing.
 */
package io.lettuce.core.dynamic.segment;

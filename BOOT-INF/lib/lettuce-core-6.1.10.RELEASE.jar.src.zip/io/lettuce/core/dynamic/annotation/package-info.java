/**
 * Central domain abstractions to be used in combination with Redis Command interfaces.
 */
package io.lettuce.core.dynamic.annotation;

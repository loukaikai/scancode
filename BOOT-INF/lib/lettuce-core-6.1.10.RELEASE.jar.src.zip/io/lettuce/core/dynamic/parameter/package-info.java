/**
 * Parameter access and descriptors.
 */
package io.lettuce.core.dynamic.parameter;

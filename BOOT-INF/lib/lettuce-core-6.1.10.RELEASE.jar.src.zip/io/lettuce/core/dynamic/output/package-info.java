/**
 * {@link io.lettuce.core.output.CommandOutput} resolution support.
 */
package io.lettuce.core.dynamic.output;

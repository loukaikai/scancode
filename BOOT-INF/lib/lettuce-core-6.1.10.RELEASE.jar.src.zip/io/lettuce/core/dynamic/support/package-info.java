/**
 * Support classes imported from the Spring Framework.
 */
package io.lettuce.core.dynamic.support;

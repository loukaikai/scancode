/**
 * Core annotations to be used with Redis Command interfaces.
 */
package io.lettuce.core.dynamic.domain;

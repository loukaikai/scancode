/**
 * Contains internal API. Classes in this package are part of the internal API and may change without further notice.
 *
 * @since 4.2
 */
package io.lettuce.core.internal;

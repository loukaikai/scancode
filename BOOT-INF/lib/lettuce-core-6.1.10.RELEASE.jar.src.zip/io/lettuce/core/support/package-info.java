/**
 * Supportive classes such as {@link io.lettuce.core.support.RedisClientCdiBean} for CDI support, connection pooling, and
 * client-side caching.
 */
package io.lettuce.core.support;

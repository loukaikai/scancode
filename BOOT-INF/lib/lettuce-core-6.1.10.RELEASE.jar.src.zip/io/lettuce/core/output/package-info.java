/**
 * Implementation of different output protocols including the Streaming API.
 */
package io.lettuce.core.output;

/**
 * Codecs for key/value type conversion.
 */
package io.lettuce.core.codec;

/**
 * Redis protocol layer abstraction.
 */
package io.lettuce.core.protocol;

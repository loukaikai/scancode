/**
 * Interfaces to consume push messages using Redis Cluster.
 */
package io.lettuce.core.cluster.api.push;

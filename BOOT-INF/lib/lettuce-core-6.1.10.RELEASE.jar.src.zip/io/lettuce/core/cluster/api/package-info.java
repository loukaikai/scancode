/**
 * Redis Cluster connection API.
 */
package io.lettuce.core.cluster.api;

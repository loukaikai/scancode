/**
 * Redis Cluster API for synchronous executed commands.
 */
package io.lettuce.core.cluster.api.sync;

/**
 * Model and parser for the {@code CLUSTER SLOTS} output.
 */
package io.lettuce.core.cluster.models.slots;

/**
 * Model and parser for the {@code CLUSTER NODES} and {@code CLUSTER SLAVES} output.
 */
package io.lettuce.core.cluster.models.partitions;

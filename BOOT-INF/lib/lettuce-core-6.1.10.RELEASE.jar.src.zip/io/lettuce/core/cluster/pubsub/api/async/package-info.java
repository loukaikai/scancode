/**
 * Redis Cluster Pub/Sub API for asynchronous executed commands.
 */
package io.lettuce.core.cluster.pubsub.api.async;

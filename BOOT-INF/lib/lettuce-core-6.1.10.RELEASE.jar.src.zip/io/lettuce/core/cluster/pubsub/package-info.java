/**
 * Redis Cluster Pub/Sub support.
 */
package io.lettuce.core.cluster.pubsub;

/**
 * Redis Cluster Pub/Sub API for synchronous executed commands.
 */
package io.lettuce.core.cluster.pubsub.api.sync;

/**
 * Cluster event types.
 */
package io.lettuce.core.cluster.event;

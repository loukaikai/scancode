/**
 * Support for cluster topology refresh.
 */
package io.lettuce.core.cluster.topology;

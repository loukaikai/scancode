/**
 * Client for Redis Cluster, see {@link io.lettuce.core.cluster.RedisClusterClient}.
 */
package io.lettuce.core.cluster;

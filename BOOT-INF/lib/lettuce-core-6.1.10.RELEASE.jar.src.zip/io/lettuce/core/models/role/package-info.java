/**
 * Model and parser for the {@code ROLE} output.
 */
package io.lettuce.core.models.role;

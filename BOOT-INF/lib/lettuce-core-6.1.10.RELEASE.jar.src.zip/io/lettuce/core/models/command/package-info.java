/**
 * Model and parser to for the {@code COMMAND} and {@code COMMAND INFO} output.
 */
package io.lettuce.core.models.command;

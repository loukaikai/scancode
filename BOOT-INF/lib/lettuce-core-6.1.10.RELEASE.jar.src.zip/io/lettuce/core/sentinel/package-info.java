/**
 * Redis Sentinel connection classes.
 */
package io.lettuce.core.sentinel;

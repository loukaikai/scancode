/**
 * Redis Sentinel API for synchronous executed commands.
 */
package io.lettuce.core.sentinel.api.sync;

/**
 * Redis Sentinel API for asynchronous executed commands.
 */
package io.lettuce.core.sentinel.api.async;

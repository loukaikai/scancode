/**
 * Redis Sentinel connection API.
 */
package io.lettuce.core.sentinel.api;

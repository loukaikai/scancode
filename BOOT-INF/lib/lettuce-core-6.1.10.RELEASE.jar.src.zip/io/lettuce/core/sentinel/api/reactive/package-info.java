/**
 * Redis Sentinel API for reactive command execution.
 */
package io.lettuce.core.sentinel.api.reactive;

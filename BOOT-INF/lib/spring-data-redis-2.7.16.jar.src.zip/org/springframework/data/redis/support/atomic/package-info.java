/**
 * Small toolkit mirroring the {@code java.util.atomic} package in Redis.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.support.atomic;

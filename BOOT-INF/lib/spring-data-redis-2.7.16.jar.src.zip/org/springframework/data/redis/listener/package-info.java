/**
 * Base package for Redis message listener / pubsub container facility
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.listener;

/**
 * Redis repository specific configuration and bean registration.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.repository.configuration;

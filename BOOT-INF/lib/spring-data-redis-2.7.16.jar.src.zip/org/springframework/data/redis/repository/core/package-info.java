/**
 * Core domain entities for repository support.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.repository.core;

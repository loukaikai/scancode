/**
 * Redis specific repository support mapping meta information.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.core.mapping;

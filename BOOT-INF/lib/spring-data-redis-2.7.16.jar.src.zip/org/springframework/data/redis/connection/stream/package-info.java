/**
 * Data structures and interfaces to interact with Redis Streams.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.connection.stream;

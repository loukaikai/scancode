/**
 * Connection package for <a href="https://lettuce.io">Lettuce</a> Redis client.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.connection.lettuce;

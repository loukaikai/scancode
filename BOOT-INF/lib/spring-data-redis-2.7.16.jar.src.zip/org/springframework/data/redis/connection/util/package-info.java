/**
 * Internal utility package for encoding/decoding Strings to byte[] (using Base64) library.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.connection.util;


/**
 * Connection package for <a href="https://github.com/xetorthio/jedis">Jedis</a> library.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.redis.connection.jedis;

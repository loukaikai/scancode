/*     */ package oracle.i18n.util;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GDKOracleMetaData
/*     */ {
/*     */   private static final String GDK_NAME = "Oracle Globalization Development Kit";
/*     */   public static final String s_gdkVersion = "19.0.0.0.0";
/*     */   public static final String s_gdkVersionFull = "19.3.0.0.0";
/*     */   public static final String s_gdkFirstYear = "2003";
/*     */   public static final String s_gdkCurrentYear = "2019";
/*     */   public static final String s_gdkCopyright = "Copyright (c) 2003, 2019, Oracle and/or its affiliates.  All right reserved.";
/*     */   public static final String s_gdkStatus = "Production";
/*     */   private static final String GDK_VERSION = "Release 19.0.0.0.0 - Production";
/*     */   private static final String GDK_VERSIONFULL = "Version 19.3.0.0.0";
/*     */   private static final String GDK_COPYRIGHT = "Copyright (c) 2003, 2019, Oracle and/or its affiliates.  All right reserved.";
/*  92 */   private static long OracleVersionID = 100000000000L;
/*     */ 
/*     */   
/*     */   private static final String GDK_DATA_PATH = "/oracle/i18n/data/";
/*     */ 
/*     */   
/*     */   static final String README_NAME = "oracle/i18n/readme.txt";
/*     */ 
/*     */   
/* 101 */   private static String[] M_PLUGINS = new String[] { "oracle.i18n.util.CharConvRepackage" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long getOracleVersionID() {
/* 120 */     return OracleVersionID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getName() {
/* 130 */     return "Oracle Globalization Development Kit";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVersion() {
/* 140 */     return "Release 19.0.0.0.0 - Production";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVersionFull() {
/* 150 */     return "Version 19.3.0.0.0";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCopyright() {
/* 160 */     return "Copyright (c) 2003, 2019, Oracle and/or its affiliates.  All right reserved.";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNameVersion() {
/* 170 */     return getName() + ": " + getVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDataPath() {
/* 180 */     return "/oracle/i18n/data/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBanner(String paramString) {
/* 202 */     StringBuffer stringBuffer = (new StringBuffer(paramString)).append(": Release ").append("19.0.0.0.0").append(" - ").append("Production").append(System.getProperty("line.separator")).append("Version ").append("19.3.0.0.0").append(System.getProperty("line.separator")).append(System.getProperty("line.separator")).append("Copyright (c) 2003, 2019, Oracle and/or its affiliates.  All right reserved.").append(System.getProperty("line.separator")).append(System.getProperty("line.separator"));
/* 203 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void main(String[] paramArrayOfString) throws Exception {
/* 231 */     Class<GDKOracleMetaData> clazz = GDKOracleMetaData.class;
/*     */     InputStream inputStream;
/* 233 */     if ((inputStream = clazz.getResourceAsStream("/oracle/i18n/readme.txt")) != null) {
/*     */ 
/*     */       
/* 236 */       printVersion();
/* 237 */       InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "iso-8859-1");
/* 238 */       char[] arrayOfChar = new char[8192];
/* 239 */       for (int i = -1; (i = inputStreamReader.read(arrayOfChar, 0, arrayOfChar.length)) != -1; ) {
/*     */         
/* 241 */         String str = new String(arrayOfChar, 0, i);
/* 242 */         System.out.print(str);
/*     */       } 
/* 244 */       inputStream.close();
/*     */       
/*     */       return;
/*     */     } 
/* 248 */     if (paramArrayOfString.length == 0) {
/*     */       
/* 250 */       printUsage();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 255 */     ArrayList<String> arrayList = new ArrayList(paramArrayOfString.length);
/*     */     byte b1;
/* 257 */     for (b1 = 0; b1 < paramArrayOfString.length; b1++)
/*     */     {
/* 259 */       arrayList.add(paramArrayOfString[b1]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 264 */     if ("-version".equals(arrayList.get(0))) {
/*     */       
/* 266 */       printVersion();
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 274 */     b1 = 0;
/* 275 */     for (byte b2 = 0; b2 < M_PLUGINS.length; b2++) {
/*     */       
/* 277 */       Object object = callStaticMethod(M_PLUGINS[b2], "getCommand", null, null);
/*     */       
/* 279 */       if (object != null && object.equals(arrayList.get(0))) {
/*     */         
/* 281 */         b1 = 1;
/* 282 */         arrayList.remove(0);
/*     */ 
/*     */         
/* 285 */         callStaticMethod(M_PLUGINS[b2], "main", new Class[] { List.class }, new Object[] { arrayList });
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 291 */     if (b1 == 0) {
/* 292 */       printUsage();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final void printVersion() {
/* 297 */     System.out.printf("%s", new Object[] { getBanner("Oracle Globalization Development Kit") });
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void printUsage() {
/* 302 */     printBaseUsage();
/* 303 */     System.out.println("  -version : Displays the GDK version");
/*     */ 
/*     */     
/* 306 */     for (byte b = 0; b < M_PLUGINS.length; b++)
/*     */     {
/* 308 */       callStaticMethod(M_PLUGINS[b], "printUsage", null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final void printBaseUsage() {
/* 315 */     System.out.println("Usage: java -jar orai18n.jar <option>");
/* 316 */     System.out.println("<option> :=");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object callStaticMethod(String paramString1, String paramString2, Class[] paramArrayOfClass, Object[] paramArrayOfObject) {
/*     */     try {
/* 336 */       Class<?> clazz = Class.forName(paramString1);
/* 337 */       return clazz.getMethod(paramString2, paramArrayOfClass).invoke(paramArrayOfClass, paramArrayOfObject);
/*     */     
/*     */     }
/* 340 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 343 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18\\util\GDKOracleMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
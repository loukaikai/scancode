/*      */ package oracle.i18n.text;
/*      */ 
/*      */ import java.io.UTFDataFormatException;
/*      */ import java.nio.charset.Charset;
/*      */ import java.sql.SQLException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import oracle.i18n.text.converter.CharsetMeta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class OraCharset
/*      */   extends Charset
/*      */ {
/*      */   private static final int CONCAIN_CHARSET_TABLE = 2;
/*      */   private static final int AL16UTF16_CHARSET = 2000;
/*      */   private static final int AL16UTF16LE_CHARSET = 2002;
/*      */   private static final int UNICODE_1_CHARSET = 870;
/*      */   private static final int UNICODE_2_CHARSET = 871;
/*      */   private static final int UTFE_CHARSET = 872;
/*      */   private static final int AL32UTF8_CHARSET = 873;
/*      */   private static final int ISO2022JP_CHARSET = 9999;
/*      */   private static final int ISO2022_JP_OUTLOOK_CHARSET = 9994;
/*      */   private static final int ISO2022_JP_OUTLOOK_HWKANA_CHARSET = 9995;
/*   61 */   private static final byte[] REP_CHAR_UTF8 = new byte[] { -17, -65, -67 };
/*      */   
/*      */   static final String ORACHARSET_PREFIX = "X-ORACLE-";
/*   64 */   private static HashMap OraCharsetCache = null;
/*      */   
/*      */   protected int oracleId;
/*      */   
/*   68 */   private static final String[] UNSUPPORTED_CHARSET = new String[] { "WE8DECTST", "ZHT32EUCTST", "WE16DECTST2", "WE16DECTST", "KO16TSTSET", "JA16TSTSET2", "JA16TSTSET", "US16TSTFIXED", "UTF16", "HZ-GB-2312", "ISO2022-KR", "ISO2022-CN" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OraCharset(String paramString, int paramInt) {
/*   83 */     super(paramString, null);
/*   84 */     this.oracleId = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static OraCharset getInstance(String paramString) {
/*   96 */     if (!paramString.toUpperCase(Locale.US).startsWith("X-ORACLE-"))
/*      */     {
/*   98 */       return null;
/*      */     }
/*      */     
/*  101 */     OraCharset oraCharset = null;
/*      */     
/*  103 */     String str1 = paramString.substring("X-ORACLE-".length()).toUpperCase(Locale.US);
/*      */ 
/*      */     
/*  106 */     for (byte b = 0; b < UNSUPPORTED_CHARSET.length; b++) {
/*      */       
/*  108 */       if (str1.equalsIgnoreCase(UNSUPPORTED_CHARSET[b]))
/*      */       {
/*  110 */         return null;
/*      */       }
/*      */     } 
/*      */     
/*  114 */     if (OraCharsetCache != null) {
/*      */ 
/*      */       
/*  117 */       oraCharset = (OraCharset)OraCharsetCache.get(str1);
/*      */       
/*  119 */       if (oraCharset != null)
/*      */       {
/*  121 */         return oraCharset;
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  126 */       OraCharsetCache = new HashMap<Object, Object>();
/*      */     } 
/*      */ 
/*      */     
/*  130 */     String str2 = CharsetMeta.getInstance().getCharSetId(str1);
/*  131 */     boolean bool = (str2 == null) ? true : Integer.parseInt(str2);
/*      */     
/*  133 */     if (bool == -1)
/*      */     {
/*  135 */       return null;
/*      */     }
/*      */     
/*  138 */     switch (bool)
/*      */     
/*      */     { case true:
/*  141 */         oraCharset = new OraCharsetAL16UTF16(paramString, bool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  175 */         OraCharsetCache.put(str1, oraCharset);
/*      */         
/*  177 */         return oraCharset;case true: case true: oraCharset = new OraCharsetUTF(paramString, bool); OraCharsetCache.put(str1, oraCharset); return oraCharset;case true: oraCharset = new OraCharsetAL32UTF8(paramString, bool); OraCharsetCache.put(str1, oraCharset); return oraCharset;case true: oraCharset = new OraCharsetUTFE(paramString, bool); OraCharsetCache.put(str1, oraCharset); return oraCharset;case true: oraCharset = new OraCharsetAL16UTF16LE(paramString, bool); OraCharsetCache.put(str1, oraCharset); return oraCharset;case true: oraCharset = new OraCharsetISO2022JP(paramString, bool); OraCharsetCache.put(str1, oraCharset); return oraCharset; }  oraCharset = OraCharsetWithConverter.getInstance(paramString, bool); OraCharsetCache.put(str1, oraCharset); return oraCharset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(Charset paramCharset) {
/*  190 */     String str = paramCharset.name().toUpperCase(Locale.US);
/*  191 */     int i = 0;
/*      */     
/*  193 */     if (!str.startsWith("X-ORACLE-"))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  210 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  214 */     i = ((OraCharset)paramCharset).oracleId;
/*      */ 
/*      */     
/*  217 */     if (this.oracleId == i)
/*      */     {
/*  219 */       return true;
/*      */     }
/*      */     
/*  222 */     CharsetMeta charsetMeta = CharsetMeta.getInstance();
/*  223 */     int[] arrayOfInt = charsetMeta.getContainsCharset(this.oracleId);
/*      */     
/*  225 */     if (arrayOfInt != null)
/*      */     {
/*  227 */       for (byte b = 0; b < arrayOfInt.length; b++) {
/*      */         
/*  229 */         if (arrayOfInt[b] == i)
/*      */         {
/*  231 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*  235 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract byte[] convertWithReplacement(String paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract byte[] convert(String paramString) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int UTFToJavaChar(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, CharacterConverterBehavior paramCharacterConverterBehavior) throws UTFDataFormatException {
/*  293 */     int i = paramInt1;
/*  294 */     int j = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  299 */     if (j > paramArrayOfbyte.length)
/*      */     {
/*  301 */       j = paramArrayOfbyte.length;
/*      */     }
/*      */     
/*  304 */     byte b = 0;
/*      */     
/*  306 */     while (i < j) {
/*      */       char c;
/*  308 */       byte b1 = paramArrayOfbyte[i++];
/*  309 */       int k = b1 & 0xF0;
/*      */       
/*  311 */       switch (k / 16) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 0:
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*  323 */           paramArrayOfchar[b++] = (char)(b1 & 0xFFFFFFFF);
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/*      */         case 13:
/*  330 */           if (i >= j) {
/*      */             
/*  332 */             i = j;
/*  333 */             paramCharacterConverterBehavior.onFailConversion();
/*      */             
/*      */             continue;
/*      */           } 
/*  337 */           c = UTFUtility.conv2ByteUTFtoUTF16(b1, paramArrayOfbyte[i++]);
/*  338 */           paramArrayOfchar[b++] = c;
/*  339 */           paramCharacterConverterBehavior.onFailConversion(c);
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 14:
/*  347 */           if (i + 1 >= j) {
/*      */             
/*  349 */             i = j;
/*  350 */             paramCharacterConverterBehavior.onFailConversion();
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  356 */           c = UTFUtility.conv3ByteUTFtoUTF16(b1, paramArrayOfbyte[i++], paramArrayOfbyte[i++]);
/*      */ 
/*      */           
/*  359 */           if (b1 != REP_CHAR_UTF8[0] || paramArrayOfbyte[i - 2] != REP_CHAR_UTF8[1] || paramArrayOfbyte[i - 1] != REP_CHAR_UTF8[2])
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  364 */             paramCharacterConverterBehavior.onFailConversion(c);
/*      */           }
/*      */ 
/*      */           
/*  368 */           if (UTFUtility.isHiSurrogate(c)) {
/*      */             
/*  370 */             if (i < j) {
/*      */               
/*  372 */               b1 = paramArrayOfbyte[i];
/*      */               
/*  374 */               if ((byte)(b1 & 0xF0) != -32) {
/*      */                 
/*  376 */                 paramArrayOfchar[b++] = '�';
/*      */                 
/*  378 */                 paramCharacterConverterBehavior.onFailConversion();
/*      */                 
/*      */                 continue;
/*      */               } 
/*      */               
/*  383 */               i++;
/*      */               
/*  385 */               if (i + 1 >= j) {
/*      */ 
/*      */                 
/*  388 */                 i = j;
/*  389 */                 paramCharacterConverterBehavior.onFailConversion();
/*      */ 
/*      */                 
/*      */                 continue;
/*      */               } 
/*      */ 
/*      */               
/*  396 */               char c1 = UTFUtility.conv3ByteUTFtoUTF16(b1, paramArrayOfbyte[i++], paramArrayOfbyte[i++]);
/*      */ 
/*      */               
/*  399 */               if (UTFUtility.isLoSurrogate(c1)) {
/*      */                 
/*  401 */                 paramArrayOfchar[b++] = c;
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/*  406 */                 paramArrayOfchar[b++] = '�';
/*      */                 
/*  408 */                 paramCharacterConverterBehavior.onFailConversion();
/*      */               } 
/*      */               
/*  411 */               paramArrayOfchar[b++] = c1;
/*      */             } 
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  417 */           paramArrayOfchar[b++] = c;
/*      */           continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  426 */       paramArrayOfchar[b++] = '�';
/*      */       
/*  428 */       paramCharacterConverterBehavior.onFailConversion();
/*      */     } 
/*      */ 
/*      */     
/*  432 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int AL32UTF8ToJavaChar(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, CharacterConverterBehavior paramCharacterConverterBehavior) throws UTFDataFormatException {
/*  454 */     int i = paramInt1;
/*  455 */     int j = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  460 */     if (j > paramArrayOfbyte.length)
/*      */     {
/*  462 */       j = paramArrayOfbyte.length;
/*      */     }
/*      */     
/*  465 */     byte b = 0;
/*      */     
/*  467 */     while (i < j) {
/*      */       char c; int m;
/*  469 */       byte b1 = paramArrayOfbyte[i++];
/*  470 */       int k = b1 & 0xF0;
/*      */       
/*  472 */       switch (k / 16) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 0:
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*  484 */           paramArrayOfchar[b++] = (char)(b1 & 0xFFFFFFFF);
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/*      */         case 13:
/*  491 */           if (i >= j) {
/*      */ 
/*      */             
/*  494 */             i = j;
/*  495 */             paramCharacterConverterBehavior.onFailConversion();
/*      */             
/*      */             continue;
/*      */           } 
/*  499 */           c = UTFUtility.conv2ByteUTFtoUTF16(b1, paramArrayOfbyte[i++]);
/*  500 */           paramArrayOfchar[b++] = c;
/*  501 */           paramCharacterConverterBehavior.onFailConversion(c);
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 14:
/*  509 */           if (i + 1 >= j) {
/*      */ 
/*      */             
/*  512 */             i = j;
/*  513 */             paramCharacterConverterBehavior.onFailConversion();
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  518 */           c = UTFUtility.conv3ByteAL32UTF8toUTF16(b1, paramArrayOfbyte[i++], paramArrayOfbyte[i++]);
/*      */           
/*  520 */           paramArrayOfchar[b++] = c;
/*      */           
/*  522 */           if (b1 != REP_CHAR_UTF8[0] || paramArrayOfbyte[i - 2] != REP_CHAR_UTF8[1] || paramArrayOfbyte[i - 1] != REP_CHAR_UTF8[2])
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  527 */             paramCharacterConverterBehavior.onFailConversion(c);
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 15:
/*  538 */           if (i + 2 >= j) {
/*      */ 
/*      */             
/*  541 */             i = j;
/*  542 */             paramCharacterConverterBehavior.onFailConversion();
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  548 */           m = UTFUtility.conv4ByteAL32UTF8toUTF16(b1, paramArrayOfbyte[i++], paramArrayOfbyte[i++], paramArrayOfbyte[i++], paramArrayOfchar, b);
/*      */ 
/*      */ 
/*      */           
/*  552 */           if (m == 1) {
/*      */             
/*  554 */             paramCharacterConverterBehavior.onFailConversion();
/*  555 */             b++;
/*      */             
/*      */             continue;
/*      */           } 
/*  559 */           b += 2;
/*      */           continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  568 */       paramArrayOfchar[b++] = '�';
/*      */       
/*  570 */       paramCharacterConverterBehavior.onFailConversion();
/*      */     } 
/*      */ 
/*      */     
/*  574 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int AL16UTF16BytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, CharacterConverterBehavior paramCharacterConverterBehavior) throws UTFDataFormatException {
/*  597 */     int j = paramInt1 + paramInt2;
/*      */ 
/*      */     
/*  600 */     byte b = 0; int i = paramInt1;
/*  601 */     for (; b < paramArrayOfchar.length && i < j; i += 2) {
/*      */       
/*  603 */       char c = (char)((paramArrayOfbyte[i] << 8) + (paramArrayOfbyte[i + 1] & 0xFF));
/*      */       
/*  605 */       if (UTFUtility.isHiSurrogate(c)) {
/*      */         
/*  607 */         i += 2;
/*      */         
/*  609 */         if (b + 1 < paramArrayOfchar.length && i < j)
/*      */         {
/*  611 */           char c1 = (char)((paramArrayOfbyte[i] << 8) + (paramArrayOfbyte[i + 1] & 0xFF));
/*      */ 
/*      */           
/*  614 */           if (UTFUtility.isLoSurrogate(c1)) {
/*      */             
/*  616 */             paramArrayOfchar[b++] = c;
/*      */           }
/*      */           else {
/*      */             
/*  620 */             paramArrayOfchar[b++] = '�';
/*      */           } 
/*      */ 
/*      */           
/*  624 */           paramArrayOfchar[b++] = c1;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  629 */         paramArrayOfchar[b++] = c;
/*      */       } 
/*      */     } 
/*      */     
/*  633 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int AL16UTF16LEBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, CharacterConverterBehavior paramCharacterConverterBehavior) throws UTFDataFormatException {
/*  656 */     int j = paramInt1 + paramInt2;
/*      */ 
/*      */     
/*  659 */     byte b = 0; int i = paramInt1;
/*  660 */     for (; b < paramArrayOfchar.length && i < j; i += 2) {
/*      */       
/*  662 */       char c = (char)((paramArrayOfbyte[i + 1] << 8) + (paramArrayOfbyte[i] & 0xFF));
/*      */       
/*  664 */       if (UTFUtility.isHiSurrogate(c)) {
/*      */         
/*  666 */         i += 2;
/*      */         
/*  668 */         if (b + 1 < paramArrayOfchar.length && i < j)
/*      */         {
/*  670 */           char c1 = (char)((paramArrayOfbyte[i + 1] << 8) + (paramArrayOfbyte[i] & 0xFF));
/*      */ 
/*      */           
/*  673 */           if (UTFUtility.isLoSurrogate(c1)) {
/*      */             
/*  675 */             paramArrayOfchar[b++] = c;
/*      */           }
/*      */           else {
/*      */             
/*  679 */             paramArrayOfchar[b++] = '�';
/*      */           } 
/*      */ 
/*      */           
/*  683 */           paramArrayOfchar[b++] = c1;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  688 */         paramArrayOfchar[b++] = c;
/*      */       } 
/*      */     } 
/*      */     
/*  692 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int javaCharsToAL16UTF16Bytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) {
/*  710 */     int i = Math.min(paramInt, paramArrayOfbyte.length >>> 1);
/*      */     byte b2;
/*  712 */     for (byte b1 = 0; b1 < i; 
/*  713 */       b1++, b2 += 2) {
/*      */       
/*  715 */       paramArrayOfbyte[b2] = (byte)(paramArrayOfchar[b1] >>> 8);
/*  716 */       paramArrayOfbyte[b2 + 1] = (byte)(paramArrayOfchar[b1] & 0xFF);
/*      */     } 
/*      */     
/*  719 */     return b2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int javaCharsToAL16UTF16LEBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) {
/*  737 */     int i = Math.min(paramInt, paramArrayOfbyte.length >>> 1);
/*      */     byte b2;
/*  739 */     for (byte b1 = 0; b1 < i; 
/*  740 */       b1++, b2 += 2) {
/*      */       
/*  742 */       paramArrayOfbyte[b2] = (byte)(paramArrayOfchar[b1] & 0xFF);
/*  743 */       paramArrayOfbyte[b2 + 1] = (byte)(paramArrayOfchar[b1] >>> 8);
/*      */     } 
/*      */     
/*  746 */     return b2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int UTFStringLength(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  766 */     byte b = 0;
/*  767 */     int i = paramInt1;
/*  768 */     int j = paramInt1 + paramInt2;
/*      */     
/*  770 */     while (i < j) {
/*      */       
/*  772 */       switch ((paramArrayOfbyte[i] & 0xF0) >>> 4) {
/*      */         
/*      */         case 0:
/*      */         case 1:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*  782 */           i++;
/*  783 */           b++;
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 12:
/*      */         case 13:
/*  790 */           if (i + 1 >= j) {
/*      */             
/*  792 */             i = j;
/*      */             
/*      */             continue;
/*      */           } 
/*  796 */           b++;
/*  797 */           i += 2;
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 14:
/*  804 */           if (i + 2 >= j) {
/*      */             
/*  806 */             i = j;
/*      */             
/*      */             continue;
/*      */           } 
/*  810 */           b++;
/*  811 */           i += 3;
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 15:
/*  818 */           if (i + 3 >= j) {
/*      */             
/*  820 */             i = j;
/*      */             
/*      */             continue;
/*      */           } 
/*  824 */           b += 2;
/*  825 */           i += 4;
/*      */           continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  831 */       i++;
/*  832 */       b++;
/*      */     } 
/*      */ 
/*      */     
/*  836 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int javaCharsToUTF(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
/*  856 */     int i = paramInt1;
/*  857 */     int j = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  862 */     if (i < 0)
/*      */     {
/*  864 */       i = 0;
/*      */     }
/*      */     
/*  867 */     if (j > paramArrayOfchar.length)
/*      */     {
/*  869 */       j = paramArrayOfchar.length;
/*      */     }
/*      */     
/*  872 */     if (paramInt3 < 0)
/*      */     {
/*  874 */       paramInt3 = 0;
/*      */     }
/*      */ 
/*      */     
/*  878 */     int k = paramInt3;
/*      */     
/*  880 */     for (int m = i; m < j; m++) {
/*      */       
/*  882 */       char c = paramArrayOfchar[m];
/*      */       
/*  884 */       if (c >= '\000' && c <= '') {
/*      */         
/*  886 */         paramArrayOfbyte[k++] = (byte)c;
/*      */       }
/*  888 */       else if (c > '߿') {
/*      */         
/*  890 */         paramArrayOfbyte[k++] = (byte)(0xE0 | c >>> 12 & 0xF);
/*  891 */         paramArrayOfbyte[k++] = (byte)(0x80 | c >>> 6 & 0x3F);
/*  892 */         paramArrayOfbyte[k++] = (byte)(0x80 | c >>> 0 & 0x3F);
/*      */       }
/*      */       else {
/*      */         
/*  896 */         paramArrayOfbyte[k++] = (byte)(0xC0 | c >>> 6 & 0x1F);
/*  897 */         paramArrayOfbyte[k++] = (byte)(0x80 | c >>> 0 & 0x3F);
/*      */       } 
/*      */     } 
/*      */     
/*  901 */     return k - paramInt3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int javaCharsToAL32UTF8(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
/*  922 */     int j = paramInt1;
/*  923 */     int k = paramInt1 + paramInt2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  928 */     if (j < 0)
/*      */     {
/*  930 */       j = 0;
/*      */     }
/*      */     
/*  933 */     if (k > paramArrayOfchar.length)
/*      */     {
/*  935 */       k = paramArrayOfchar.length;
/*      */     }
/*      */     
/*  938 */     if (paramInt3 < 0)
/*      */     {
/*  940 */       paramInt3 = 0;
/*      */     }
/*      */ 
/*      */     
/*  944 */     int m = paramInt3;
/*      */     
/*  946 */     for (int i = j; i < k; i++) {
/*      */       
/*  948 */       char c = paramArrayOfchar[i];
/*  949 */       char c1 = Character.MIN_VALUE;
/*      */       
/*  951 */       if (c >= '\000' && c <= '') {
/*      */         
/*  953 */         paramArrayOfbyte[m++] = (byte)c;
/*      */       }
/*  955 */       else if (UTFUtility.isHiSurrogate((char)c)) {
/*      */ 
/*      */         
/*  958 */         if (i + 1 < k && 
/*      */           
/*  960 */           UTFUtility.isLoSurrogate((char)(c1 = paramArrayOfchar[i + 1])))
/*      */         {
/*      */ 
/*      */           
/*  964 */           int n = (c >>> 6 & 0xF) + 1;
/*  965 */           paramArrayOfbyte[m++] = (byte)(n >>> 2 | 0xF0);
/*  966 */           paramArrayOfbyte[m++] = (byte)((n & 0x3) << 4 | c >>> 2 & 0xF | 0x80);
/*      */           
/*  968 */           paramArrayOfbyte[m++] = (byte)((c & 0x3) << 4 | c1 >>> 6 & 0xF | 0x80);
/*      */           
/*  970 */           paramArrayOfbyte[m++] = (byte)(c1 & 0x3F | 0x80);
/*  971 */           i++;
/*      */         }
/*      */         else
/*      */         {
/*  975 */           paramArrayOfbyte[m++] = -17;
/*  976 */           paramArrayOfbyte[m++] = -65;
/*  977 */           paramArrayOfbyte[m++] = -67;
/*      */         }
/*      */       
/*  980 */       } else if (c > '߿') {
/*      */         
/*  982 */         paramArrayOfbyte[m++] = (byte)(0xE0 | c >>> 12 & 0xF);
/*  983 */         paramArrayOfbyte[m++] = (byte)(0x80 | c >>> 6 & 0x3F);
/*  984 */         paramArrayOfbyte[m++] = (byte)(0x80 | c >>> 0 & 0x3F);
/*      */       }
/*      */       else {
/*      */         
/*  988 */         paramArrayOfbyte[m++] = (byte)(0xC0 | c >>> 6 & 0x1F);
/*  989 */         paramArrayOfbyte[m++] = (byte)(0x80 | c >>> 0 & 0x3F);
/*      */       } 
/*      */     } 
/*      */     
/*  993 */     return m - paramInt3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int stringUTFLength(String paramString) {
/* 1009 */     byte b1 = 0;
/* 1010 */     char[] arrayOfChar = paramString.toCharArray();
/* 1011 */     int i = arrayOfChar.length;
/*      */     
/* 1013 */     for (byte b2 = 0; b2 < i; b2++) {
/*      */       
/* 1015 */       char c = arrayOfChar[b2];
/*      */       
/* 1017 */       if (c >= '\000' && c <= '') {
/*      */         
/* 1019 */         b1++;
/*      */       }
/* 1021 */       else if (c > '߿') {
/*      */         
/* 1023 */         b1 += 3;
/*      */       }
/*      */       else {
/*      */         
/* 1027 */         b1 += 2;
/*      */       } 
/*      */     } 
/*      */     
/* 1031 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int string32UTF8Length(String paramString) {
/* 1047 */     byte b1 = 0;
/* 1048 */     char[] arrayOfChar = paramString.toCharArray();
/* 1049 */     int i = arrayOfChar.length;
/*      */     
/* 1051 */     for (byte b2 = 0; b2 < i; b2++) {
/*      */       
/* 1053 */       char c = arrayOfChar[b2];
/*      */       
/* 1055 */       if (c >= '\000' && c <= '') {
/*      */         
/* 1057 */         b1++;
/*      */       }
/* 1059 */       else if (c > '߿') {
/*      */         
/* 1061 */         if (UTFUtility.isHiSurrogate((char)c)) {
/*      */           
/* 1063 */           if (b2 + 1 < i)
/*      */           {
/* 1065 */             b1 += 4;
/* 1066 */             b2++;
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1071 */           b1 += 3;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1076 */         b1 += 2;
/*      */       } 
/*      */     } 
/*      */     
/* 1080 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class CharacterConverterBehavior
/*      */   {
/* 1089 */     public static final char[] NULL_CHARS = new char[1];
/*      */     public static final char UTF16_REPLACEMENT_CHAR = '�';
/*      */     
/* 1092 */     public static final CharacterConverterBehavior REPORT_ERROR = new CharacterConverterBehavior("Report Error")
/*      */       {
/*      */ 
/*      */         
/*      */         public void onFailConversion() throws UTFDataFormatException
/*      */         {
/* 1098 */           throw new UTFDataFormatException();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void onFailConversion(char param2Char) throws UTFDataFormatException {
/* 1104 */           if (param2Char == '�')
/*      */           {
/* 1106 */             throw new UTFDataFormatException();
/*      */           }
/*      */         }
/*      */       };
/*      */     
/* 1111 */     public static final CharacterConverterBehavior REPLACEMENT = new CharacterConverterBehavior("Replacement")
/*      */       {
/*      */         public void onFailConversion() throws UTFDataFormatException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void onFailConversion(char param2Char) throws UTFDataFormatException {}
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String m_name;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CharacterConverterBehavior(String param1String) {
/* 1131 */       this.m_name = param1String;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract void onFailConversion(char param1Char) throws UTFDataFormatException;
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract void onFailConversion() throws UTFDataFormatException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDefined(String paramString) {
/* 1146 */     int i = paramString.length();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 1153 */       char c = paramString.charAt(b);
/* 1154 */       if (c >= '?' && c <= '?') return false; 
/* 1155 */       if (c >= '?' && c <= '?')
/*      */       
/* 1157 */       { if (b + 1 >= i) return false; 
/* 1158 */         char c1 = paramString.charAt(b + 1);
/* 1159 */         if (c1 < '?' || c1 > '?') return false; 
/* 1160 */         b++;
/*      */         
/*      */          }
/*      */       
/* 1164 */       else if (c == '￾' || c == Character.MAX_VALUE) { return false; }
/*      */     
/*      */     } 
/* 1167 */     return true;
/*      */   }
/*      */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.MalformedInputException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import oracle.i18n.text.converter.GDKMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OraCharsetISO2022JP
/*     */   extends OraCharset
/*     */ {
/*     */   static final byte REPLACEMENT_CHAR_IN_BYTE = 63;
/*  42 */   static final byte[] REPLACEMENT_CHAR_IN_BYTES = new byte[] { 63 };
/*     */   
/*     */   static final int ASCII_JISROMAN = 0;
/*     */   
/*     */   static final int JISX0208 = 1;
/*     */   
/*     */   static final int JISX0212 = 2;
/*     */   
/*     */   static final int HALF_WIDTH_KATAKANA = 3;
/*     */   
/*     */   static final int BUCKETSIZE = 200;
/*     */   
/*     */   OraCharsetISO2022JP(String paramString, int paramInt) {
/*  55 */     super(paramString, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/*  60 */     return new OraCharsetDecoder(this, 0.5F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/*  65 */     return new OraCharsetEncoder(this, 10.0F, 10.0F, REPLACEMENT_CHAR_IN_BYTES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/*  73 */       return ISO2022JPToJavaChars(paramArrayOfbyte, paramInt1, paramInt2, CharacterConverterBehavior.REPORT_ERROR);
/*     */     
/*     */     }
/*  76 */     catch (Exception exception) {
/*     */       
/*  78 */       throw new SQLException(
/*  79 */           GDKMessage.getORAMessage(17154), null, 17154);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/*  89 */       return ISO2022JPToJavaChars(paramArrayOfbyte, paramInt1, paramInt2, CharacterConverterBehavior.REPLACEMENT);
/*     */     
/*     */     }
/*  92 */     catch (Exception exception) {
/*     */       
/*  94 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getNextEscpSeq(byte[] paramArrayOfbyte, int paramInt) {
/* 102 */     for (; paramInt < paramArrayOfbyte.length; paramInt++) {
/*     */       
/* 104 */       if (paramArrayOfbyte[paramInt] == 27)
/* 105 */         return paramInt; 
/*     */     } 
/* 107 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int convertToEUCJP(byte[] paramArrayOfbyte, ArrayList<byte[]> paramArrayList, int paramInt1, int paramInt2, int paramInt3, CharacterConverterBehavior paramCharacterConverterBehavior) throws MalformedInputException {
/* 115 */     byte b = 0; int i = 0;
/* 116 */     byte[] arrayOfByte = null;
/*     */ 
/*     */     
/* 119 */     if (paramInt2 < paramInt1) {
/* 120 */       throw new MalformedInputException(paramInt1);
/*     */     }
/* 122 */     switch (paramInt3) {
/*     */ 
/*     */       
/*     */       case 0:
/* 126 */         arrayOfByte = new byte[paramInt2 - paramInt1 + 1];
/* 127 */         paramArrayList.add(arrayOfByte);
/* 128 */         i = paramInt2 - paramInt1 + 1;
/*     */         
/* 130 */         for (b = 0; paramInt1 <= paramInt2; paramInt1++, b++) {
/*     */           
/* 132 */           if ((paramArrayOfbyte[paramInt1] < 32 || paramArrayOfbyte[paramInt1] > 126) && paramArrayOfbyte[paramInt1] != 13 && paramArrayOfbyte[paramInt1] != 10) {
/*     */ 
/*     */ 
/*     */             
/* 136 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = 63;
/* 137 */             paramCharacterConverterBehavior.onFailConversion(paramInt1);
/*     */           } else {
/*     */             
/* 140 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = paramArrayOfbyte[paramInt1];
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 1:
/* 146 */         if ((paramInt2 - paramInt1) % 2 == 0) {
/*     */ 
/*     */           
/* 149 */           paramInt2--;
/* 150 */           paramCharacterConverterBehavior.onFailConversion(paramInt1);
/*     */         } 
/*     */ 
/*     */         
/* 154 */         arrayOfByte = new byte[paramInt2 - paramInt1 + 1];
/* 155 */         paramArrayList.add(arrayOfByte);
/* 156 */         i = paramInt2 - paramInt1 + 1;
/*     */         
/* 158 */         for (b = 0; paramInt1 <= paramInt2; paramInt1++, b++) {
/*     */           
/* 160 */           if (paramArrayOfbyte[paramInt1] < 33 || paramArrayOfbyte[paramInt1] > 126) {
/*     */ 
/*     */             
/* 163 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = -65;
/*     */             
/* 165 */             paramCharacterConverterBehavior.onFailConversion(paramInt1);
/*     */           }
/*     */           else {
/*     */             
/* 169 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = (byte)(paramArrayOfbyte[paramInt1] | 0x80);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 2:
/* 175 */         if ((paramInt2 - paramInt1) % 2 == 0)
/*     */         {
/*     */           
/* 178 */           paramInt2--;
/*     */         }
/*     */ 
/*     */         
/* 182 */         arrayOfByte = new byte[(int)((paramInt2 - paramInt1 + 1) * 1.5D)];
/* 183 */         paramArrayList.add(arrayOfByte);
/* 184 */         i = (int)((paramInt2 - paramInt1 + 1) * 1.5D);
/*     */         
/* 186 */         for (b = 0; paramInt1 <= paramInt2; paramInt1++, b++) {
/*     */           
/* 188 */           if (b % 3 == 0) {
/* 189 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b++] = -113;
/*     */           }
/* 191 */           if (paramArrayOfbyte[paramInt1] < 33 || paramArrayOfbyte[paramInt1] > 126) {
/*     */ 
/*     */             
/* 194 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = -65;
/*     */             
/* 196 */             paramCharacterConverterBehavior.onFailConversion(paramInt1);
/*     */           } else {
/*     */             
/* 199 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = (byte)(paramArrayOfbyte[paramInt1] | 0x80);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/* 205 */         arrayOfByte = new byte[(paramInt2 - paramInt1 + 1) * 2];
/* 206 */         paramArrayList.add(arrayOfByte);
/* 207 */         i = (paramInt2 - paramInt1 + 1) * 2;
/*     */         
/* 209 */         for (b = 0; paramInt1 <= paramInt2; paramInt1++, b++) {
/*     */           
/* 211 */           if (b % 2 == 0) {
/* 212 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b++] = -114;
/*     */           }
/* 214 */           if (paramArrayOfbyte[paramInt1] < 33 || paramArrayOfbyte[paramInt1] > 126) {
/*     */ 
/*     */             
/* 217 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = -65;
/*     */             
/* 219 */             paramCharacterConverterBehavior.onFailConversion(paramInt1);
/*     */           }
/*     */           else {
/*     */             
/* 223 */             ((byte[])paramArrayList.get(paramArrayList.size() - 1))[b] = (byte)(paramArrayOfbyte[paramInt1] | 0x80);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 230 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int checkEscpSeq(byte[] paramArrayOfbyte, int paramInt) throws MalformedInputException {
/* 239 */     if (paramInt + 2 >= paramArrayOfbyte.length) {
/* 240 */       return -1;
/*     */     }
/* 242 */     if (paramArrayOfbyte[paramInt + 1] == 40) {
/*     */ 
/*     */       
/* 245 */       if (paramArrayOfbyte[paramInt + 2] == 66 || paramArrayOfbyte[paramInt + 2] == 74)
/* 246 */         return 0; 
/* 247 */       if (paramArrayOfbyte[paramInt + 2] == 73) {
/* 248 */         return 3;
/*     */       }
/* 250 */     } else if (paramArrayOfbyte[paramInt + 1] == 36) {
/*     */ 
/*     */       
/* 253 */       if (paramArrayOfbyte[paramInt + 2] == 64 || paramArrayOfbyte[paramInt + 2] == 66) {
/* 254 */         return 1;
/*     */       }
/* 256 */       if (paramArrayOfbyte[paramInt + 2] == 40 && paramArrayOfbyte[paramInt + 3] == 68)
/* 257 */         return 2; 
/*     */     } 
/* 259 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String ISO2022JPToJavaChars(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, CharacterConverterBehavior paramCharacterConverterBehavior) throws MalformedInputException {
/* 267 */     int i = paramInt1;
/* 268 */     int j = paramInt1;
/* 269 */     boolean bool1 = false;
/* 270 */     int k = 0;
/* 271 */     byte b1 = 0, b2 = 0, b3 = 0;
/* 272 */     boolean bool2 = false;
/*     */ 
/*     */     
/* 275 */     ArrayList arrayList = new ArrayList(0);
/*     */ 
/*     */     
/* 278 */     j = getNextEscpSeq(paramArrayOfbyte, i);
/*     */     
/* 280 */     if (j == -1) {
/*     */       
/* 282 */       k += convertToEUCJP(paramArrayOfbyte, arrayList, 0, paramArrayOfbyte.length - 1, 0, paramCharacterConverterBehavior);
/* 283 */       bool1 = true;
/*     */     }
/* 285 */     else if (j != 0) {
/* 286 */       k += convertToEUCJP(paramArrayOfbyte, arrayList, 0, j - 1, 0, paramCharacterConverterBehavior);
/*     */     } 
/* 288 */     while (!bool1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 293 */       i = j;
/* 294 */       j = getNextEscpSeq(paramArrayOfbyte, j + 1);
/*     */ 
/*     */       
/* 297 */       if (j == -1) {
/*     */         
/* 299 */         j = paramArrayOfbyte.length;
/* 300 */         bool1 = true;
/*     */       } 
/*     */       
/* 303 */       int m = checkEscpSeq(paramArrayOfbyte, i);
/*     */       
/* 305 */       if (m == 0 || m == 1 || m == 3) {
/*     */         
/* 307 */         if (i + 3 != j)
/* 308 */           k += convertToEUCJP(paramArrayOfbyte, arrayList, i + 3, j - 1, m, paramCharacterConverterBehavior); 
/*     */         continue;
/*     */       } 
/* 311 */       if (m == 2) {
/*     */         
/* 313 */         if (i + 4 != j) {
/* 314 */           k += convertToEUCJP(paramArrayOfbyte, arrayList, i + 4, j - 1, m, paramCharacterConverterBehavior);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 320 */       paramCharacterConverterBehavior.onFailConversion(i);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 325 */     byte[] arrayOfByte = new byte[k];
/* 326 */     for (b1 = 0; b1 < arrayList.size(); b1++) {
/*     */       
/* 328 */       for (b2 = 0; b2 < ((byte[])arrayList.get(b1)).length; b2++, b3++)
/*     */       {
/* 330 */         arrayOfByte[b3] = ((byte[])arrayList.get(b1))[b2];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 336 */       return new String(arrayOfByte, "EUCJP");
/*     */     }
/* 338 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 341 */       paramCharacterConverterBehavior.onFailConversion(0);
/* 342 */       return new String("");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] convert(String paramString) throws SQLException {
/*     */     try {
/* 351 */       return JavaCharsToISO2022JP(paramString, CharacterConverterBehavior.REPORT_ERROR);
/*     */     }
/* 353 */     catch (Exception exception) {
/*     */       
/* 355 */       throw new SQLException(
/* 356 */           GDKMessage.getORAMessage(17155), null, 17155);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] convertWithReplacement(String paramString) {
/*     */     try {
/* 366 */       return JavaCharsToISO2022JP(paramString, CharacterConverterBehavior.REPORT_ERROR);
/*     */     }
/* 368 */     catch (Exception exception) {
/*     */       
/* 370 */       return new byte[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int insertToBucket(int paramInt, ArrayList<byte[]> paramArrayList, byte[] paramArrayOfbyte) {
/* 379 */     if (paramInt + paramArrayOfbyte.length - 1 >= 200) {
/*     */       
/* 381 */       for (byte b = 0; b < paramArrayOfbyte.length; b++, paramInt++)
/*     */       {
/* 383 */         if (paramInt >= 200) {
/*     */           
/* 385 */           byte[] arrayOfByte = new byte[200];
/* 386 */           paramArrayList.add(arrayOfByte);
/* 387 */           paramInt = 0;
/*     */         } 
/* 389 */         ((byte[])paramArrayList.get(paramArrayList.size() - 1))[paramInt] = paramArrayOfbyte[b];
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 394 */       for (byte b = 0; b < paramArrayOfbyte.length; b++, paramInt++)
/*     */       {
/* 396 */         ((byte[])paramArrayList.get(paramArrayList.size() - 1))[paramInt] = paramArrayOfbyte[b];
/*     */       }
/*     */     } 
/* 399 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int insertEscSeq(int paramInt1, ArrayList paramArrayList, int paramInt2) {
/* 405 */     byte[] arrayOfByte = null;
/* 406 */     if (paramInt2 == 0) {
/* 407 */       arrayOfByte = new byte[] { 27, 40, 66 };
/* 408 */     } else if (paramInt2 == 1) {
/* 409 */       arrayOfByte = new byte[] { 27, 36, 66 };
/* 410 */     } else if (paramInt2 == 2) {
/* 411 */       arrayOfByte = new byte[] { 27, 36, 40, 68 };
/* 412 */     } else if (paramInt2 == 3) {
/* 413 */       arrayOfByte = new byte[] { 27, 40, 73 };
/*     */     } 
/* 415 */     return insertToBucket(paramInt1, paramArrayList, arrayOfByte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] JavaCharsToISO2022JP(String paramString, CharacterConverterBehavior paramCharacterConverterBehavior) throws MalformedInputException {
/* 422 */     byte b = -1;
/* 423 */     int i = 0; byte b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0;
/* 424 */     ArrayList<byte[]> arrayList = new ArrayList(0);
/* 425 */     byte[] arrayOfByte1 = null;
/*     */     
/* 427 */     byte[] arrayOfByte2 = new byte[200];
/* 428 */     arrayList.add(arrayOfByte2);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 433 */       arrayOfByte1 = paramString.getBytes("X-ORACLE-JA16EUC");
/* 434 */     } catch (Exception exception) {
/* 435 */       paramCharacterConverterBehavior.onFailConversion(b1);
/* 436 */       return new byte[0];
/*     */     } 
/*     */     
/* 439 */     for (b1 = 0; b1 < arrayOfByte1.length; ) {
/*     */       
/* 441 */       if ((arrayOfByte1[b1] >= 32 && arrayOfByte1[b1] <= 126) || arrayOfByte1[b1] == 10 || arrayOfByte1[b1] == 13) {
/*     */ 
/*     */         
/* 444 */         if (b != 0) {
/*     */ 
/*     */ 
/*     */           
/* 448 */           if (b1 != 0) {
/*     */             
/* 450 */             i = insertEscSeq(i, arrayList, 0);
/* 451 */             b2 += true;
/*     */           } 
/* 453 */           b = 0;
/*     */         } 
/*     */         
/* 456 */         i = insertToBucket(i, arrayList, new byte[] { arrayOfByte1[b1] });
/* 457 */         b1++;
/* 458 */         b2++; continue;
/*     */       } 
/* 460 */       if (arrayOfByte1[b1] >= -95 && arrayOfByte1[b1] <= -2) {
/*     */         
/* 462 */         if (b != 1) {
/*     */           
/* 464 */           i = insertEscSeq(i, arrayList, 1);
/* 465 */           b = 1;
/* 466 */           b2 += 3;
/*     */         } 
/*     */         
/* 469 */         i = insertToBucket(i, arrayList, new byte[] { (byte)(arrayOfByte1[b1] & Byte.MAX_VALUE), (byte)(arrayOfByte1[b1 + 1] & Byte.MAX_VALUE) });
/*     */         
/* 471 */         b1 += 2;
/* 472 */         b2 += 2; continue;
/*     */       } 
/* 474 */       if (arrayOfByte1[b1] == -114) {
/*     */         
/* 476 */         if (b != 3) {
/*     */           
/* 478 */           i = insertEscSeq(i, arrayList, 3);
/* 479 */           b = 3;
/* 480 */           b2 += 3;
/*     */         } 
/*     */         
/* 483 */         i = insertToBucket(i, arrayList, new byte[] { (byte)(arrayOfByte1[b1 + 1] & Byte.MAX_VALUE) });
/*     */ 
/*     */         
/* 486 */         b1 += 2;
/* 487 */         b2++; continue;
/*     */       } 
/* 489 */       if (arrayOfByte1[b1] == -113) {
/*     */         
/* 491 */         if (b != 2) {
/*     */           
/* 493 */           i = insertEscSeq(i, arrayList, 2);
/* 494 */           b = 2;
/* 495 */           b2 += 4;
/*     */         } 
/*     */         
/* 498 */         i = insertToBucket(i, arrayList, new byte[] { (byte)(arrayOfByte1[b1 + 1] & Byte.MAX_VALUE), (byte)(arrayOfByte1[b1 + 2] & Byte.MAX_VALUE) });
/*     */         
/* 500 */         b1 += 3;
/* 501 */         b2 += 2;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 506 */       paramCharacterConverterBehavior.onFailConversion(b1);
/* 507 */       b1++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 513 */     if (b != 0) {
/* 514 */       i = insertEscSeq(i, arrayList, 0);
/* 515 */       b2 += 3;
/*     */     } 
/*     */ 
/*     */     
/* 519 */     byte[] arrayOfByte3 = new byte[b2];
/* 520 */     for (b3 = 0; b3 < arrayList.size(); b3++) {
/*     */       
/* 522 */       byte b6 = ((b2 - b5) / 200 > 0) ? 200 : (b2 % 200);
/* 523 */       for (b4 = 0; b4 < b6; b4++, b5++)
/*     */       {
/* 525 */         arrayOfByte3[b5] = ((byte[])arrayList.get(b3))[b4];
/*     */       }
/*     */     } 
/* 528 */     return arrayOfByte3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static abstract class CharacterConverterBehavior
/*     */   {
/* 543 */     public static final CharacterConverterBehavior REPORT_ERROR = new CharacterConverterBehavior()
/*     */       {
/*     */         
/*     */         public void onFailConversion(int param2Int) throws MalformedInputException
/*     */         {
/* 548 */           throw new MalformedInputException(param2Int);
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 553 */     public static final CharacterConverterBehavior REPLACEMENT = new CharacterConverterBehavior() {
/*     */         public void onFailConversion(int param2Int) throws MalformedInputException {}
/*     */       };
/*     */     
/*     */     public abstract void onFailConversion(int param1Int) throws MalformedInputException;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetISO2022JP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
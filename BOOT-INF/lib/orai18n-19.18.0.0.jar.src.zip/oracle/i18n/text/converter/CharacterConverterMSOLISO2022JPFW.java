/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.i18n.util.GDKOracleMetaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharacterConverterMSOLISO2022JPFW
/*    */   extends CharacterConverterMSOLISO2022JPBase
/*    */ {
/* 35 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] toISO2022JPStringMain(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint, CharacterConverterMSOLISO2022JPBase.CharacterConverterBehavior paramCharacterConverterBehavior) throws SQLException {
/* 52 */     return toISO2022JPStringFWHW(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramArrayOfint, paramCharacterConverterBehavior, 1);
/*    */   }
/*    */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterMSOLISO2022JPFW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
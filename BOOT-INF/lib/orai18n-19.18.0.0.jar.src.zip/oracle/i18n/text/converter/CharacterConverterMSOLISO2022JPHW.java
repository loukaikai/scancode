/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.i18n.util.GDKOracleMetaData;
/*    */ 
/*    */ public class CharacterConverterMSOLISO2022JPHW
/*    */   extends CharacterConverterMSOLISO2022JPBase {
/*  8 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] toISO2022JPStringMain(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint, CharacterConverterMSOLISO2022JPBase.CharacterConverterBehavior paramCharacterConverterBehavior) throws SQLException {
/* 25 */     return toISO2022JPStringFWHW(paramArrayOfchar, paramInt1, paramArrayOfbyte, paramInt2, paramArrayOfint, paramCharacterConverterBehavior, 2);
/*    */   }
/*    */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterMSOLISO2022JPHW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
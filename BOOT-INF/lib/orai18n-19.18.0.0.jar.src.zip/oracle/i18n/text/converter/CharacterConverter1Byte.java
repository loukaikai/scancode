/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverter1Byte
/*     */   extends CharacterConverterOGS
/*     */ {
/* 104 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */   
/*     */   static final int ORACHARMASK = 255;
/*     */   
/*     */   static final int UCSCHARWIDTH = 16;
/* 109 */   public int m_ucsReplacement = 0;
/* 110 */   public int[] m_ucsChar = null;
/* 111 */   public char[] m_oraCharLevel1 = null;
/* 112 */   public char[] m_oraCharSurrogateLevel = null;
/* 113 */   public char[] m_oraCharLevel2 = null;
/* 114 */   public byte m_oraCharReplacement = 0;
/*     */ 
/*     */   
/* 117 */   public byte[] m_displayWidthTable = null;
/*     */   
/*     */   protected transient boolean noSurrogate = true;
/*     */   protected transient boolean strictASCII = true;
/* 121 */   protected transient int m_oraCharLevel2Size = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharacterConverter1Byte() {
/* 127 */     this.m_groupId = 0;
/* 128 */     this.averageCharsPerByte = 1.0F;
/* 129 */     this.maxCharsPerByte = 1.0F;
/* 130 */     this.maxBytesPerChar = 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicode(byte paramByte) throws SQLException {
/* 146 */     int i = this.m_ucsChar[paramByte & 0xFF];
/*     */     
/* 148 */     if (i == -1)
/*     */     {
/* 150 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     }
/*     */ 
/*     */     
/* 154 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicodeWithReplacement(byte paramByte) {
/* 166 */     int i = this.m_ucsChar[paramByte & 0xFF];
/*     */     
/* 168 */     if (i == -1)
/*     */     {
/* 170 */       return this.m_ucsReplacement;
/*     */     }
/*     */ 
/*     */     
/* 174 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDisplayWidth(int paramInt, boolean paramBoolean) throws UnsupportedEncodingException, SQLException {
/*     */     byte b;
/* 192 */     char[] arrayOfChar = parseUnicodeCodePoint(paramInt);
/*     */ 
/*     */     
/* 195 */     if (paramBoolean) {
/* 196 */       if (arrayOfChar[1] == '\000') {
/* 197 */         b = toOracleCharacterWithReplacement(arrayOfChar[0]);
/*     */       } else {
/* 199 */         b = toOracleCharacterWithReplacement(arrayOfChar[0], arrayOfChar[1]);
/*     */       }
/*     */     
/* 202 */     } else if (arrayOfChar[1] == '\000') {
/* 203 */       b = toOracleCharacter(arrayOfChar[0]);
/*     */     } else {
/* 205 */       b = toOracleCharacter(arrayOfChar[0], arrayOfChar[1]);
/*     */     } 
/*     */     
/* 208 */     if (this.m_displayWidthTable != null) {
/* 209 */       byte b1 = this.m_displayWidthTable[b & 0xFF];
/* 210 */       if (b1 != -1)
/* 211 */         return b1; 
/*     */     } 
/* 213 */     return getDefaultDisplayWidth(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte toOracleCharacter(char paramChar1, char paramChar2) throws SQLException {
/* 227 */     int i = paramChar1 >>> 8 & 0xFF;
/* 228 */     int j = paramChar1 & 0xFF;
/* 229 */     int k = paramChar2 >>> 8 & 0xFF;
/* 230 */     int m = paramChar2 & 0xFF;
/*     */     
/* 232 */     if (this.m_oraCharLevel1[i] != (char)this.m_oraCharLevel2Size && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m] != Character.MAX_VALUE)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 237 */       return (byte)this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 242 */     throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte toOracleCharacter(char paramChar) throws SQLException {
/* 257 */     int i = paramChar >>> 8;
/* 258 */     int j = paramChar & 0xFF;
/*     */     
/*     */     char c;
/* 261 */     if ((c = this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j]) != Character.MAX_VALUE)
/*     */     {
/* 263 */       return (byte)c;
/*     */     }
/*     */ 
/*     */     
/* 267 */     throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte toOracleCharacterWithReplacement(char paramChar1, char paramChar2) {
/* 282 */     int i = paramChar1 >>> 8 & 0xFF;
/* 283 */     int j = paramChar1 & 0xFF;
/* 284 */     int k = paramChar2 >>> 8 & 0xFF;
/* 285 */     int m = paramChar2 & 0xFF;
/*     */     
/* 287 */     if (this.m_oraCharLevel1[i] != (char)this.m_oraCharLevel2Size && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m] != Character.MAX_VALUE)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 292 */       return (byte)this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[i] + j] + k] + m];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 297 */     return this.m_oraCharReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte toOracleCharacterWithReplacement(char paramChar) {
/* 310 */     int i = paramChar >>> 8;
/* 311 */     int j = paramChar & 0xFF;
/*     */     
/*     */     char c;
/* 314 */     if ((c = this.m_oraCharLevel2[this.m_oraCharLevel1[i] + j]) != Character.MAX_VALUE)
/*     */     {
/* 316 */       return (byte)c;
/*     */     }
/*     */ 
/*     */     
/* 320 */     return this.m_oraCharReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 339 */     int i = paramInt1 + paramInt2;
/* 340 */     char[] arrayOfChar = new char[paramInt2];
/*     */     
/* 342 */     byte b = 0;
/*     */     
/* 344 */     for (int j = paramInt1; j < i; j++) {
/*     */       
/* 346 */       int k = this.m_ucsChar[paramArrayOfbyte[j] & 0xFF];
/*     */       
/* 348 */       if (k == -1)
/*     */       {
/* 350 */         throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */       }
/*     */ 
/*     */       
/* 354 */       arrayOfChar[b++] = (char)k;
/*     */     } 
/*     */ 
/*     */     
/* 358 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 370 */     int i = paramInt1 + paramInt2;
/* 371 */     char[] arrayOfChar = new char[paramInt2];
/*     */     
/* 373 */     byte b = 0;
/*     */     
/* 375 */     for (int j = paramInt1; j < i; j++) {
/*     */       
/* 377 */       int k = this.m_ucsChar[paramArrayOfbyte[j] & 0xFF];
/*     */       
/* 379 */       if (k == -1) {
/* 380 */         arrayOfChar[b++] = (char)this.m_ucsReplacement;
/*     */       } else {
/* 382 */         arrayOfChar[b++] = (char)k;
/*     */       } 
/*     */     } 
/* 385 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toUnicodeCharsWithReplacement(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
/* 402 */     int i = paramInt1 + paramInt3;
/*     */     
/* 404 */     int k = paramInt2;
/*     */ 
/*     */     
/* 407 */     i = Math.min(paramInt1 + paramInt3, paramArrayOfbyte.length);
/*     */     int j;
/* 409 */     for (j = paramInt1; j < i && k < paramArrayOfchar.length; j++) {
/*     */       
/* 411 */       int m = this.m_ucsChar[paramArrayOfbyte[j] & 0xFF];
/*     */       
/* 413 */       if (m == -1) {
/* 414 */         paramArrayOfchar[k++] = (char)this.m_ucsReplacement;
/*     */       } else {
/* 416 */         paramArrayOfchar[k++] = (char)m;
/*     */       } 
/*     */     } 
/* 419 */     return j - paramInt1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleString(String paramString) throws SQLException {
/* 431 */     int i = paramString.length();
/*     */     
/* 433 */     if (i == 0)
/*     */     {
/* 435 */       return new byte[0];
/*     */     }
/*     */     
/* 438 */     char[] arrayOfChar = new char[i];
/* 439 */     paramString.getChars(0, i, arrayOfChar, 0);
/*     */     
/* 441 */     byte[] arrayOfByte = new byte[i * 4];
/*     */     
/* 443 */     byte b1 = 0;
/*     */     
/* 445 */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       
/* 447 */       if (arrayOfChar[b2] >= '?' && arrayOfChar[b2] < '?') {
/*     */         
/* 449 */         if (b2 + 1 < i && arrayOfChar[b2 + 1] >= '?' && arrayOfChar[b2 + 1] <= '?')
/*     */         {
/*     */ 
/*     */           
/* 453 */           if (this.noSurrogate)
/*     */           {
/* 455 */             throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */           }
/* 457 */           arrayOfByte[b1++] = toOracleCharacter(arrayOfChar[b2], arrayOfChar[b2 + 1]);
/*     */           
/* 459 */           b2++;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 464 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 469 */       else if (arrayOfChar[b2] < '' && this.strictASCII) {
/*     */         
/* 471 */         arrayOfByte[b1++] = (byte)arrayOfChar[b2];
/*     */       } else {
/*     */         
/* 474 */         arrayOfByte[b1++] = toOracleCharacter(arrayOfChar[b2]);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 479 */     if (b1 < arrayOfByte.length) {
/*     */ 
/*     */       
/* 482 */       byte[] arrayOfByte1 = new byte[b1];
/* 483 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*     */       
/* 485 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 489 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*     */     byte[] arrayOfByte;
/*     */     byte b;
/* 517 */     int i = paramArrayOfint[0];
/*     */ 
/*     */ 
/*     */     
/* 521 */     int j = paramInt1 + i;
/*     */ 
/*     */     
/* 524 */     if (paramArrayOfbyte != null) {
/*     */       
/* 526 */       arrayOfByte = paramArrayOfbyte;
/* 527 */       b = paramInt2;
/*     */     }
/*     */     else {
/*     */       
/* 531 */       arrayOfByte = new byte[i * 4];
/* 532 */       b = 0;
/* 533 */       paramInt2 = 0;
/*     */     } 
/*     */     
/* 536 */     for (int k = paramInt1; k < j; k++) {
/*     */       
/* 538 */       if (paramArrayOfchar[k] >= '?' && paramArrayOfchar[k] < '?') {
/*     */         
/* 540 */         if (k + 1 < j && paramArrayOfchar[k + 1] >= '?' && paramArrayOfchar[k + 1] <= '?')
/*     */         {
/*     */ 
/*     */           
/* 544 */           if (this.noSurrogate) {
/*     */             
/* 546 */             arrayOfByte[b++] = this.m_oraCharReplacement;
/*     */           }
/*     */           else {
/*     */             
/* 550 */             arrayOfByte[b++] = 
/* 551 */               toOracleCharacterWithReplacement(paramArrayOfchar[k], paramArrayOfchar[k + 1]);
/*     */           } 
/* 553 */           k++;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 558 */           arrayOfByte[b++] = this.m_oraCharReplacement;
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 565 */       else if (paramArrayOfchar[k] < '' && this.strictASCII) {
/*     */         
/* 567 */         arrayOfByte[b++] = (byte)paramArrayOfchar[k];
/*     */       }
/*     */       else {
/*     */         
/* 571 */         arrayOfByte[b++] = 
/* 572 */           toOracleCharacterWithReplacement(paramArrayOfchar[k]);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 578 */     paramArrayOfint[0] = b - paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 585 */     if (paramArrayOfbyte == null && b < arrayOfByte.length) {
/*     */       
/* 587 */       byte[] arrayOfByte1 = new byte[b];
/* 588 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b);
/*     */       
/* 590 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 594 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOraCharacterReplacement(char paramChar1, char paramChar2) {
/* 600 */     if (paramChar2 != '\000') {
/* 601 */       return (toOracleCharacterWithReplacement(paramChar1, paramChar2) == this.m_oraCharReplacement);
/*     */     }
/* 603 */     return (toOracleCharacterWithReplacement(paramChar1) == this.m_oraCharReplacement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildUnicodeToOracleMapping() {
/* 639 */     this.m_oraCharLevel1 = new char[256];
/* 640 */     this.m_oraCharSurrogateLevel = null;
/* 641 */     this.m_oraCharLevel2 = null;
/*     */     
/* 643 */     Vector<int[]> vector = new Vector(45055, 12287);
/* 644 */     Hashtable<Object, Object> hashtable1 = new Hashtable<Object, Object>();
/* 645 */     Hashtable<Object, Object> hashtable2 = new Hashtable<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 654 */     int i = this.m_ucsChar.length;
/* 655 */     char c1 = Character.MIN_VALUE;
/* 656 */     char c2 = Character.MIN_VALUE;
/*     */     
/*     */     byte b1;
/* 659 */     for (b1 = 0; b1 < 'Ā'; b1++)
/*     */     {
/* 661 */       this.m_oraCharLevel1[b1] = Character.MAX_VALUE;
/*     */     }
/*     */     
/* 664 */     for (b1 = 0; b1 < i; b1++) {
/*     */ 
/*     */       
/* 667 */       int j = this.m_ucsChar[b1];
/*     */       
/* 669 */       if (j != -1)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 674 */         if (j != this.m_ucsReplacement) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 679 */           int[] arrayOfInt = new int[2];
/* 680 */           arrayOfInt[0] = j;
/* 681 */           arrayOfInt[1] = b1;
/* 682 */           vector.addElement(arrayOfInt);
/* 683 */           storeMappingRange(j, hashtable1, hashtable2);
/*     */         }  } 
/*     */     } 
/* 686 */     if (this.extraUnicodeToOracleMapping != null) {
/*     */       
/* 688 */       i = this.extraUnicodeToOracleMapping.length;
/*     */       
/* 690 */       for (b1 = 0; b1 < i; b1++) {
/*     */ 
/*     */         
/* 693 */         int j = this.extraUnicodeToOracleMapping[b1][0];
/* 694 */         if (j != this.m_ucsReplacement) {
/* 695 */           storeMappingRange(j, hashtable1, hashtable2);
/*     */         }
/*     */       } 
/*     */     } 
/* 699 */     Enumeration<Object> enumeration = hashtable1.keys();
/*     */ 
/*     */     
/* 702 */     byte b2 = 0;
/* 703 */     byte b3 = 0;
/*     */     
/* 705 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 707 */       Object object = enumeration.nextElement();
/* 708 */       char[] arrayOfChar = (char[])hashtable1.get(object);
/*     */       
/* 710 */       if (arrayOfChar != null)
/*     */       {
/*     */         
/* 713 */         b2 += true;
/*     */       }
/*     */     } 
/*     */     
/* 717 */     enumeration = hashtable2.keys();
/*     */     
/* 719 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 721 */       Object object = enumeration.nextElement();
/* 722 */       char[] arrayOfChar = (char[])hashtable2.get(object);
/*     */       
/* 724 */       if (arrayOfChar != null)
/*     */       {
/*     */         
/* 727 */         b3 += true;
/*     */       }
/*     */     } 
/*     */     
/* 731 */     if (b2)
/*     */     {
/* 733 */       this.m_oraCharSurrogateLevel = new char[b2];
/*     */     }
/*     */     
/* 736 */     if (b3)
/*     */     {
/* 738 */       this.m_oraCharLevel2 = new char[b3 + 256];
/*     */     }
/*     */     
/* 741 */     for (b1 = 0; b1 < b2; b1++)
/*     */     {
/* 743 */       this.m_oraCharSurrogateLevel[b1] = Character.MAX_VALUE;
/*     */     }
/*     */     
/* 746 */     for (b1 = 0; b1 < b3 + 256; b1++)
/*     */     {
/* 748 */       this.m_oraCharLevel2[b1] = Character.MAX_VALUE;
/*     */     }
/*     */     
/* 751 */     for (b1 = 0; b1 < vector.size(); b1++) {
/*     */       
/* 753 */       int[] arrayOfInt = vector.elementAt(b1);
/*     */       
/* 755 */       if (arrayOfInt[0] != this.m_ucsReplacement) {
/*     */ 
/*     */         
/* 758 */         int j = arrayOfInt[0] >> 24 & 0xFF;
/* 759 */         int k = arrayOfInt[0] >> 16 & 0xFF;
/* 760 */         int m = arrayOfInt[0] >> 8 & 0xFF;
/* 761 */         int n = arrayOfInt[0] & 0xFF;
/*     */         
/* 763 */         if (j >= 216 && j < 220) {
/*     */           
/* 765 */           if (this.m_oraCharLevel1[j] == Character.MAX_VALUE) {
/*     */             
/* 767 */             this.m_oraCharLevel1[j] = c2;
/* 768 */             c2 = (char)(c2 + 256);
/*     */           } 
/*     */           
/* 771 */           if (this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] == Character.MAX_VALUE) {
/*     */             
/* 773 */             this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] = c2;
/* 774 */             c2 = (char)(c2 + 256);
/*     */           } 
/*     */           
/* 777 */           if (this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] == Character.MAX_VALUE) {
/*     */ 
/*     */             
/* 780 */             this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] = c1;
/* 781 */             c1 = (char)(c1 + 256);
/*     */           } 
/*     */           
/* 784 */           if (this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] == Character.MAX_VALUE)
/*     */           {
/*     */             
/* 787 */             this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] = (char)(arrayOfInt[1] & 0xFFFF);
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 797 */           if (this.m_oraCharLevel1[m] == Character.MAX_VALUE) {
/*     */             
/* 799 */             this.m_oraCharLevel1[m] = c1;
/* 800 */             c1 = (char)(c1 + 256);
/*     */           } 
/*     */           
/* 803 */           if (this.m_oraCharLevel2[this.m_oraCharLevel1[m] + n] == Character.MAX_VALUE)
/*     */           {
/* 805 */             this.m_oraCharLevel2[this.m_oraCharLevel1[m] + n] = (char)(arrayOfInt[1] & 0xFFFF);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 815 */     if (this.extraUnicodeToOracleMapping != null) {
/*     */       
/* 817 */       i = this.extraUnicodeToOracleMapping.length;
/*     */       
/* 819 */       for (b1 = 0; b1 < i; b1++) {
/*     */ 
/*     */         
/* 822 */         int j = this.extraUnicodeToOracleMapping[b1][0];
/*     */         
/* 824 */         if (j != this.m_ucsReplacement) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 829 */           int k = j >>> 24 & 0xFF;
/* 830 */           int m = j >>> 16 & 0xFF;
/* 831 */           int n = j >>> 8 & 0xFF;
/* 832 */           int i1 = j & 0xFF;
/*     */           
/* 834 */           if (k >= 216 && k < 220) {
/*     */             
/* 836 */             if (this.m_oraCharLevel1[k] == Character.MAX_VALUE) {
/*     */ 
/*     */               
/* 839 */               this.m_oraCharLevel1[k] = c2;
/* 840 */               c2 = (char)(c2 + 256);
/*     */             } 
/*     */             
/* 843 */             if (this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[k] + m] == Character.MAX_VALUE) {
/*     */               
/* 845 */               this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[k] + m] = c2;
/* 846 */               c2 = (char)(c2 + 256);
/*     */             } 
/*     */             
/* 849 */             if (this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[k] + m] + n] == Character.MAX_VALUE) {
/*     */ 
/*     */               
/* 852 */               this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[k] + m] + n] = c1;
/* 853 */               c1 = (char)(c1 + 256);
/*     */             } 
/*     */             
/* 856 */             this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[k] + m] + n] + i1] = (char)(this.extraUnicodeToOracleMapping[b1][1] & 0xFF);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 861 */             if (this.m_oraCharLevel1[n] == Character.MAX_VALUE) {
/*     */               
/* 863 */               this.m_oraCharLevel1[n] = c1;
/* 864 */               c1 = (char)(c1 + 256);
/*     */             } 
/*     */             
/* 867 */             this.m_oraCharLevel2[this.m_oraCharLevel1[n] + i1] = (char)(this.extraUnicodeToOracleMapping[b1][1] & 0xFFFF);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 872 */     if (this.m_oraCharSurrogateLevel == null) {
/* 873 */       this.noSurrogate = true;
/*     */     } else {
/* 875 */       this.noSurrogate = false;
/*     */     } 
/* 877 */     this.strictASCII = true;
/* 878 */     for (b1 = 0; b1 < ''; b1++) {
/*     */       
/* 880 */       if (this.m_oraCharLevel2[b1] != b1) {
/*     */         
/* 882 */         this.strictASCII = false;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 887 */     for (b1 = 0; b1 < 'Ā'; b1++) {
/*     */       
/* 889 */       if (this.m_oraCharLevel1[b1] == Character.MAX_VALUE)
/* 890 */         this.m_oraCharLevel1[b1] = (char)b3; 
/*     */     } 
/* 892 */     this.m_oraCharLevel2Size = b3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extractCodepoints(Vector<int[]> paramVector) {
/* 899 */     byte b1 = 0;
/* 900 */     char c = 'ÿ';
/*     */ 
/*     */     
/* 903 */     for (byte b2 = b1; b2 <= c; b2++) {
/*     */ 
/*     */       
/*     */       try {
/* 907 */         int[] arrayOfInt = new int[2];
/* 908 */         arrayOfInt[0] = b2;
/* 909 */         arrayOfInt[1] = toUnicode((byte)b2);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 914 */         paramVector.addElement(arrayOfInt);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 919 */       catch (SQLException sQLException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extractExtraMappings(Vector<int[]> paramVector) {
/* 928 */     if (this.extraUnicodeToOracleMapping == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 935 */     for (byte b = 0; b < this.extraUnicodeToOracleMapping.length; b++) {
/*     */       
/* 937 */       int[] arrayOfInt = new int[2];
/* 938 */       arrayOfInt[0] = this.extraUnicodeToOracleMapping[b][0];
/* 939 */       arrayOfInt[1] = this.extraUnicodeToOracleMapping[b][1];
/* 940 */       paramVector.addElement(arrayOfInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasExtraMappings() {
/* 946 */     return (this.extraUnicodeToOracleMapping != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getOraChar1ByteRep() {
/* 951 */     return (char)(this.m_oraCharReplacement & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getOraChar2ByteRep() {
/* 956 */     return Character.MIN_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getUCS2CharRep() {
/* 961 */     return this.m_ucsReplacement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ByteToCharConvert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 970 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int CharToByteConvert(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 978 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverter1Byte.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverterLCFixed
/*     */   extends CharacterConverterLC
/*     */ {
/* 103 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */   
/*     */   static final int ORACHARBYTECNT = 4;
/*     */   
/* 107 */   public int m_4ByteOraCharReplacement = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharacterConverterLCFixed() {
/* 114 */     this.m_groupId = 3;
/* 115 */     this.averageCharsPerByte = 0.25F;
/* 116 */     this.maxCharsPerByte = 1.0F;
/* 117 */     this.maxBytesPerChar = 4.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toOracleCharacter(char paramChar1, char paramChar2) throws SQLException {
/* 134 */     int i = -1;
/*     */     
/* 136 */     if (paramChar2 != '\000') {
/*     */ 
/*     */       
/* 139 */       int j = paramChar1 >>> 8 & 0xFF;
/* 140 */       int k = paramChar1 & 0xFF;
/* 141 */       int m = paramChar2 >>> 8 & 0xFF;
/* 142 */       int n = paramChar2 & 0xFF;
/*     */       
/* 144 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] != -1)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 149 */         i = this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n];
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 155 */       int j = paramChar1 >>> 8 & 0xFF;
/* 156 */       int k = paramChar1 & 0xFF;
/*     */       
/* 158 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k] != -1)
/*     */       {
/*     */         
/* 161 */         i = this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 166 */     if (i == -1)
/*     */     {
/* 168 */       throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */     }
/*     */ 
/*     */     
/* 172 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toOracleCharacterWithReplacement(char paramChar1, char paramChar2) {
/* 184 */     int i = -1;
/*     */     
/* 186 */     if (paramChar2 != '\000') {
/*     */ 
/*     */       
/* 189 */       int j = paramChar1 >>> 8 & 0xFF;
/* 190 */       int k = paramChar1 & 0xFF;
/* 191 */       int m = paramChar2 >>> 8 & 0xFF;
/* 192 */       int n = paramChar2 & 0xFF;
/*     */       
/* 194 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] != Character.MAX_VALUE && this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n] != -1)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 199 */         i = this.m_oraCharLevel2[this.m_oraCharSurrogateLevel[this.m_oraCharSurrogateLevel[this.m_oraCharLevel1[j] + k] + m] + n];
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 205 */       int j = paramChar1 >>> 8 & 0xFF;
/* 206 */       int k = paramChar1 & 0xFF;
/*     */       
/* 208 */       if (this.m_oraCharLevel1[j] != Character.MAX_VALUE && this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k] != -1)
/*     */       {
/*     */         
/* 211 */         i = this.m_oraCharLevel2[this.m_oraCharLevel1[j] + k];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 216 */     if (i == -1)
/*     */     {
/* 218 */       return this.m_4ByteOraCharReplacement;
/*     */     }
/*     */ 
/*     */     
/* 222 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 242 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 243 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     if (paramInt2 >= 4) {
/*     */       
/* 254 */       int i = paramArrayOfbyte[paramInt1] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 1] & 0xFF;
/*     */ 
/*     */ 
/*     */       
/* 258 */       for (byte b1 = 0; b1 < this.m_ucsCharLeadingCode.length; b1++) {
/*     */         
/* 260 */         if (i == this.m_ucsCharLeadingCode[b1][0]) {
/*     */           int k;
/* 262 */           char c = this.m_ucsCharLeadingCode[b1][1];
/* 263 */           int j = paramArrayOfbyte[paramInt1 + 2] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 3] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 268 */           int m = (j >> 8 & 0xFF) + c;
/* 269 */           int n = j & 0xFF;
/*     */ 
/*     */           
/* 272 */           if (this.m_ucsCharLevel1[m] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[m] + n] != -1) {
/*     */ 
/*     */             
/* 275 */             k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[m] + n];
/*     */           }
/*     */           else {
/*     */             
/* 279 */             throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */           } 
/*     */ 
/*     */           
/* 283 */           if ((k & 0xFFFFFFFFL) > 65535L) {
/*     */             
/* 285 */             arrayOfChar[b++] = (char)(k >>> 16);
/* 286 */             arrayOfChar[b++] = (char)(k & 0xFFFF);
/*     */           }
/*     */           else {
/*     */             
/* 290 */             arrayOfChar[b++] = (char)k;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 295 */           paramInt2 -= 4;
/* 296 */           paramInt1 += 4;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 302 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     } 
/*     */     
/* 305 */     if (paramInt2 != 0)
/*     */     {
/* 307 */       throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */     }
/*     */     
/* 310 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 324 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 325 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 332 */     while (paramInt2 >= 4) {
/*     */       
/* 334 */       int i = paramArrayOfbyte[paramInt1] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 1] & 0xFF;
/*     */       
/* 336 */       int j = this.m_ucsCharReplacement;
/*     */ 
/*     */       
/* 339 */       for (byte b1 = 0; b1 < this.m_ucsCharLeadingCode.length; b1++) {
/*     */         
/* 341 */         if (i == this.m_ucsCharLeadingCode[b1][0]) {
/*     */           
/* 343 */           char c = this.m_ucsCharLeadingCode[b1][1];
/* 344 */           int k = paramArrayOfbyte[paramInt1 + 2] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 3] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 349 */           int m = (k >> 8 & 0xFF) + c;
/* 350 */           int n = k & 0xFF;
/*     */ 
/*     */           
/* 353 */           if (this.m_ucsCharLevel1[m] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[m] + n] != -1) {
/*     */ 
/*     */             
/* 356 */             j = this.m_ucsCharLevel2[this.m_ucsCharLevel1[m] + n];
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 361 */           j = this.m_ucsCharReplacement;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 369 */       if ((j & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 371 */         arrayOfChar[b++] = (char)(j >>> 16);
/* 372 */         arrayOfChar[b++] = (char)(j & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 376 */         arrayOfChar[b++] = (char)j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 381 */       paramInt2 -= 4;
/* 382 */       paramInt1 += 4;
/*     */     } 
/*     */     
/* 385 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ByteToCharConvert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 394 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int CharToByteConvert(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 402 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toUnicodeCharsWithReplacement(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
/* 409 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterLCFixed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Vector;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverterJAEUC
/*     */   extends CharacterConverterLC
/*     */ {
/* 107 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int LEADINGCODE = 143;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicode(int paramInt) throws SQLException {
/* 135 */     char c = Character.MIN_VALUE;
/*     */     
/* 137 */     if ((paramInt >> 16 & 0xFFFF) == 143)
/*     */     {
/* 139 */       c = 'Ā';
/*     */     }
/*     */ 
/*     */     
/* 143 */     int i = paramInt >> 8 & 255 + c;
/* 144 */     int j = paramInt & 0xFF;
/*     */ 
/*     */     
/* 147 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1)
/*     */     {
/*     */       
/* 150 */       return this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*     */     }
/*     */ 
/*     */     
/* 154 */     throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int toUnicodeWithReplacement(int paramInt) {
/*     */     int k;
/* 168 */     char c = Character.MIN_VALUE;
/*     */     
/* 170 */     if ((paramInt >> 16 & 0xFFFF) == 143)
/*     */     {
/* 172 */       c = 'Ā';
/*     */     }
/*     */ 
/*     */     
/* 176 */     int i = paramInt >> 8 & 255 + c;
/* 177 */     int j = paramInt & 0xFF;
/*     */ 
/*     */     
/* 180 */     if (this.m_ucsCharLevel1[i] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j] != -1) {
/*     */ 
/*     */       
/* 183 */       k = this.m_ucsCharLevel2[this.m_ucsCharLevel1[i] + j];
/*     */     }
/*     */     else {
/*     */       
/* 187 */       k = this.m_ucsCharReplacement;
/*     */     } 
/*     */     
/* 190 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 209 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 210 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     while (paramInt2 > 0) {
/*     */       int j; byte b1;
/* 220 */       int i = paramArrayOfbyte[paramInt1] & 0xFF;
/* 221 */       char c = Character.MIN_VALUE;
/*     */       
/* 223 */       if (i == 143) {
/*     */         
/* 225 */         if (paramInt2 < 3)
/*     */         {
/* 227 */           throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 232 */         i = paramArrayOfbyte[paramInt1 + 1] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 2] & 0xFF;
/*     */         
/* 234 */         b1 = 3;
/* 235 */         c = 'Ā';
/*     */       }
/* 237 */       else if (i > 127) {
/*     */         
/* 239 */         if (paramInt2 < 2)
/*     */         {
/* 241 */           throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 246 */         i = paramArrayOfbyte[paramInt1] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 1] & 0xFF;
/*     */         
/* 248 */         b1 = 2;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 253 */         b1 = 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 258 */       int k = (i >> 8 & 0xFF) + c;
/* 259 */       int m = i & 0xFF;
/*     */ 
/*     */       
/* 262 */       if (this.m_ucsCharLevel1[k] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m] != -1) {
/*     */ 
/*     */         
/* 265 */         j = this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m];
/*     */       }
/*     */       else {
/*     */         
/* 269 */         throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */       } 
/*     */ 
/*     */       
/* 273 */       if ((j & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 275 */         arrayOfChar[b++] = (char)(j >>> 16);
/* 276 */         arrayOfChar[b++] = (char)(j & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 280 */         arrayOfChar[b++] = (char)j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 285 */       paramInt2 -= b1;
/* 286 */       paramInt1 += b1;
/*     */     } 
/*     */     
/* 289 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 303 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 304 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     while (paramInt2 > 0) {
/*     */       int j; byte b1;
/* 314 */       int i = paramArrayOfbyte[paramInt1] & 0xFF;
/* 315 */       char c = Character.MIN_VALUE;
/*     */       
/* 317 */       if (i == 143) {
/*     */         
/* 319 */         if (paramInt2 < 3) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 327 */         i = paramArrayOfbyte[paramInt1 + 1] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 2] & 0xFF;
/*     */         
/* 329 */         b1 = 3;
/* 330 */         c = 'Ā';
/*     */       }
/* 332 */       else if (i > 127) {
/*     */         
/* 334 */         if (paramInt2 < 2) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 342 */         i = paramArrayOfbyte[paramInt1] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 1] & 0xFF;
/*     */         
/* 344 */         b1 = 2;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 349 */         b1 = 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 354 */       int k = (i >> 8 & 0xFF) + c;
/* 355 */       int m = i & 0xFF;
/*     */       
/* 357 */       if (this.m_ucsCharLevel1[k] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m] != -1) {
/*     */ 
/*     */         
/* 360 */         j = this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m];
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 365 */         j = this.m_ucsCharReplacement;
/*     */       } 
/*     */       
/* 368 */       if ((j & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 370 */         arrayOfChar[b++] = (char)(j >>> 16);
/* 371 */         arrayOfChar[b++] = (char)(j & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 375 */         arrayOfChar[b++] = (char)j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 380 */       paramInt2 -= b1;
/* 381 */       paramInt1 += b1;
/*     */     } 
/*     */     
/* 384 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extractCodepoints(Vector<int[]> paramVector) {
/* 395 */     int i = 0;
/* 396 */     int j = 65535;
/*     */     
/*     */     int k;
/* 399 */     for (k = i; k <= j; k++) {
/*     */ 
/*     */       
/*     */       try {
/* 403 */         int[] arrayOfInt = new int[2];
/* 404 */         arrayOfInt[0] = k;
/* 405 */         arrayOfInt[1] = toUnicode(k);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 410 */         paramVector.addElement(arrayOfInt);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 415 */       catch (SQLException sQLException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     i = 9371648;
/* 424 */     j = i + 65535;
/*     */     
/* 426 */     for (k = i; k <= j; k++) {
/*     */ 
/*     */       
/*     */       try {
/* 430 */         int[] arrayOfInt = new int[2];
/* 431 */         arrayOfInt[0] = k;
/* 432 */         arrayOfInt[1] = toUnicode(k);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 437 */         paramVector.addElement(arrayOfInt);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 443 */       catch (SQLException sQLException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ByteToCharConvert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 456 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int CharToByteConvert(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 464 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toUnicodeCharsWithReplacement(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
/* 471 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterJAEUC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
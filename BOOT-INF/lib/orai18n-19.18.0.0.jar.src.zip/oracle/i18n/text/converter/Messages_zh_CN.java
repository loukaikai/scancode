/*    */ package oracle.i18n.text.converter;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages_zh_CN
/*    */   extends ListResourceBundle
/*    */ {
/*    */   public Object[][] getContents() {
/* 26 */     return this.contents;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private Object[][] contents = new Object[][] { { "17154", "无法将 Oracle 字符映射到 Unicode" }, { "17155", "无法将 Unicode 映射到 Oracle 字符" }, { "7002", "Unicode 代理无效" } };
/*    */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\Messages_zh_CN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
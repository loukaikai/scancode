/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharsetMeta
/*     */   implements Serializable
/*     */ {
/*  33 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*  34 */   private static CharsetMeta m_instance = null;
/*     */   
/*     */   public static final String FILENAME = "charsetMeta";
/*     */   
/*     */   public static final String CUSTOM_CHARSET_METAFILE = "charsetMeta.properties";
/*     */   
/*     */   protected String[] m_aveCharsets;
/*     */   protected Map m_charSetIdMap;
/*     */   protected Map m_containsCharset;
/*     */   
/*     */   public static synchronized CharsetMeta getInstance() {
/*  45 */     if (m_instance == null)
/*     */     {
/*  47 */       m_instance = (CharsetMeta)readObj(
/*  48 */           GDKOracleMetaData.getDataPath() + "charsetMeta" + ".glb");
/*     */     }
/*     */     
/*  51 */     return m_instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAvailableCharacterSets() {
/*  61 */     return this.m_aveCharsets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharSetId(String paramString) {
/*  73 */     return (String)this.m_charSetIdMap.get(paramString.toUpperCase(Locale.US));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getContainsCharset(int paramInt) {
/*  86 */     return (int[])this.m_containsCharset.get(new Integer(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object readObj(String paramString) {
/* 100 */     Class<CharsetMeta> clazz = CharsetMeta.class;
/* 101 */     URL uRL = clazz.getResource(paramString);
/*     */     
/* 103 */     if (uRL == null)
/*     */     {
/* 105 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 110 */       InputStream inputStream = uRL.openStream();
/* 111 */       ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
/* 112 */       Object object = objectInputStream.readObject();
/* 113 */       objectInputStream.close();
/* 114 */       inputStream.close();
/* 115 */       readCustomCharsetMeta((CharsetMeta)object);
/* 116 */       return object;
/*     */     }
/* 118 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 121 */       throw new RuntimeException(exception.getClass().getName() + ": " + exception
/* 122 */           .getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readCustomCharsetMeta(CharsetMeta paramCharsetMeta) {
/*     */     try {
/* 139 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 140 */       URL uRL = classLoader.getResource("charsetMeta.properties");
/* 141 */       if (uRL == null) {
/*     */         return;
/*     */       }
/* 144 */       InputStream inputStream = uRL.openStream();
/* 145 */       ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
/* 146 */       Properties properties = (Properties)objectInputStream.readObject();
/* 147 */       Enumeration<?> enumeration = properties.propertyNames();
/* 148 */       while (enumeration.hasMoreElements()) {
/*     */         
/* 150 */         String str1 = (String)enumeration.nextElement();
/* 151 */         String str2 = properties.getProperty(str1);
/*     */ 
/*     */ 
/*     */         
/* 155 */         StringTokenizer stringTokenizer = new StringTokenizer(str2, ";");
/* 156 */         String str3 = stringTokenizer.nextToken();
/* 157 */         paramCharsetMeta.m_charSetIdMap.put(str3, str1);
/* 158 */         paramCharsetMeta.m_aveCharsets = addToArray(paramCharsetMeta.m_aveCharsets, str3);
/*     */       } 
/*     */     } catch (Exception exception) {
/* 161 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String[] addToArray(String[] paramArrayOfString, String paramString) {
/* 166 */     String[] arrayOfString = null;
/* 167 */     if (paramArrayOfString != null) {
/* 168 */       arrayOfString = new String[paramArrayOfString.length + 1];
/* 169 */       System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
/* 170 */       arrayOfString[paramArrayOfString.length] = paramString;
/* 171 */       Arrays.sort((Object[])arrayOfString);
/*     */     } 
/* 173 */     return arrayOfString;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharsetMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverter2ByteFixed
/*     */   extends CharacterConverter12Byte
/*     */ {
/*  46 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  74 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/*  78 */     char[] arrayOfChar = new char[paramInt2];
/*  79 */     byte b = 0;
/*  80 */     int j = paramInt1;
/*     */ 
/*     */ 
/*     */     
/*  84 */     while (j < i) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  89 */       int k = paramArrayOfbyte[j] & 0xFF;
/*     */       
/*  91 */       if (j < i - 1) {
/*     */         
/*  93 */         k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */         
/*  95 */         j++;
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 103 */         throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 109 */       int m = toUnicode(k);
/*     */       
/* 111 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 113 */         arrayOfChar[b++] = (char)(m >>> 16);
/* 114 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 118 */         arrayOfChar[b++] = (char)m;
/*     */       } 
/*     */       
/* 121 */       j++;
/*     */     } 
/*     */     
/* 124 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 136 */     int i = paramInt1 + paramInt2;
/*     */ 
/*     */ 
/*     */     
/* 140 */     char[] arrayOfChar = new char[paramInt2];
/* 141 */     byte b = 0;
/* 142 */     int j = paramInt1;
/* 143 */     int k = 0;
/*     */ 
/*     */     
/* 146 */     while (j < i) {
/*     */ 
/*     */       
/* 149 */       k = paramArrayOfbyte[j] & 0xFF;
/*     */       
/* 151 */       if (j < i - 1) {
/*     */ 
/*     */ 
/*     */         
/* 155 */         k = paramArrayOfbyte[j] << 8 & 0xFF00 | paramArrayOfbyte[j + 1] & 0xFF;
/*     */         
/* 157 */         j++;
/*     */       } 
/*     */ 
/*     */       
/* 161 */       int m = toUnicodeWithReplacement(k);
/*     */       
/* 163 */       if ((m & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 165 */         arrayOfChar[b++] = (char)(m >>> 16);
/* 166 */         arrayOfChar[b++] = (char)(m & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 170 */         arrayOfChar[b++] = (char)m;
/*     */       } 
/*     */       
/* 173 */       j++;
/*     */     } 
/*     */     
/* 176 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleString(String paramString) throws SQLException {
/* 188 */     int i = paramString.length();
/*     */     
/* 190 */     if (i == 0)
/*     */     {
/* 192 */       return new byte[0];
/*     */     }
/*     */     
/* 195 */     char[] arrayOfChar = new char[i];
/* 196 */     paramString.getChars(0, i, arrayOfChar, 0);
/*     */     
/* 198 */     byte[] arrayOfByte = new byte[i * 2];
/*     */     
/* 200 */     byte b1 = 0;
/*     */     
/* 202 */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       char c;
/* 204 */       if (arrayOfChar[b2] >= '?' && arrayOfChar[b2] < '?') {
/*     */         
/* 206 */         if (b2 + 1 < i && arrayOfChar[b2 + 1] >= '?' && arrayOfChar[b2 + 1] <= '?')
/*     */         {
/*     */ 
/*     */           
/* 210 */           c = toOracleCharacterWithReplacement(arrayOfChar[b2], arrayOfChar[b2 + 1]);
/*     */           
/* 212 */           b2++;
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 217 */           throw new SQLException(GDKMessage.getORAMessage(17155), null, 17155);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 222 */         c = toOracleCharacter(arrayOfChar[b2], false);
/*     */       } 
/*     */       
/* 225 */       arrayOfByte[b1++] = (byte)(c >> 8);
/* 226 */       arrayOfByte[b1++] = (byte)c;
/*     */     } 
/*     */     
/* 229 */     if (b1 < arrayOfByte.length) {
/*     */ 
/*     */       
/* 232 */       byte[] arrayOfByte1 = new byte[b1];
/* 233 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b1);
/*     */       
/* 235 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 239 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toOracleStringWithReplacement(char[] paramArrayOfchar, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int[] paramArrayOfint) {
/*     */     byte[] arrayOfByte;
/*     */     byte b;
/* 268 */     int i = paramArrayOfint[0];
/*     */ 
/*     */ 
/*     */     
/* 272 */     char c = '￿';
/* 273 */     int j = paramInt1 + i;
/*     */ 
/*     */     
/* 276 */     if (paramArrayOfbyte != null) {
/*     */       
/* 278 */       arrayOfByte = paramArrayOfbyte;
/* 279 */       b = paramInt2;
/*     */     }
/*     */     else {
/*     */       
/* 283 */       arrayOfByte = new byte[i * 4];
/* 284 */       b = 0;
/* 285 */       paramInt2 = 0;
/*     */     } 
/*     */     
/* 288 */     int k = paramInt1; while (true) { if (k < j) {
/*     */         
/* 290 */         if (paramArrayOfchar[k] >= '?' && paramArrayOfchar[k] < '?') {
/*     */           
/* 292 */           if (k + 1 < j && paramArrayOfchar[k + 1] >= '?' && paramArrayOfchar[k + 1] <= '?') {
/*     */ 
/*     */ 
/*     */             
/* 296 */             c = toOracleCharacterWithReplacement(paramArrayOfchar[k], paramArrayOfchar[k + 1]);
/*     */             
/* 298 */             k++;
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 303 */             arrayOfByte[b++] = (byte)(this.m_2ByteOraCharReplacement >> 8);
/* 304 */             arrayOfByte[b++] = (byte)this.m_2ByteOraCharReplacement;
/*     */ 
/*     */ 
/*     */             
/*     */             k++;
/*     */           } 
/*     */         } else {
/* 311 */           c = toOracleCharacterWithReplacement(paramArrayOfchar[k], false);
/*     */         } 
/*     */         
/* 314 */         arrayOfByte[b++] = (byte)(c >> 8);
/* 315 */         arrayOfByte[b++] = (byte)c;
/*     */       } else {
/*     */         break;
/*     */       }  k++; }
/* 319 */      paramArrayOfint[0] = b - paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 326 */     if (paramArrayOfbyte == null && b < arrayOfByte.length) {
/*     */       
/* 328 */       byte[] arrayOfByte1 = new byte[b];
/* 329 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, b);
/*     */       
/* 331 */       return arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 335 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverter2ByteFixed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
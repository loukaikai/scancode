/*     */ package oracle.i18n.text.converter;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.util.GDKOracleMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterConverterZHTEUC
/*     */   extends CharacterConverterLC
/*     */ {
/* 113 */   static final long serialVersionUID = GDKOracleMetaData.getOracleVersionID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 142 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 143 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     while (paramInt2 > 0) {
/*     */       
/* 153 */       int j, i = paramArrayOfbyte[paramInt1] & 0xFF;
/* 154 */       byte b1 = 1;
/* 155 */       char c = Character.MIN_VALUE;
/*     */       
/* 157 */       if (i > 127) {
/*     */ 
/*     */         
/* 160 */         if (paramInt2 < 2)
/*     */         {
/* 162 */           throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 168 */         i = i << 8 | paramArrayOfbyte[paramInt1 + 1] & 0xFF;
/*     */         
/* 170 */         b1 = 2;
/*     */ 
/*     */         
/* 173 */         for (byte b2 = 0; b2 < this.m_ucsCharLeadingCode.length; b2++) {
/*     */           
/* 175 */           if (i == this.m_ucsCharLeadingCode[b2][0]) {
/*     */ 
/*     */             
/* 178 */             if (paramInt2 < 4)
/*     */             {
/* 180 */               throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */             }
/*     */             
/* 183 */             c = this.m_ucsCharLeadingCode[b2][1];
/* 184 */             i = i << 16 | paramArrayOfbyte[paramInt1 + 2] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 3] & 0xFF;
/*     */ 
/*     */             
/* 187 */             b1 = 4;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 196 */       int k = (i >> 8 & 0xFF) + c;
/* 197 */       int m = i & 0xFF;
/*     */ 
/*     */       
/* 200 */       if (this.m_ucsCharLevel1[k] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m] != -1) {
/*     */ 
/*     */         
/* 203 */         j = this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m];
/*     */       }
/*     */       else {
/*     */         
/* 207 */         throw new SQLException(GDKMessage.getORAMessage(17154), null, 17154);
/*     */       } 
/*     */ 
/*     */       
/* 211 */       if ((j & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 213 */         arrayOfChar[b++] = (char)(j >>> 16);
/* 214 */         arrayOfChar[b++] = (char)(j & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 218 */         arrayOfChar[b++] = (char)j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 223 */       paramInt2 -= b1;
/* 224 */       paramInt1 += b1;
/*     */     } 
/*     */     
/* 227 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toUnicodeStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 241 */     char[] arrayOfChar = new char[paramInt2 * 2];
/* 242 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     while (paramInt2 > 0) {
/*     */       
/* 252 */       int j, i = paramArrayOfbyte[paramInt1] & 0xFF;
/* 253 */       byte b1 = 1;
/* 254 */       char c = Character.MIN_VALUE;
/*     */       
/* 256 */       if (i > 127) {
/*     */         
/* 258 */         if (paramInt2 < 2) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 266 */         i = i << 8 | paramArrayOfbyte[paramInt1 + 1] & 0xFF;
/*     */         
/* 268 */         b1 = 2;
/*     */         
/* 270 */         for (byte b2 = 0; b2 < this.m_ucsCharLeadingCode.length; b2++) {
/*     */           
/* 272 */           if (i == this.m_ucsCharLeadingCode[b2][0]) {
/*     */             
/* 274 */             c = this.m_ucsCharLeadingCode[b2][1];
/*     */ 
/*     */             
/* 277 */             if (paramInt2 < 4)
/*     */             {
/*     */               
/* 280 */               return new String(arrayOfChar, 0, b);
/*     */             }
/*     */             
/* 283 */             i = i << 16 | paramArrayOfbyte[paramInt1 + 2] << 8 & 0xFF00 | paramArrayOfbyte[paramInt1 + 3] & 0xFF;
/*     */ 
/*     */ 
/*     */             
/* 287 */             b1 = 4;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 296 */       int k = (i >> 8 & 0xFF) + c;
/* 297 */       int m = i & 0xFF;
/*     */       
/* 299 */       if (this.m_ucsCharLevel1[k] != Character.MAX_VALUE && this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m] != -1) {
/*     */ 
/*     */         
/* 302 */         j = this.m_ucsCharLevel2[this.m_ucsCharLevel1[k] + m];
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 307 */         j = this.m_ucsCharReplacement;
/*     */       } 
/*     */ 
/*     */       
/* 311 */       if ((j & 0xFFFFFFFFL) > 65535L) {
/*     */         
/* 313 */         arrayOfChar[b++] = (char)(j >>> 16);
/* 314 */         arrayOfChar[b++] = (char)(j & 0xFFFF);
/*     */       }
/*     */       else {
/*     */         
/* 318 */         arrayOfChar[b++] = (char)j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 323 */       paramInt2 -= b1;
/* 324 */       paramInt1 += b1;
/*     */     } 
/*     */     
/* 327 */     return new String(arrayOfChar, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int ByteToCharConvert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 336 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int CharToByteConvert(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4) throws IOException, CharConversionException, IndexOutOfBoundsException {
/* 344 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toUnicodeCharsWithReplacement(byte[] paramArrayOfbyte, int paramInt1, char[] paramArrayOfchar, int paramInt2, int paramInt3) {
/* 351 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\converter\CharacterConverterZHTEUC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package oracle.i18n.text;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.CharsetDecoder;
/*    */ import java.nio.charset.CoderResult;
/*    */ import java.nio.charset.CodingErrorAction;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OraCharsetDecoder
/*    */   extends CharsetDecoder
/*    */ {
/*    */   OraCharsetDecoder(OraCharset paramOraCharset, float paramFloat1, float paramFloat2) {
/* 37 */     super(paramOraCharset, paramFloat1, paramFloat2);
/*    */   }
/*    */ 
/*    */   
/*    */   public CoderResult decodeLoop(ByteBuffer paramByteBuffer, CharBuffer paramCharBuffer) {
/* 42 */     int i = paramByteBuffer.position();
/* 43 */     int j = paramByteBuffer.remaining();
/*    */ 
/*    */     
/* 46 */     if (j == 0)
/*    */     {
/* 48 */       return CoderResult.UNDERFLOW;
/*    */     }
/*    */ 
/*    */     
/* 52 */     byte[] arrayOfByte = new byte[j];
/* 53 */     paramByteBuffer.get(arrayOfByte);
/*    */ 
/*    */     
/*    */     try {
/* 57 */       CodingErrorAction codingErrorAction = malformedInputAction();
/*    */ 
/*    */       
/* 60 */       String str = (CodingErrorAction.REPLACE == unmappableCharacterAction()) ? ((OraCharset)charset()).toStringWithReplacement(arrayOfByte, 0, arrayOfByte.length) : ((OraCharset)charset()).toString(arrayOfByte, 0, arrayOfByte.length);
/*    */       
/* 62 */       int k = paramCharBuffer.remaining();
/*    */ 
/*    */       
/* 65 */       if (k < str.length()) {
/*    */ 
/*    */         
/* 68 */         paramByteBuffer.position(i);
/* 69 */         return CoderResult.OVERFLOW;
/*    */       } 
/*    */ 
/*    */       
/* 73 */       paramCharBuffer.put(str);
/*    */     }
/* 75 */     catch (SQLException sQLException) {
/*    */       
/* 77 */       paramByteBuffer.position(i);
/* 78 */       return CoderResult.unmappableForLength(j);
/*    */     } 
/* 80 */     return CoderResult.UNDERFLOW;
/*    */   }
/*    */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.io.UTFDataFormatException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetUTFE
/*     */   extends OraCharset
/*     */ {
/*     */   static final int MAXBYTEPERCHAR = 4;
/*  35 */   static byte[][] utf8m2utfe = new byte[][] { { 0, 1, 2, 3, 55, 45, 46, 47, 22, 5, 21, 11, 12, 13, 14, 15 }, { 16, 17, 18, 19, 60, 61, 50, 38, 24, 25, 63, 39, 28, 29, 30, 31 }, { 64, 90, Byte.MAX_VALUE, 123, 91, 108, 80, 125, 77, 93, 92, 78, 107, 96, 75, 97 }, { -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, 122, 94, 76, 126, 110, 111 }, { 124, -63, -62, -61, -60, -59, -58, -57, -56, -55, -47, -46, -45, -44, -43, -42 }, { -41, -40, -39, -30, -29, -28, -27, -26, -25, -24, -23, -83, -32, -67, 95, 109 }, { 121, -127, -126, -125, -124, -123, -122, -121, -120, -119, -111, -110, -109, -108, -107, -106 }, { -105, -104, -103, -94, -93, -92, -91, -90, -89, -88, -87, -64, 79, -48, -95, 7 }, { 32, 33, 34, 35, 36, 37, 6, 23, 40, 41, 42, 43, 44, 9, 10, 27 }, { 48, 49, 26, 51, 52, 53, 54, 8, 56, 57, 58, 59, 4, 20, 62, -1 }, { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 81, 82, 83, 84, 85, 86 }, { 87, 88, 89, 98, 99, 100, 101, 102, 103, 104, 105, 106, 112, 113, 114, 115 }, { 116, 117, 118, 119, 120, Byte.MIN_VALUE, -118, -117, -116, -115, -114, -113, -112, -102, -101, -100 }, { -99, -98, -97, -96, -86, -85, -84, -82, -81, -80, -79, -78, -77, -76, -75, -74 }, { -73, -72, -71, -70, -69, -68, -66, -65, -54, -53, -52, -51, -50, -49, -38, -37 }, { -36, -35, -34, -33, -31, -22, -21, -20, -19, -18, -17, -6, -5, -4, -3, -2 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   static byte[][] utfe2utf8m = new byte[][] { { 0, 1, 2, 3, -100, 9, -122, Byte.MAX_VALUE, -105, -115, -114, 11, 12, 13, 14, 15 }, { 16, 17, 18, 19, -99, 10, 8, -121, 24, 25, -110, -113, 28, 29, 30, 31 }, { Byte.MIN_VALUE, -127, -126, -125, -124, -123, 23, 27, -120, -119, -118, -117, -116, 5, 6, 7 }, { -112, -111, 22, -109, -108, -107, -106, 4, -104, -103, -102, -101, 20, 21, -98, 26 }, { 32, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, 46, 60, 40, 43, 124 }, { 38, -86, -85, -84, -83, -82, -81, -80, -79, -78, 33, 36, 42, 41, 59, 94 }, { 45, 47, -77, -76, -75, -74, -73, -72, -71, -70, -69, 44, 37, 95, 62, 63 }, { -68, -67, -66, -65, -64, -63, -62, -61, -60, 96, 58, 35, 64, 39, 61, 34 }, { -59, 97, 98, 99, 100, 101, 102, 103, 104, 105, -58, -57, -56, -55, -54, -53 }, { -52, 106, 107, 108, 109, 110, 111, 112, 113, 114, -51, -50, -49, -48, -47, -46 }, { -45, 126, 115, 116, 117, 118, 119, 120, 121, 122, -44, -43, -42, 88, -41, -40 }, { -39, -38, -37, -36, -35, -34, -33, -32, -31, -30, -29, -28, -27, 93, -26, -25 }, { 123, 65, 66, 67, 68, 69, 70, 71, 72, 73, -24, -23, -22, -21, -20, -19 }, { 13, 74, 75, 76, 77, 78, 79, 80, 81, 82, -18, -17, -16, -15, -14, -13 }, { 92, -12, 83, 84, 85, 86, 87, 88, 89, 90, -11, -10, -9, -8, -7, -6 }, { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, -5, -4, -3, -2, -1, -97 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OraCharsetUTFE(String paramString, int paramInt) {
/* 235 */     super(paramString, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Charset paramCharset) {
/* 241 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/* 247 */     return new OraCharsetDecoder(this, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/* 253 */     return new OraCharsetEncoder(this, 1.0F, 3.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/* 263 */       char[] arrayOfChar = new char[paramArrayOfbyte.length];
/*     */       
/* 265 */       int i = UTFEToJavaChar(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPORT_ERROR);
/*     */ 
/*     */ 
/*     */       
/* 269 */       return new String(arrayOfChar, 0, i);
/*     */     }
/* 271 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */       
/* 273 */       throw new SQLException(uTFDataFormatException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/* 283 */       char[] arrayOfChar = new char[paramArrayOfbyte.length];
/*     */       
/* 285 */       int i = UTFEToJavaChar(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPLACEMENT);
/*     */ 
/*     */ 
/*     */       
/* 289 */       return new String(arrayOfChar, 0, i);
/*     */     }
/* 291 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */ 
/*     */ 
/*     */       
/* 295 */       throw new IllegalStateException(uTFDataFormatException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int UTFEToJavaChar(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, char[] paramArrayOfchar, OraCharset.CharacterConverterBehavior paramCharacterConverterBehavior) throws UTFDataFormatException {
/* 305 */     int i = paramInt1;
/* 306 */     int j = paramInt1 + paramInt2;
/* 307 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     while (i < j) {
/*     */       
/* 315 */       byte b2, b3, b4, b1 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/*     */       
/* 317 */       switch (b1 >>> 4 & 0xF) {
/*     */ 
/*     */ 
/*     */         
/*     */         case 0:
/*     */         case 1:
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/* 329 */           paramArrayOfchar[b++] = (char)(b1 & Byte.MAX_VALUE);
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 8:
/*     */         case 9:
/* 336 */           paramArrayOfchar[b++] = (char)(b1 & 0x1F);
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 12:
/*     */         case 13:
/* 344 */           if (i >= j) {
/*     */             
/* 346 */             paramCharacterConverterBehavior.onFailConversion();
/* 347 */             i = j;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 352 */           b1 = (byte)(b1 & 0x1F);
/* 353 */           b2 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/*     */ 
/*     */           
/* 356 */           if (!is101xxxxx(b2)) {
/*     */             
/* 358 */             paramCharacterConverterBehavior.onFailConversion();
/* 359 */             paramArrayOfchar[b++] = '�';
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 365 */           paramArrayOfchar[b++] = (char)(b1 << 5 | b2 & 0x1F);
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 14:
/* 372 */           if (i + 1 >= j) {
/*     */             
/* 374 */             paramCharacterConverterBehavior.onFailConversion();
/* 375 */             i = j;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 380 */           b1 = (byte)(b1 & 0xF);
/* 381 */           b2 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/* 382 */           b3 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/*     */ 
/*     */           
/* 385 */           if (!is101xxxxx(b2) || !is101xxxxx(b3)) {
/*     */             
/* 387 */             paramCharacterConverterBehavior.onFailConversion();
/* 388 */             paramArrayOfchar[b++] = '�';
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 394 */           paramArrayOfchar[b++] = (char)(b1 << 10 | (b2 & 0x1F) << 5 | b3 & 0x1F);
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 15:
/* 402 */           if (i + 2 >= j) {
/*     */             
/* 404 */             paramCharacterConverterBehavior.onFailConversion();
/* 405 */             i = j;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 410 */           b1 = (byte)(b1 & 0x1);
/* 411 */           b2 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/* 412 */           b3 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/* 413 */           b4 = utfe2utf8m[high(paramArrayOfbyte[i])][low(paramArrayOfbyte[i++])];
/*     */ 
/*     */           
/* 416 */           if (!is101xxxxx(b2) || !is101xxxxx(b3) || !is101xxxxx(b4)) {
/*     */             
/* 418 */             paramCharacterConverterBehavior.onFailConversion();
/* 419 */             paramArrayOfchar[b++] = '�';
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 425 */           paramArrayOfchar[b++] = (char)(b1 << 15 | (b2 & 0x1F) << 10 | (b3 & 0x1F) << 5 | b4 & 0x1F);
/*     */           continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 437 */       paramCharacterConverterBehavior.onFailConversion();
/* 438 */       paramArrayOfchar[b++] = '�';
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convertWithReplacement(String paramString) {
/* 458 */     char[] arrayOfChar = paramString.toCharArray();
/* 459 */     byte[] arrayOfByte1 = new byte[arrayOfChar.length * 4];
/* 460 */     int i = javaCharsToUTFE(arrayOfChar, 0, arrayOfChar.length, arrayOfByte1, 0);
/* 461 */     byte[] arrayOfByte2 = new byte[i];
/* 462 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
/*     */     
/* 464 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convert(String paramString) throws SQLException {
/* 479 */     return convertWithReplacement(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int javaCharsToUTFE(char[] paramArrayOfchar, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
/* 488 */     int i = paramInt1 + paramInt2;
/*     */     
/* 490 */     byte b = 0;
/*     */     
/* 492 */     for (int j = paramInt1; j < i; j++) {
/*     */ 
/*     */       
/* 495 */       char c = paramArrayOfchar[j];
/*     */       
/* 497 */       if (c <= '\037') {
/*     */ 
/*     */ 
/*     */         
/* 501 */         int k = c | 0x80;
/* 502 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/*     */       }
/* 504 */       else if (c <= '') {
/*     */ 
/*     */ 
/*     */         
/* 508 */         paramArrayOfbyte[b++] = utf8m2utfe[high(c)][low(c)];
/*     */       }
/* 510 */       else if (c <= 'Ͽ') {
/*     */ 
/*     */ 
/*     */         
/* 514 */         int k = (c & 0x3E0) >> 5 | 0xC0;
/* 515 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/* 516 */         k = c & 0x1F | 0xA0;
/* 517 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/*     */       }
/* 519 */       else if (c <= '㿿') {
/*     */ 
/*     */ 
/*     */         
/* 523 */         int k = (c & 0x3C00) >> 10 | 0xE0;
/* 524 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/* 525 */         k = (c & 0x3E0) >> 5 | 0xA0;
/* 526 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/* 527 */         k = c & 0x1F | 0xA0;
/* 528 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 534 */         int k = (c & 0x8000) >> 15 | 0xF0;
/* 535 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/* 536 */         k = (c & 0x7C00) >> 10 | 0xA0;
/* 537 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/* 538 */         k = (c & 0x3E0) >> 5 | 0xA0;
/* 539 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/* 540 */         k = c & 0x1F | 0xA0;
/* 541 */         paramArrayOfbyte[b++] = utf8m2utfe[high(k)][low(k)];
/*     */       } 
/*     */     } 
/*     */     
/* 545 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int high(int paramInt) {
/* 551 */     return paramInt >>> 4 & 0xF;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int low(int paramInt) {
/* 557 */     return paramInt & 0xF;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean is101xxxxx(byte paramByte) {
/* 563 */     return ((paramByte & 0xFFFFFFE0) == -96);
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetUTFE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package oracle.i18n.text;
/*     */ 
/*     */ import java.io.UTFDataFormatException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.sql.SQLException;
/*     */ import oracle.i18n.text.converter.GDKMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OraCharsetAL16UTF16
/*     */   extends OraCharset
/*     */ {
/*  34 */   static final byte[] REPLACEMENT_CHAR_IN_BYTES = new byte[] { -1, -3 };
/*     */   
/*     */   OraCharsetAL16UTF16(String paramString, int paramInt) {
/*  37 */     super(paramString, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Charset paramCharset) {
/*  42 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharsetDecoder newDecoder() {
/*  47 */     return new OraCharsetDecoder(this, 0.5F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public CharsetEncoder newEncoder() {
/*  52 */     return new OraCharsetEncoder(this, 2.0F, 2.0F, REPLACEMENT_CHAR_IN_BYTES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toStringWithReplacement(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*     */     try {
/*  60 */       char[] arrayOfChar = new char[Math.min(paramArrayOfbyte.length - paramInt1 >>> 1, paramInt2 >>> 1)];
/*     */       
/*  62 */       int i = AL16UTF16BytesToJavaChars(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPLACEMENT);
/*     */ 
/*     */ 
/*     */       
/*  66 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  68 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */ 
/*     */       
/*  71 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*     */     try {
/*  83 */       char[] arrayOfChar = new char[Math.min(paramArrayOfbyte.length - paramInt1 >>> 1, paramInt2 >>> 1)];
/*     */       
/*  85 */       int i = AL16UTF16BytesToJavaChars(paramArrayOfbyte, paramInt1, paramInt2, arrayOfChar, OraCharset.CharacterConverterBehavior.REPORT_ERROR);
/*     */ 
/*     */ 
/*     */       
/*  89 */       return new String(arrayOfChar, 0, i);
/*     */     }
/*  91 */     catch (UTFDataFormatException uTFDataFormatException) {
/*     */       
/*  93 */       throw new SQLException(GDKMessage.getORAMessage(17037));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convertWithReplacement(String paramString) {
/* 100 */     char[] arrayOfChar = paramString.toCharArray();
/* 101 */     byte[] arrayOfByte = new byte[arrayOfChar.length * 2];
/* 102 */     javaCharsToAL16UTF16Bytes(arrayOfChar, arrayOfChar.length, arrayOfByte);
/*     */     
/* 104 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] convert(String paramString) throws SQLException {
/* 110 */     return convertWithReplacement(paramString);
/*     */   }
/*     */ }


/* Location:              D:\JDI\rwa-engine-1.0-SNAPSHOT(1)\rwa-engine-1.0-SNAPSHOT.jar!\BOOT-INF\lib\orai18n-19.18.0.0.jar!\oracle\i18n\text\OraCharsetAL16UTF16.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package com.googlecode.aviator.parser;

enum DepthState {
  Parent, Bracket, Lambda, Brace,
}

package com.googlecode.aviator.parser;

import java.io.Serializable;

/**
 * compile-time types
 * 
 * @author dennis(killme2008@gmail.com)
 *
 */
public enum CompileTypes implements Serializable {
  Function, Array, Class,
}

package com.googlecode.aviator.runtime.type;

/**
 * Sequence mark interface.
 *
 * @author dennis(killme2008@gmail.com)
 *
 * @param <T>
 */
public interface Sequence<T> extends Iterable<T> {
  Collector newCollector(int size);

  int hintSize();
}

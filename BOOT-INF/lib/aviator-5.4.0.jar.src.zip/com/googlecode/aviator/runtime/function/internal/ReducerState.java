package com.googlecode.aviator.runtime.function.internal;

/**
 *
 * @author dennis(killme2008@gmail.com)
 * @since 5.0.0
 */
public enum ReducerState {
  Empty, Cont, Break, Return
}
